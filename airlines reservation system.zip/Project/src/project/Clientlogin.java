
package project;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import java.sql.*;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import static jdk.nashorn.internal.runtime.Debug.id;

public class Clientlogin extends javax.swing.JFrame {
private Connection con;
private Statement st;
private PreparedStatement smt;
private ResultSet result;
private String path,user,password,paths;
byte[] image=null;
    public Clientlogin() {
        
        initComponents();
    }
 
    
    private void loadid(){
//    try {
//        smt=con.prepareStatement("select id from account");
//        result=smt.executeQuery();
//        ID.removeAll();
//        while (result.next()){
//        
//        ID.setText(result.getString(1));
//        }
//    } catch (SQLException ex) {
//        Logger.getLogger(Clientlogin.class.getName()).log(Level.SEVERE, null, ex);
//    }
//    
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jFileChooser1 = new javax.swing.JFileChooser();
        jFileChooser2 = new javax.swing.JFileChooser();
        dateChooserDialog1 = new datechooser.beans.DateChooserDialog();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        signin = new javax.swing.JButton();
        email = new javax.swing.JTextField();
        male = new javax.swing.JRadioButton();
        female = new javax.swing.JRadioButton();
        country = new javax.swing.JComboBox<>();
        already = new javax.swing.JLabel();
        create = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        passportNo = new javax.swing.JTextField();
        me = new javax.swing.JPasswordField();
        dob = new datechooser.beans.DateChooserCombo();
        jLabel10 = new javax.swing.JLabel();
        type = new javax.swing.JComboBox<>();
        imagebutton = new javax.swing.JButton();
        lbimage = new javax.swing.JLabel();
        phone = new javax.swing.JTextField();
        username = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        address = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();

        jFileChooser2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jFileChooser2ActionPerformed(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(204, 0, 255));
        setMinimumSize(new java.awt.Dimension(746, 613));
        setPreferredSize(new java.awt.Dimension(926, 633));
        setSize(new java.awt.Dimension(926, 633));
        getContentPane().setLayout(null);

        jLabel1.setFont(new java.awt.Font("Perpetua", 1, 30)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 102, 255));
        jLabel1.setText("CREATE ACCOUNT ");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(290, 10, 256, 35);

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(51, 255, 255));
        jLabel2.setText("Email");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(0, 180, 100, 22);

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(51, 255, 255));
        jLabel3.setText("PassportNo");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(480, 70, 110, 29);

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(51, 255, 255));
        jLabel4.setText("Date of Birth");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(0, 390, 120, 17);

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(51, 255, 255));
        jLabel5.setText("Gender");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(10, 330, 80, 17);

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(51, 255, 255));
        jLabel6.setText("Country of origin");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(0, 450, 160, 17);

        signin.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        signin.setForeground(new java.awt.Color(51, 255, 255));
        signin.setText("Sign in");
        signin.setToolTipText("click here to sign in");
        signin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                signinActionPerformed(evt);
            }
        });
        getContentPane().add(signin);
        signin.setBounds(250, 560, 122, 32);
        getContentPane().add(email);
        email.setBounds(210, 159, 251, 39);

        buttonGroup1.add(male);
        male.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        male.setForeground(new java.awt.Color(51, 255, 255));
        male.setText("Male");
        getContentPane().add(male);
        male.setBounds(220, 319, 80, 31);

        buttonGroup1.add(female);
        female.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        female.setForeground(new java.awt.Color(51, 255, 255));
        female.setText("Female");
        getContentPane().add(female);
        female.setBounds(350, 320, 100, 31);

        country.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        country.setForeground(new java.awt.Color(51, 255, 255));
        country.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "select home country", "Uganda", "Rwanda", "England", "Germany", "Switzerland", "Poland", "SouthAfrica", "Togo", "Nigeria", "Burundi", "Cape verde", "Egypt", "Senegal", "Kenya", "Tanzania", "Kenya", "Canada", "USA", "Brazil", "Mexico", "Greece", "Spain", "Germany" }));
        getContentPane().add(country);
        country.setBounds(210, 429, 251, 41);

        already.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        already.setText("Already have an account?");
        getContentPane().add(already);
        already.setBounds(240, 570, 159, 17);

        create.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        create.setForeground(new java.awt.Color(51, 255, 255));
        create.setText("Create");
        create.setToolTipText("create an account");
        create.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                createMouseClicked(evt);
            }
        });
        create.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                createActionPerformed(evt);
            }
        });
        getContentPane().add(create);
        create.setBounds(250, 490, 122, 32);

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(51, 255, 255));
        jLabel8.setText("Password");
        getContentPane().add(jLabel8);
        jLabel8.setBounds(0, 130, 100, 22);

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(51, 255, 255));
        jLabel9.setText("phone");
        getContentPane().add(jLabel9);
        jLabel9.setBounds(0, 230, 70, 20);
        getContentPane().add(passportNo);
        passportNo.setBounds(606, 64, 222, 31);

        me.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                meActionPerformed(evt);
            }
        });
        getContentPane().add(me);
        me.setBounds(210, 112, 251, 33);

        dob.setCalendarBackground(new java.awt.Color(51, 255, 255));
        getContentPane().add(dob);
        dob.setBounds(210, 369, 251, 38);

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(51, 255, 255));
        jLabel10.setText("Account type");
        getContentPane().add(jLabel10);
        jLabel10.setBounds(0, 270, 130, 20);

        type.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        type.setForeground(new java.awt.Color(51, 255, 255));
        type.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "select account type", "admin", "user" }));
        getContentPane().add(type);
        type.setBounds(210, 249, 251, 40);

        imagebutton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        imagebutton.setForeground(new java.awt.Color(51, 255, 255));
        imagebutton.setText("Add Image");
        imagebutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                imagebuttonActionPerformed(evt);
            }
        });
        getContentPane().add(imagebutton);
        imagebutton.setBounds(620, 490, 130, 43);
        getContentPane().add(lbimage);
        lbimage.setBounds(568, 184, 250, 280);
        getContentPane().add(phone);
        phone.setBounds(210, 209, 251, 31);
        getContentPane().add(username);
        username.setBounds(210, 64, 251, 31);

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(51, 255, 255));
        jLabel12.setText("Address");
        getContentPane().add(jLabel12);
        jLabel12.setBounds(490, 130, 90, 29);

        address.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addressActionPerformed(evt);
            }
        });
        getContentPane().add(address);
        address.setBounds(606, 128, 222, 31);

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 255, 255));
        jLabel11.setText("User Name");
        getContentPane().add(jLabel11);
        jLabel11.setBounds(0, 70, 130, 29);

        jLabel7.setIcon(new javax.swing.ImageIcon("C:\\Users\\This Pc\\Pictures\\Saved Pictures\\air1.PNG")); // NOI18N
        jLabel7.setText("jLabel7");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(0, 0, 890, 640);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void signinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_signinActionPerformed
new Login().setLayout(null);
            new Login().setLocationRelativeTo(null);
            new Login().setVisible(true);
            this.dispose();       
    }//GEN-LAST:event_signinActionPerformed

    private void createActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_createActionPerformed
        // TODO add your handling code here:
        
     if(username.getText().trim().isEmpty()){
        JOptionPane.showMessageDialog(null, "username cannot be empty", "Error message", JOptionPane.ERROR_MESSAGE);
        username.requestFocus();
        }
     else if(username.getText().trim().length()<3){
        JOptionPane.showMessageDialog(null, "username cannot be less than three characters", "Error message", JOptionPane.ERROR_MESSAGE);
        }

     else if(me.getText().toString().isEmpty()){
        JOptionPane.showMessageDialog(null, "password field cant be empry", "Error message", JOptionPane.ERROR_MESSAGE);
        me.requestFocus(true);
         }
        
     else if(email.getText().trim().isEmpty()){
        JOptionPane.showMessageDialog(null, "gender field cannot be empty", "Error message", JOptionPane.ERROR_MESSAGE);
        email.requestFocus();
        }
        else if(phone.getText().trim().length()<10){
        JOptionPane.showMessageDialog(null, "phone must be ten characters long", "Error message", JOptionPane.ERROR_MESSAGE);
        phone.requestFocus();
        }
      else if(!phone.getText().matches("[0-9]+")){
           JOptionPane.showMessageDialog(null, "Enter only integer values", "Error message", JOptionPane.ERROR_MESSAGE);
           phone.requestFocus();
       }
      else if(dob.getText().isEmpty()){
           JOptionPane.showMessageDialog(null, "Enter the date of birth", "Error message", JOptionPane.ERROR_MESSAGE);
           dob.requestFocus();
       }
             else if(type.getSelectedItem().toString()=="Select account type"){
        JOptionPane.showMessageDialog(null, "Please specify the account", "Error message", JOptionPane.ERROR_MESSAGE);
        type.requestFocus();
        }
       else  if(!male.isSelected() && !female.isSelected()){
                JOptionPane.showMessageDialog(null,"Please select a gender");
            }
        

       else if(country.getSelectedItem().toString()=="Select home country"){
        JOptionPane.showMessageDialog(null, "Please select your home country", "Error message", JOptionPane.ERROR_MESSAGE);
        country.requestFocus();
        }
       else   if(address.getText().trim().isEmpty()){
        JOptionPane.showMessageDialog(null, "provide your address", "Error message", JOptionPane.ERROR_MESSAGE);
        address.requestFocus();
        }
     
       else if(passportNo.getText().trim().isEmpty()){
           JOptionPane.showMessageDialog(this, "passport is missing");
           passportNo.requestFocus();
       }
       else{
        try{
            
          
             con=null;
        smt=null;
        result=null;
        st=null;
        user="root";
        path="jdbc:mysql://localhost:3306/airlines";
        password="";
        String genders=null;
            if(male.isSelected()){
            genders="male";
            }else if(female.isSelected()){
            genders="female";
            }else{
            JOptionPane.showMessageDialog(null,"select gender");
            }
            Class.forName("com.mysql.jdbc.Driver");
             con = DriverManager.getConnection(path, user, password);
            String insert_query="INSERT INTO account( username,password,email,passportNo,address,phone,accounttype,gender,dateof_birth,destination,image,path) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
            smt=con.prepareStatement(insert_query); 
            smt.setString(1, username.getText());
            smt.setString(2, me.getText());
            smt.setString(3, email.getText());
            int ph =Integer.parseInt(phone.getText().trim());
            smt.setString(4, passportNo.getText());
            smt.setString(5, address.getText());
            smt.setInt(6, ph);
            smt.setString(7, type.getSelectedItem().toString());
            smt.setString(8, genders);
            smt.setString(9, dob.getText());
            smt.setString(10, country.getSelectedItem().toString());
            smt.setBytes(11, image);
            smt.setString(12, paths);
            smt.executeUpdate();
            Clear();
            JOptionPane.showMessageDialog(null, "Hey"+passportNo.getText()+"\t\t\t you have successfully created an account \n with talex airlines","Success message",JOptionPane.INFORMATION_MESSAGE);
            new Login().setLayout(null);
            new Login().setLocationRelativeTo(null);
            new Login().setVisible(true);
            this.dispose();
            }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, ex.getMessage());
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Passengers.class.getName()).log(Level.SEVERE, null, ex);
            }
       }
    }//GEN-LAST:event_createActionPerformed

    private void Clear(){
        type.setSelectedItem("");
        country.setSelectedItem("");
        email.setText("");
        passportNo.setText("");
        username.setText("");
        phone.setText("");
        dob.setText("");
        address.setText("");
        male.setSelected(false);
        female.setSelected(false);
        username.requestFocus();

}
    private void jFileChooser2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jFileChooser2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jFileChooser2ActionPerformed

    private void imagebuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_imagebuttonActionPerformed
        // TODO add your handling code here:
        JFileChooser chose = new JFileChooser();
        chose.showOpenDialog(null);
        File f=chose.getSelectedFile();
        lbimage.setIcon(new ImageIcon(f.toString()));
         paths=f.getAbsolutePath();
        try{
        File img = new File(paths);
        FileInputStream fis=new FileInputStream(img);
        ByteArrayOutputStream a=new ByteArrayOutputStream();
        byte[] buf=new byte[1024];
        for (int readNum;(readNum=fis.read(buf))!=-1;){
        a.write(buf, 0, readNum);
        }
        image=a.toByteArray();
        }catch(Exception e){
        JOptionPane.showMessageDialog(this, e.getStackTrace());
        }
    }//GEN-LAST:event_imagebuttonActionPerformed

    private void createMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_createMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_createMouseClicked

    private void meActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_meActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_meActionPerformed

    private void addressActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addressActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_addressActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Clientlogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Clientlogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Clientlogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Clientlogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
              new Clientlogin().setVisible(true);
            }
        });
    }
   


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField address;
    private javax.swing.JLabel already;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox<String> country;
    private javax.swing.JButton create;
    private datechooser.beans.DateChooserDialog dateChooserDialog1;
    private datechooser.beans.DateChooserCombo dob;
    private javax.swing.JTextField email;
    private javax.swing.JRadioButton female;
    private javax.swing.JButton imagebutton;
    private javax.swing.JFileChooser jFileChooser1;
    private javax.swing.JFileChooser jFileChooser2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel lbimage;
    private javax.swing.JRadioButton male;
    private javax.swing.JPasswordField me;
    private javax.swing.JTextField passportNo;
    private javax.swing.JTextField phone;
    private javax.swing.JButton signin;
    private javax.swing.JComboBox<String> type;
    private javax.swing.JTextField username;
    // End of variables declaration//GEN-END:variables
}
