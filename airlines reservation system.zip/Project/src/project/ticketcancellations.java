
package project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import net.proteanit.sql.DbUtils;
/**
 * 
 *<h3 style="color red"> MAIN CLASS</h3>
 * 
 */
public class ticketcancellations extends javax.swing.JFrame {
private Connection con;
private ResultSet result;
private PreparedStatement smt;
private Statement st;
private String path,user,password;
/**
 * 
 * <h3 style="color red"> Initializes components</h3>
 * 
 */
    public ticketcancellations() {
        initComponents();
        getTicket();  
    }

        
        
/**
 * 
 * <h3 style="color red"> returns a null and shows cancelled bookings when called</h3>
 * 
 */
    
    public void CancelledbOOKINGS(){
    try{
        con=null;
        smt=null;
        result=null;
        user="root";
        path="jdbc:mysql://localhost:3306/airlines";
        password="";
        Class.forName("com.mysql.jdbc.Driver");
             con = DriverManager.getConnection(path, user, password);
             st=con.createStatement();
             result=st.executeQuery("select * from cancellation");
             table.setModel(DbUtils.resultSetToTableModel(result));
    }  catch(Exception ex){
         JOptionPane.showMessageDialog(null,ex.getMessage(),"Error Message",JOptionPane.ERROR_MESSAGE);}
    
    }
    /**
 * 
 *  <h3 style="color red">gets flight codes from the flights table</h3>

 */
public void getTicket(){
    try{
        con=null;
        smt=null;
        result=null;
        st=null;
        user="root";
        path="jdbc:mysql://localhost:3306/airlines";
        password="";
        Class.forName("com.mysql.jdbc.Driver");
             con = DriverManager.getConnection(path, user, password);
             st=con.createStatement();
             String Query ="select * from bookings";
           result=st.executeQuery(Query);
           while(result.next()){
            String code=result.getString("pid");
            String fcoded=result.getString("code");
           ticketid.addItem(code);
           codes.addItem(fcoded);
           

           }
    }  catch(Exception ex){
         JOptionPane.showMessageDialog(null,ex.getMessage(),"Error Message",JOptionPane.ERROR_MESSAGE);}
    
    }
/**
 * 
 * @param evt <h3 style="color red"> Cancels out tickets</h3>
 * @return returns a null value
 */
private void Cancel(){
 try{
     validate();
        con=null;
        smt=null;
        result=null;
        user="root";
        path="jdbc:mysql://localhost:3306/airlines";
        password="";
        Class.forName("com.mysql.jdbc.Driver");
        con = DriverManager.getConnection(path, user, password);
        String query="delete from bookings where flightcode="+codes.getSelectedItem();
        Statement dele=con.createStatement();
        dele.executeUpdate(query);
        }catch(Exception e){
        JOptionPane.showMessageDialog(this, e.getMessage());
        }
        }



    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        dateChooserDialog1 = new datechooser.beans.DateChooserDialog();
        dateComponentFormatter1 = new org.jdatepicker.impl.DateComponentFormatter();
        jLabel4 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        tick = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        back = new javax.swing.JButton();
        reset = new javax.swing.JButton();
        cancel = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        ticketid = new javax.swing.JComboBox<>();
        candate = new datechooser.beans.DateChooserCombo();
        codes = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jLabel4.setText("jLabel4");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(204, 255, 51));
        setForeground(new java.awt.Color(102, 102, 255));
        setSize(new java.awt.Dimension(650, 700));

        jPanel2.setPreferredSize(new java.awt.Dimension(691, 672));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 51));
        jLabel6.setText("Ticket ID");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(57, 143, 91, 37));

        tick.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tick.setForeground(new java.awt.Color(255, 255, 51));
        tick.setText("Cancellation date");
        jPanel2.add(tick, new org.netbeans.lib.awtextra.AbsoluteConstraints(537, 143, 122, 37));

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 51));
        jLabel8.setText("Flight code");
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(279, 143, 112, 37));

        back.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        back.setForeground(new java.awt.Color(255, 255, 51));
        back.setText("Back");
        back.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                backMouseClicked(evt);
            }
        });
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });
        jPanel2.add(back, new org.netbeans.lib.awtextra.AbsoluteConstraints(528, 258, 195, 44));

        reset.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        reset.setForeground(new java.awt.Color(255, 255, 51));
        reset.setText("Reset");
        reset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetActionPerformed(evt);
            }
        });
        jPanel2.add(reset, new org.netbeans.lib.awtextra.AbsoluteConstraints(249, 258, 195, 44));

        cancel.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        cancel.setForeground(new java.awt.Color(255, 255, 51));
        cancel.setIcon(new javax.swing.ImageIcon("C:\\Users\\This Pc\\Pictures\\Saved Pictures\\mest.PNG")); // NOI18N
        cancel.setText("Cancel");
        cancel.setToolTipText("cancel flights");
        cancel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cancelMouseClicked(evt);
            }
        });
        cancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelActionPerformed(evt);
            }
        });
        jPanel2.add(cancel, new org.netbeans.lib.awtextra.AbsoluteConstraints(27, 258, 157, 44));

        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane2.setViewportView(table);

        jPanel2.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 377, 734, 252));

        jLabel3.setBackground(new java.awt.Color(255, 51, 0));
        jLabel3.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 102, 255));
        jLabel3.setText("Cancelled tickets");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 334, 160, 32));

        ticketid.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        ticketid.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "select id", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11" }));
        ticketid.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ticketidActionPerformed(evt);
            }
        });
        jPanel2.add(ticketid, new org.netbeans.lib.awtextra.AbsoluteConstraints(27, 191, 179, 37));

        candate.setLocale(new java.util.Locale("", "", ""));
        jPanel2.add(candate, new org.netbeans.lib.awtextra.AbsoluteConstraints(528, 191, 195, 37));

        codes.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "code" }));
        jPanel2.add(codes, new org.netbeans.lib.awtextra.AbsoluteConstraints(249, 193, 195, 36));

        jLabel2.setFont(new java.awt.Font("Tempus Sans ITC", 1, 36)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 0, 0));
        jLabel2.setText("Ticket Cancellation");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(191, 60, -1, -1));

        jLabel1.setFont(new java.awt.Font("Perpetua", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 51));
        jLabel1.setText("TALEX Airlines ");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 10, -1, -1));

        jLabel7.setIcon(new javax.swing.ImageIcon("C:\\Users\\This Pc\\Pictures\\Saved Pictures\\aero.jpg")); // NOI18N
        jLabel7.setText("jLabel7");
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 754, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 675, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    /**
 * 
 * @param evt <h3 style="color red"> cancels flights and calls the cancelled bookings</h3>
 * @return returns a null value
 */
    private void cancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelActionPerformed
        // TODO add your handling code here:
        CancelledbOOKINGS();
    }//GEN-LAST:event_cancelActionPerformed
/**
 * 
 * @param evt <h3 style="color red"> returns back to the administrator menu</h3>
 * @return returns a null value
 */
    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
        // TODO add your handling code here:
        Flight fly =new Flight();
        fly.setLayout(null);
        fly.setLocationRelativeTo(null);
        fly.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_backActionPerformed
/**
 * 
 * @param evt <h3 style="color red"> Clears all JTtextfields</h3>
 * @return returns a null value
 */
    private void resetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetActionPerformed
        // TODO add your handling code here:
       codes.setSelectedItem("");
        ticketid.setSelectedItem("");
        tick.setText("");
        clear();
    }//GEN-LAST:event_resetActionPerformed

    private void backMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_backMouseClicked
        // TODO add your handling code here:
        Flight fly = new Flight();
        fly.setLocationRelativeTo(null);
        fly.setLayout(null);
        fly.setVisible(true);
    }//GEN-LAST:event_backMouseClicked

    private void ticketidActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ticketidActionPerformed
        // TODO add your handling code here:
              
    }//GEN-LAST:event_ticketidActionPerformed

    private void cancelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cancelMouseClicked
        // TODO add your handling code here:
        if(ticketid.getSelectedItem()=="select id"){
        JOptionPane.showMessageDialog(this, " code ");
        ticketid.requestFocus();
        }
        else if(codes.getSelectedItem()==" select the code"){
        JOptionPane.showMessageDialog(this, "select the flight code");
        }
        else{
        try{
             con=null;
        smt=null;
        result=null;
        st=null;
        user="root";
        path="jdbc:mysql://localhost:3306/airlines";
        password="";
            Class.forName("com.mysql.jdbc.Driver");
             con = DriverManager.getConnection(path, user, password);
            String insert_query="INSERT INTO cancellation( ticketid,flightcode,cancellationdate) VALUES (?,?,?)";
            smt=con.prepareStatement(insert_query);
            smt.setInt(1, Integer.parseInt(ticketid.getSelectedItem().toString()));
            smt.setString(2, codes.getSelectedItem().toString());
            smt.setString(3, candate.getText());
            smt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Flight cancelled","Success message",JOptionPane.INFORMATION_MESSAGE);
            
            }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, ex.getMessage());
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Passengers.class.getName()).log(Level.SEVERE, null, ex);
            }
        clear();
         Cancel();
        CancelledbOOKINGS();
       
        }
    }//GEN-LAST:event_cancelMouseClicked
int key=0;
/**
 * <h2>This is the main method</h2>
 * @param args takes on the arguments of the method
 */
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                 new ticketcancellations().setLocationRelativeTo(null);
                 new ticketcancellations().setLayout(null);
                new ticketcancellations().setVisible(true);
            }
        });
    }
    /**
     * <h4>Clears all the JTextFields</h4>
     */
public void clear(){
codes.setSelectedItem("");
ticketid.setSelectedItem("");
}
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton back;
    private javax.swing.JButton cancel;
    private datechooser.beans.DateChooserCombo candate;
    private javax.swing.JComboBox<String> codes;
    private datechooser.beans.DateChooserDialog dateChooserDialog1;
    private org.jdatepicker.impl.DateComponentFormatter dateComponentFormatter1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JButton reset;
    private javax.swing.JTable table;
    private javax.swing.JLabel tick;
    private javax.swing.JComboBox<String> ticketid;
    // End of variables declaration//GEN-END:variables
}
