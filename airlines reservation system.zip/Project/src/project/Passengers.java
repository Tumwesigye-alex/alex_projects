
package project;

import java.awt.Image;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;

public class Passengers extends javax.swing.JFrame {
    private Connection con;
private ResultSet result,rst;
private PreparedStatement smt,smtcount;
private Statement st,stcount;
private String path,user,password;
public void returnPassengers(){
    try{
        con=null;
        smt=null;
        result=null;
        user="root";
        path="jdbc:mysql://localhost:3306/airlines";
        password="";
        Class.forName("com.mysql.jdbc.Driver");
             con = DriverManager.getConnection(path, user, password);
             st=con.createStatement();
             result=st.executeQuery("select * from passengers");
             passen.setModel(DbUtils.resultSetToTableModel(result));
    }  catch(Exception ex){
         JOptionPane.showMessageDialog(null,ex.getMessage(),"Error Message",JOptionPane.ERROR_MESSAGE);}
    
    }
private void getPassengerData(){
String myworry="select * from account where passportNo='"+passportNo.getText()+"'";
     con=null;
      ResultSet  r=null;
      Statement st=null;
        user="root";
        path="jdbc:mysql://localhost:3306/airlines";
        password="";
        
try{
Class.forName("com.mysql.jdbc.Driver");
ImageIcon format;
con = DriverManager.getConnection(path, user, password);
st=con.createStatement();
r=st.executeQuery(myworry);
if(r.next()==false){
    JOptionPane.showMessageDialog(this, "passenger not found");

}else{
fname.setText(r.getString("username"));
gender.setText(r.getString("gender"));
passportNo.setText(r.getString("passportNo"));
nationality.setText(r.getString("destination"));
phone.setText(r.getString("phone"));
address.setText(r.getString("address"));
byte[] imagedata=r.getBytes("image");
format=new ImageIcon(imagedata);
Image mm=format.getImage();
Image img2=mm.getScaledInstance(lbimage.getWidth(), lbimage.getHeight(), Image.SCALE_SMOOTH);
ImageIcon image = new ImageIcon(img2);
lbimage.setIcon(image);
}

}catch(Exception e){


}
}

    public Passengers() {
        initComponents();
        //returnPassengers();
        con=null;
        smt=null;
        result=null;
        user="root";
        path="jdbc:mysql://localhost:3306/airlines";
        password="";
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        utilDateModel1 = new org.jdatepicker.impl.UtilDateModel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        fname = new javax.swing.JTextField();
        phone = new javax.swing.JTextField();
        address = new javax.swing.JTextField();
        back = new javax.swing.JButton();
        delete = new javax.swing.JButton();
        edit = new javax.swing.JButton();
        save = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        passen = new javax.swing.JTable();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        gender = new javax.swing.JTextField();
        nationality = new javax.swing.JTextField();
        search = new javax.swing.JButton();
        id = new javax.swing.JLabel();
        passportNo = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        lbimage = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(960, 563));
        setPreferredSize(new java.awt.Dimension(909, 676));
        setResizable(false);
        setSize(new java.awt.Dimension(909, 676));
        getContentPane().setLayout(null);

        jLabel1.setFont(new java.awt.Font("Perpetua Titling MT", 1, 30)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(204, 204, 0));
        jLabel1.setText("derrick AIRLINES ");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(280, 10, 330, 43);

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel2.setText("Manage Passengers");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(350, 60, 210, 25);

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 102, 255));
        jLabel4.setText("Address");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(20, 449, 81, 25);

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(51, 102, 255));
        jLabel5.setText("Nationality");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(20, 273, 110, 25);

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(51, 102, 255));
        jLabel6.setText("Gender");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(20, 368, 74, 25);

        jLabel7.setBackground(new java.awt.Color(255, 255, 255));
        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(51, 102, 255));
        jLabel7.setText("Name");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(20, 202, 58, 25);

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 102, 255));
        jLabel8.setText("Phone");
        getContentPane().add(jLabel8);
        jLabel8.setBounds(20, 542, 63, 25);

        fname.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        fname.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                fnameKeyPressed(evt);
            }
        });
        getContentPane().add(fname);
        fname.setBounds(153, 202, 180, 39);

        phone.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        phone.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                phoneKeyPressed(evt);
            }
        });
        getContentPane().add(phone);
        phone.setBounds(139, 536, 190, 44);

        address.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        address.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                addressKeyPressed(evt);
            }
        });
        getContentPane().add(address);
        address.setBounds(139, 444, 190, 42);

        back.setBackground(new java.awt.Color(204, 204, 255));
        back.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        back.setForeground(new java.awt.Color(0, 102, 255));
        back.setIcon(new javax.swing.ImageIcon("C:\\Users\\This Pc\\Pictures\\Saved Pictures\\back.jpg")); // NOI18N
        back.setText("Back");
        back.setActionCommand("Save");
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });
        getContentPane().add(back);
        back.setBounds(730, 610, 130, 41);

        delete.setBackground(new java.awt.Color(204, 204, 255));
        delete.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        delete.setForeground(new java.awt.Color(0, 102, 255));
        delete.setIcon(new javax.swing.ImageIcon("C:\\Users\\This Pc\\Pictures\\Saved Pictures\\delete.png")); // NOI18N
        delete.setText("Delete");
        delete.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                deleteMouseClicked(evt);
            }
        });
        delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteActionPerformed(evt);
            }
        });
        delete.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                deleteKeyPressed(evt);
            }
        });
        getContentPane().add(delete);
        delete.setBounds(520, 610, 140, 41);

        edit.setBackground(new java.awt.Color(204, 204, 255));
        edit.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        edit.setForeground(new java.awt.Color(51, 102, 255));
        edit.setIcon(new javax.swing.ImageIcon("C:\\Users\\This Pc\\Pictures\\Saved Pictures\\edit.png")); // NOI18N
        edit.setText("Edit");
        edit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                editMouseClicked(evt);
            }
        });
        edit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editActionPerformed(evt);
            }
        });
        getContentPane().add(edit);
        edit.setBounds(300, 610, 140, 41);

        save.setBackground(new java.awt.Color(204, 204, 255));
        save.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        save.setForeground(new java.awt.Color(0, 102, 255));
        save.setIcon(new javax.swing.ImageIcon("C:\\Users\\This Pc\\Pictures\\Saved Pictures\\saved.jpg")); // NOI18N
        save.setText("Save");
        save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveActionPerformed(evt);
            }
        });
        getContentPane().add(save);
        save.setBounds(30, 611, 103, 41);

        passen.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.MatteBorder(null), "Passengers table", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 11), new java.awt.Color(0, 255, 204))); // NOI18N
        passen.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        passen.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        passen.setSelectionBackground(new java.awt.Color(204, 204, 255));
        passen.setSelectionForeground(new java.awt.Color(0, 102, 255));
        passen.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                passenMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(passen);

        getContentPane().add(jScrollPane2);
        jScrollPane2.setBounds(339, 353, 570, 230);

        jButton3.setBackground(new java.awt.Color(204, 204, 255));
        jButton3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton3.setForeground(new java.awt.Color(51, 102, 255));
        jButton3.setText("Passenger List");
        jButton3.setActionCommand("Passengers");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3);
        jButton3.setBounds(360, 310, 180, 40);

        jButton4.setBackground(new java.awt.Color(204, 204, 255));
        jButton4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton4.setForeground(new java.awt.Color(51, 102, 255));
        jButton4.setIcon(new javax.swing.ImageIcon("C:\\Users\\This Pc\\Pictures\\Saved Pictures\\printers.PNG")); // NOI18N
        jButton4.setText("Print");
        jButton4.setToolTipText("print passengers");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton4);
        jButton4.setBounds(700, 310, 170, 40);

        gender.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        gender.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                genderKeyPressed(evt);
            }
        });
        getContentPane().add(gender);
        gender.setBounds(149, 353, 180, 38);

        nationality.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        nationality.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                nationalityKeyPressed(evt);
            }
        });
        getContentPane().add(nationality);
        nationality.setBounds(153, 270, 180, 38);

        search.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        search.setForeground(new java.awt.Color(0, 102, 255));
        search.setText("search");
        search.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                searchMouseClicked(evt);
            }
        });
        search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchActionPerformed(evt);
            }
        });
        getContentPane().add(search);
        search.setBounds(355, 138, 102, 40);

        id.setBackground(new java.awt.Color(255, 255, 255));
        id.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        id.setForeground(new java.awt.Color(51, 102, 255));
        id.setText("passportNo");
        getContentPane().add(id);
        id.setBounds(20, 144, 114, 25);

        passportNo.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        passportNo.setForeground(new java.awt.Color(255, 102, 102));
        getContentPane().add(passportNo);
        passportNo.setBounds(153, 139, 170, 39);

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(51, 102, 255));
        jLabel10.setText("photo");
        getContentPane().add(jLabel10);
        jLabel10.setBounds(540, 140, 67, 25);

        lbimage.setToolTipText("passenger photo");
        getContentPane().add(lbimage);
        lbimage.setBounds(644, 44, 210, 260);

        jLabel9.setIcon(new javax.swing.ImageIcon("C:\\Users\\This Pc\\Pictures\\Saved Pictures\\timetotravelair.jpg")); // NOI18N
        jLabel9.setText("jLabel9");
        getContentPane().add(jLabel9);
        jLabel9.setBounds(10, 10, 950, 660);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveActionPerformed
        // TODO add your handling code here:
          String first_name=fname.getText().trim();
        String ddresses=address.getText().trim();
        String pho=phone.getText().trim();
      

         if(first_name.isEmpty()){
        JOptionPane.showMessageDialog(null, "Enter your name", "Error message", JOptionPane.ERROR_MESSAGE);
        fname.requestFocus();
        }
         else if(fname.getText().length()<3){
        JOptionPane.showMessageDialog(null, "Name must be three or more characters long", "Error message", JOptionPane.ERROR_MESSAGE);
        fname.requestFocus();
        }
         else if(nationality.getText().trim().isEmpty()){
        JOptionPane.showMessageDialog(null, "What is your nationality", "Error message", JOptionPane.ERROR_MESSAGE);
        nationality.requestFocus();
        }
          else if(passportNo.getText().trim().isEmpty()){
        JOptionPane.showMessageDialog(null, "provide the passport number", "Error message", JOptionPane.ERROR_MESSAGE);
        passportNo.requestFocus();
        }
          else if(address.getText().trim().isEmpty()){
        JOptionPane.showMessageDialog(null, "provide your address", "Error message", JOptionPane.ERROR_MESSAGE);
        address.requestFocus();
        }
         else  if(pho.isEmpty()){
        JOptionPane.showMessageDialog(null, "What are your contacts", "Error message", JOptionPane.ERROR_MESSAGE);
        phone.requestFocus();
        }

          else{
        try{
            
            Class.forName("com.mysql.jdbc.Driver");
             con = DriverManager.getConnection(path, user, password);
            String insert_query="INSERT INTO passengers( fname, nationality,gender,passportNo,Address,phone) VALUES (?,?,?,?,?,?)";
            smt=con.prepareStatement(insert_query);
            smt.setString(1, fname.getText());
            smt.setString(2, nationality.getText());
            smt.setString(3, gender.getText());
            smt.setString(4, passportNo.getText());
            smt.setString(5, address.getText());
            smt.setString(6, phone.getText());
            smt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Passenger recorded","Success message",JOptionPane.INFORMATION_MESSAGE);
            returnPassengers();
            }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, ex.getMessage());
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Passengers.class.getName()).log(Level.SEVERE, null, ex);
            }
        Clear();
          }
    }//GEN-LAST:event_saveActionPerformed
 private void Clear(){
        //pasId.setSelectedIndex(0);
        gender.setText("");
        nationality.setText("");
        passportNo.setText("");
        phone.setText("");
        fname.setText("");
        address.setText("");
        passportNo.requestFocus();

}
   
    private void deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_deleteActionPerformed

    private void deleteKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_deleteKeyPressed
       
    }//GEN-LAST:event_deleteKeyPressed

    private void deleteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_deleteMouseClicked
        // TODO add your handling code here:
        if(key==0){
        JOptionPane.showMessageDialog(this, "please select a passenger");
        }else{
        try{
        con=null;
        smt=null;
        result=null;
        user="root";
        path="jdbc:mysql://localhost:3306/airlines";
        password="";
        Class.forName("com.mysql.jdbc.Driver");
        con = DriverManager.getConnection(path, user, password);
        String query="delete from passengers where id=0"+key;
        Statement dele=con.createStatement();
        dele.executeUpdate(query);
        JOptionPane.showMessageDialog(this, "Passenger deleted","Success Message",JOptionPane.INFORMATION_MESSAGE);
        }catch(Exception e){
        JOptionPane.showMessageDialog(this, e.getMessage());
        }
        
        }
    }//GEN-LAST:event_deleteMouseClicked
int key=0;
    private void passenMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_passenMouseClicked
        DefaultTableModel model=(DefaultTableModel)passen.getModel();
        int mytable=passen.getSelectedRow();
        key=Integer.valueOf(model.getValueAt(mytable, 0).toString());
        fname.setText(model.getValueAt(mytable, 1).toString());
        nationality.setText(model.getValueAt(mytable, 2).toString());
        gender.setText(model.getValueAt(mytable, 3).toString());
        passportNo.setText(model.getValueAt(mytable, 4).toString());
        address.setText(model.getValueAt(mytable, 5).toString());
        phone.setText(model.getValueAt(mytable, 6).toString());
        
    }//GEN-LAST:event_passenMouseClicked

    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
        // TODO add your handling code here:
        new Flight().setLayout(null);
        new Flight().setLocationRelativeTo(null);
        new Flight().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_backActionPerformed

    private void editMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_editMouseClicked
fname.setEditable(true);
        if(key==0){
           JOptionPane.showMessageDialog(null, "select a passenger column to edit", "Error message", JOptionPane.ERROR_MESSAGE);
       }else{
        try{
            
            Class.forName("com.mysql.jdbc.Driver");
             con = DriverManager.getConnection(path, user, password);
             String updatequery="update passengers set fname=?,nationality=?,gender=?,passportNo=?,Address=?,phone=? where pid=? ";
            smt=con.prepareStatement(updatequery);
            smt.setInt(7, key);
            smt.setString(1, fname.getText());
            smt.setString(2, nationality.getText());
            smt.setString(3, gender.getText());
            smt.setString(4, passportNo.getText());
            smt.setString(5, address.getText());
            smt.setString(6, phone.getText());
            smt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Passenger Updated","Success message",JOptionPane.INFORMATION_MESSAGE);
            returnPassengers();
            }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, ex.getMessage());
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Passengers.class.getName()).log(Level.SEVERE, null, ex);
            }

    }//GEN-LAST:event_editMouseClicked
    }
    
    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        try{
        passen.print(JTable.PrintMode.NORMAL);
        }
        catch(Exception e){
        
        }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        returnPassengers();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchActionPerformed
getPassengerData();
// TODO add your handling code here:
    }//GEN-LAST:event_searchActionPerformed

    private void searchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_searchMouseClicked
        // TODO add your handling code here:
        getPassengerData();
    }//GEN-LAST:event_searchMouseClicked

    private void editActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_editActionPerformed

    private void fnameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_fnameKeyPressed
char c=evt.getKeyChar();
  if(Character.isLetter(c)||Character.isWhitespace(c)||Character.isISOControl(c)){
  fname.setEditable(true);
  } else{fname.setEditable(false);}       // TODO add your handling code here:
            // TODO add your handling code here:
    }//GEN-LAST:event_fnameKeyPressed

    private void nationalityKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nationalityKeyPressed
char c=evt.getKeyChar();
  if(Character.isLetter(c)||Character.isWhitespace(c)||Character.isISOControl(c)){
  nationality.setEditable(true);
  } else{nationality.setEditable(false);}       // TODO add your handling code here:
            // TODO add your handling code here:
    }//GEN-LAST:event_nationalityKeyPressed

    private void genderKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_genderKeyPressed
char c=evt.getKeyChar();
  if(Character.isLetter(c)||Character.isWhitespace(c)||Character.isISOControl(c)){
  gender.setEditable(true);
  } else{gender.setEditable(false);}       // TODO add your handling code here:
            // TODO add your handling code here:
    }//GEN-LAST:event_genderKeyPressed

    private void addressKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_addressKeyPressed
char c=evt.getKeyChar();
  if(Character.isLetter(c)||Character.isWhitespace(c)||Character.isISOControl(c)){
  address.setEditable(true);
  } else{address.setEditable(false);}       // TODO add your handling code here:
            // TODO add your handling code here:
    }//GEN-LAST:event_addressKeyPressed

    private void phoneKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_phoneKeyPressed
char c=evt.getKeyChar();
  if(Character.isLetter(c)||Character.isWhitespace(c)||Character.isISOControl(c)){
  phone.setEditable(false);
  } else{phone.setEditable(true);}       // TODO add your handling code here:
            // TODO add your handling code here:
    }//GEN-LAST:event_phoneKeyPressed
    
    
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Passengers().setLayout(null);
                new Passengers().setLocationRelativeTo(null);
                new Passengers().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField address;
    private javax.swing.JButton back;
    private javax.swing.JButton delete;
    private javax.swing.JButton edit;
    private javax.swing.JTextField fname;
    private javax.swing.JTextField gender;
    private javax.swing.JLabel id;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel lbimage;
    private javax.swing.JTextField nationality;
    private javax.swing.JTable passen;
    private javax.swing.JTextField passportNo;
    private javax.swing.JTextField phone;
    private javax.swing.JButton save;
    private javax.swing.JButton search;
    private org.jdatepicker.impl.UtilDateModel utilDateModel1;
    // End of variables declaration//GEN-END:variables

    
}
