package project;

import java.sql.DriverManager;
import java.sql.*;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;

public class ManageFlight extends javax.swing.JFrame {
private Connection con;
private PreparedStatement smt;
private ResultSet result;
private Statement st;
String path,user,password;
    public ManageFlight() {
        initComponents();
    }
    public void returnFlight(){
    try{
        con=null;
        smt=null;
        result=null;
        user="root";
        path="jdbc:mysql://localhost:3306/airlines";
        password="";
        Class.forName("com.mysql.jdbc.Driver");
             con = DriverManager.getConnection(path, user, password);
             st=con.createStatement();
             result=st.executeQuery("select * from flights");
             table.setModel(DbUtils.resultSetToTableModel(result));
    }  catch(Exception ex){
         JOptionPane.showMessageDialog(null,ex.getMessage(),"Error Message",JOptionPane.ERROR_MESSAGE);}
    
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPopupMenu1 = new javax.swing.JPopupMenu();
        jDatePickerUtil1 = new org.jdatepicker.util.JDatePickerUtil();
        dateChooserDialog1 = new datechooser.beans.DateChooserDialog();
        dateChooserDialog2 = new datechooser.beans.DateChooserDialog();
        dateChooserDialog3 = new datechooser.beans.DateChooserDialog();
        jPanel1 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        code = new javax.swing.JTextField();
        destination = new javax.swing.JComboBox<>();
        source = new javax.swing.JComboBox<>();
        seats = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        save = new javax.swing.JButton();
        back = new javax.swing.JButton();
        delete = new javax.swing.JButton();
        edit = new javax.swing.JButton();
        tickdate = new datechooser.beans.DateChooserCombo();
        jButton2 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        jButton3 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 102));
        setLocation(new java.awt.Point(0, 0));
        setResizable(false);
        setSize(new java.awt.Dimension(1082, 660));

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(51, 153, 255));
        jLabel7.setText("source");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 230, -1, 33));

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(51, 153, 255));
        jLabel4.setText("Destination");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 330, -1, -1));

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 102, 255));
        jLabel5.setText("TicketDate");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 440, -1, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 102, 255));
        jLabel6.setText("Seats");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 550, -1, -1));
        jPanel1.add(code, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 140, 188, 40));

        destination.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        destination.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "destination", "India", "Canada", "England", "Switzerland", "Poland", "Germany", "Ukraine", "Russia", "Uganda", "Kenya", "Tanzania", "Congo", "CAR", "Gabon", "Rwanda", "Burundi", "Niger", "Nigeria", "Mali", "Togo" }));
        jPanel1.add(destination, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 320, 188, 49));

        source.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        source.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "source", "Uganda", "Kenya", "Tanzania", "Congo", "CAR", "Gabon", "Rwanda", "Burundi", "Niger", "Nigeria", "Mali", "Togo", " " }));
        jPanel1.add(source, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 230, 188, 40));

        seats.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                seatsKeyPressed(evt);
            }
        });
        jPanel1.add(seats, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 540, 180, 42));

        jPanel2.setBackground(new java.awt.Color(204, 204, 255));

        save.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        save.setForeground(new java.awt.Color(51, 153, 255));
        save.setIcon(new javax.swing.ImageIcon("C:\\Users\\This Pc\\Pictures\\Saved Pictures\\saved.jpg")); // NOI18N
        save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveActionPerformed(evt);
            }
        });

        back.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        back.setForeground(new java.awt.Color(0, 102, 255));
        back.setIcon(new javax.swing.ImageIcon("C:\\Users\\This Pc\\Pictures\\Saved Pictures\\back.jpg")); // NOI18N
        back.setText("Back");
        back.setToolTipText("go back");
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });

        delete.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        delete.setForeground(new java.awt.Color(0, 102, 255));
        delete.setIcon(new javax.swing.ImageIcon("C:\\Users\\This Pc\\Pictures\\Saved Pictures\\delete.png")); // NOI18N
        delete.setText("Delete");
        delete.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                deleteMouseClicked(evt);
            }
        });
        delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteActionPerformed(evt);
            }
        });

        edit.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        edit.setForeground(new java.awt.Color(0, 153, 255));
        edit.setIcon(new javax.swing.ImageIcon("C:\\Users\\This Pc\\Pictures\\Saved Pictures\\edit.png")); // NOI18N
        edit.setText("Edit");
        edit.setToolTipText("edit records");
        edit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                editMouseClicked(evt);
            }
        });
        edit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(save, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(81, 81, 81)
                .addComponent(edit, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(171, 171, 171)
                .addComponent(delete)
                .addGap(109, 109, 109)
                .addComponent(back, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(26, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(save)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(delete, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(edit, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(back, javax.swing.GroupLayout.DEFAULT_SIZE, 47, Short.MAX_VALUE))
                        .addContainerGap())))
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 610, 860, 60));

        tickdate.setCalendarBackground(new java.awt.Color(153, 153, 153));
        jPanel1.add(tickdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 430, 180, 42));

        jButton2.setFont(new java.awt.Font("Tempus Sans ITC", 1, 24)); // NOI18N
        jButton2.setForeground(new java.awt.Color(0, 102, 255));
        jButton2.setText("Show Flights");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 130, -1, 50));

        table.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        table.setToolTipText("List of flights");
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(table);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(318, 220, 560, 370));

        jButton3.setFont(new java.awt.Font("Tempus Sans ITC", 1, 24)); // NOI18N
        jButton3.setForeground(new java.awt.Color(0, 102, 255));
        jButton3.setIcon(new javax.swing.ImageIcon("C:\\Users\\This Pc\\Pictures\\Saved Pictures\\printers.PNG")); // NOI18N
        jButton3.setText("Print");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 130, -1, 50));

        jLabel1.setBackground(new java.awt.Color(255, 204, 0));
        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setText("Manage Flights");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 70, 181, -1));

        jLabel9.setFont(new java.awt.Font("Perpetua Titling MT", 1, 40)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 204, 0));
        jLabel9.setText("derrick airlines");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 10, -1, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 102, 255));
        jLabel3.setText("Flight code");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 140, -1, -1));

        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\This Pc\\Pictures\\Saved Pictures\\air1.PNG")); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 690));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(262, 262, 262))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        try{
            table.print(JTable.PrintMode.NORMAL);
        }catch(Exception e){

        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void tableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableMouseClicked
        DefaultTableModel model=(DefaultTableModel)table.getModel();
        int mytable=table.getSelectedRow();
        key=Integer.valueOf(model.getValueAt(mytable, 0).toString());
        code.setText(model.getValueAt(mytable, 1).toString());
        source.setSelectedItem(model.getValueAt(mytable, 2).toString());
        destination.setSelectedItem(model.getValueAt(mytable, 3).toString());
        tickdate.setText(model.getValueAt(mytable, 4).toString());
        seats.setText(model.getValueAt(mytable, 5).toString());

    }//GEN-LAST:event_tableMouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:

        returnFlight();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void editActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editActionPerformed
        // TODO add your handling code here
        if(key==0){
            JOptionPane.showMessageDialog(null, "select a passenger column to edit", "Error message", JOptionPane.ERROR_MESSAGE);
        }else{
            try{

                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(path, user, password);
                String updatequery="update flights set flightcode=?,source=?,destination=?,ticketdate=?,seats=? where id=? ";
                smt=con.prepareStatement(updatequery);
                smt.setInt(6, key);
                smt.setString(1, code.getText());
                smt.setString(2, source.getSelectedItem().toString());
                smt.setString(3, destination.getSelectedItem().toString());
                smt.setString(4, tickdate.getText());
                smt.setString(5, seats.getText());
                smt.executeUpdate();
                JOptionPane.showMessageDialog(null, "Flight Updated successfully","Success message",JOptionPane.INFORMATION_MESSAGE);

            }catch(SQLException ex){
                JOptionPane.showMessageDialog(null, ex.getMessage());
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Passengers.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
        Clear();

    }//GEN-LAST:event_editActionPerformed

    private void editMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_editMouseClicked
        // TODO add your handling code here:
        if(key==0){
            JOptionPane.showMessageDialog(null, "select a flight", "Error message", JOptionPane.ERROR_MESSAGE);
        }else{
            try{

                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(path, user, password);
                String updatequery="update flights set flightcode=?,source=?,destination=?,tickdate=?,seats=? where id=? ";

                smt=con.prepareStatement(updatequery);
                smt.setInt(6, key);
                smt.setString(1, code.getText());
                smt.setString(2, source.getSelectedItem().toString());
                smt.setString(3, destination.getSelectedItem().toString());
                smt.setString(4, tickdate.getText());
                smt.setString(5, seats.getText());
                smt.executeUpdate();
                JOptionPane.showMessageDialog(null, "flight updated","Success message",JOptionPane.INFORMATION_MESSAGE);
                returnFlight();
            }catch(SQLException ex){
                JOptionPane.showMessageDialog(null, ex.getMessage());
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Passengers.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
    }//GEN-LAST:event_editMouseClicked

    private void deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_deleteActionPerformed

    private void deleteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_deleteMouseClicked
        // TODO add your handling code here:
        if(key==0){
            JOptionPane.showMessageDialog(this, "please select a passenger");
        }else{
            try{
                con=null;
                smt=null;
                result=null;
                user="root";
                path="jdbc:mysql://localhost:3306/airlines";
                password="";
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(path, user, password);
                String query="delete from flights where id="+key;
                Statement dele=con.createStatement();
                dele.executeUpdate(query);
                JOptionPane.showMessageDialog(this, "flight deleted","Success Message",JOptionPane.INFORMATION_MESSAGE);
            }catch(Exception e){
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
        }

    }//GEN-LAST:event_deleteMouseClicked

    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
        // TODO add your handling code here:
        Flight fly = new Flight();
        fly.setVisible(true);
        fly.setLocationRelativeTo(null);
        this.dispose();

    }//GEN-LAST:event_backActionPerformed

    private void saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveActionPerformed
        // TODO add your handling code here:
        con=null;
        smt=null;
        user="root";
        path="jdbc:mysql://localhost:3306/airlines";
        password="";
        String coded=code.getText().trim();
        String ticket=tickdate.getText().trim();
        String seat=seats.getText().trim();

        if(coded.isEmpty()){
            JOptionPane.showMessageDialog(null, "code cannot be empty", "Error message", JOptionPane.ERROR_MESSAGE);
            code.requestFocus();
        }
        if(coded.length()<3){
            JOptionPane.showMessageDialog(null, "code length cannot be less than three characters", "Error message", JOptionPane.ERROR_MESSAGE);
            code.requestFocus();
        }

        if(source.getSelectedItem().toString()=="source"){
            JOptionPane.showMessageDialog(null, "Where are you coming from?", "Error message", JOptionPane.ERROR_MESSAGE);
        }
        if(destination.getSelectedItem().toString()=="destination"){
            JOptionPane.showMessageDialog(null, "Where are you going?", "Error message", JOptionPane.ERROR_MESSAGE);
        }

        if(ticket.isEmpty()){
            JOptionPane.showMessageDialog(null, "fill in the ticket date", "Error message", JOptionPane.ERROR_MESSAGE);
        }
        if(seat.isEmpty()){
            JOptionPane.showMessageDialog(null, "How many seats are you booking", "Error message", JOptionPane.ERROR_MESSAGE);
        }

        try{

            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(path, user, password);
            String insert_query="INSERT INTO flights( flightcode, source,destination,ticketdate,seats) VALUES (?,?,?,?,?)";
            smt=con.prepareStatement(insert_query);
            smt.setString(1, code.getText());
            smt.setString(2, source.getSelectedItem().toString());
            smt.setString(3, destination.getSelectedItem().toString());
            smt.setString(4, tickdate.getText());
            smt.setString(5, seats.getText());
            smt.executeUpdate();
            JOptionPane.showMessageDialog(null, "flight recorded","Success message",JOptionPane.INFORMATION_MESSAGE);

        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, ex.getMessage());
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Passengers.class.getName()).log(Level.SEVERE, null, ex);
        }
        Clear();
        returnFlight();
    }//GEN-LAST:event_saveActionPerformed

    private void seatsKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_seatsKeyPressed
        char c=evt.getKeyChar();
        if(Character.isLetter(c)||Character.isWhitespace(c)||Character.isISOControl(c)){
            seats.setEditable(false);
        } else{seats.setEditable(true);}       // TODO add your handling code here:
        // TODO add your handling code here:
    }//GEN-LAST:event_seatsKeyPressed
private void Clear(){
        code.getText();
        destination.setSelectedItem("");
        source.setSelectedItem("");
       seats.setText("");
        tickdate.setText("");
        code.requestFocus();

}int key=0;
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ManageFlight().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton back;
    private javax.swing.JTextField code;
    private datechooser.beans.DateChooserDialog dateChooserDialog1;
    private datechooser.beans.DateChooserDialog dateChooserDialog2;
    private datechooser.beans.DateChooserDialog dateChooserDialog3;
    private javax.swing.JButton delete;
    private javax.swing.JComboBox<String> destination;
    private javax.swing.JButton edit;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private org.jdatepicker.util.JDatePickerUtil jDatePickerUtil1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPopupMenu jPopupMenu1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton save;
    private javax.swing.JTextField seats;
    private javax.swing.JComboBox<String> source;
    private javax.swing.JTable table;
    private datechooser.beans.DateChooserCombo tickdate;
    // End of variables declaration//GEN-END:variables
}
