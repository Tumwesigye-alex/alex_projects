package project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;


public class Ticketbooking extends javax.swing.JFrame {

private Connection con;
private ResultSet result;
private PreparedStatement smt;
private Statement st;
private String path,user,password;
    public Ticketbooking() {
        initComponents();
        getPassengers();
        getFlight();
        
        con=null;
        smt=null;
        result=null;
        user="root";
        path="jdbc:mysql://localhost:3306/airlines";
        password="";
    }
    
public void returnBookings(){
    try{
        con=null;
        smt=null;
        result=null;
        user="root";
        path="jdbc:mysql://localhost:3306/airlines";
        password="";
        Class.forName("com.mysql.jdbc.Driver");
             con = DriverManager.getConnection(path, user, password);
             st=con.createStatement();
             result=st.executeQuery("select * from bookings");
             passen.setModel(DbUtils.resultSetToTableModel(result));
    }  catch(Exception ex){
         JOptionPane.showMessageDialog(null,ex.getMessage(),"Error Message",JOptionPane.ERROR_MESSAGE);}
    
    }

public void getPassengers(){
    try{
        con=null;
        smt=null;
        result=null;
        st=null;
        user="root";
        path="jdbc:mysql://localhost:3306/airlines";
        password="";
        Class.forName("com.mysql.jdbc.Driver");
             con = DriverManager.getConnection(path, user, password);
             st=con.createStatement();
             String Query ="select * from passengers";
           result=st.executeQuery(Query);
           while(result.next()){
           String pid=String.valueOf(result.getInt("pid"));
          // pasId.addItem(pid);
           }
    }  catch(Exception ex){
         JOptionPane.showMessageDialog(null,ex.getMessage(),"Error Message",JOptionPane.ERROR_MESSAGE);}
    
    }
private void getPassengerData(){
String myworry="select * from customerbookings where passportNo='"+passportNo.getText()+"'";
     con=null;
     
      ResultSet  r=null;
      Statement st=null;
        user="root";
        path="jdbc:mysql://localhost:3306/airlines";
        password="";
        
try{
Class.forName("com.mysql.jdbc.Driver");

con = DriverManager.getConnection(path, user, password);
st=con.createStatement();
r=st.executeQuery(myworry);
if(r.next()){
passportNo.setText(r.getString("passportNo"));
genders.setText(r.getString("gender"));
fname.setText(r.getString("Name"));
nation.setText(r.getString("destination"));
}

}catch(Exception e){


}
}
public void getFlight(){
    try{
        con=null;
        smt=null;
        result=null;
        st=null;
        user="root";
        path="jdbc:mysql://localhost:3306/airlines";
        password="";
        Class.forName("com.mysql.jdbc.Driver");
             con = DriverManager.getConnection(path, user, password);
             st=con.createStatement();
             String Query ="select * from flights";
           result=st.executeQuery(Query);
           while(result.next()){
           String fcode=result.getString("flightcode");
           code.addItem(fcode);
           }
    }  catch(Exception ex){
         JOptionPane.showMessageDialog(null,ex.getMessage(),"Error Message",JOptionPane.ERROR_MESSAGE);}
    
    }
private void checkExisting(){
 try{
        con=null;
        smt=null;
        result=null;
        user="root";
        path="jdbc:mysql://localhost:3306/airlines";
        password="";
        Class.forName("com.mysql.jdbc.Driver");
        String expass=result.getString("passportNo");
             con = DriverManager.getConnection(path, user, password);
             st=con.createStatement();
             result=st.executeQuery("select * from bookings where passportNo='"+expass+"'");
             if(result.next()){
             JOptionPane.showMessageDialog(this, "user already exists");
             }else{
             JOptionPane.showMessageDialog(this, "new user");
             }
             
    }  catch(Exception ex){
         JOptionPane.showMessageDialog(null,ex.getMessage(),"Error Message",JOptionPane.ERROR_MESSAGE);}
    

}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        utilCalendarModel1 = new org.jdatepicker.impl.UtilCalendarModel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        amount = new javax.swing.JTextField();
        genders = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        book = new javax.swing.JButton();
        back = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        passen = new javax.swing.JTable();
        fname = new javax.swing.JTextField();
        nation = new javax.swing.JTextField();
        code = new javax.swing.JComboBox<>();
        jLabel11 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        passportNo = new javax.swing.JTextField();
        search = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(102, 102, 255));
        setPreferredSize(new java.awt.Dimension(1060, 737));
        setResizable(false);
        setSize(new java.awt.Dimension(1060, 737));
        getContentPane().setLayout(null);

        jLabel2.setFont(new java.awt.Font("Perpetua", 1, 30)); // NOI18N
        jLabel2.setText("Ticket Booking");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(430, 80, 196, 35);

        jLabel3.setBackground(new java.awt.Color(204, 204, 255));
        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(51, 153, 255));
        jLabel3.setText("PassportNo");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(10, 146, 81, 33);

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(51, 153, 255));
        jLabel4.setText("Code");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(10, 340, 98, 33);

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(51, 153, 255));
        jLabel5.setText("Name");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(10, 240, 98, 33);

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(51, 153, 255));
        jLabel6.setText("Amount");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(0, 510, 98, 33);

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 153, 255));
        jLabel8.setText("Gender");
        getContentPane().add(jLabel8);
        jLabel8.setBounds(10, 430, 98, 33);

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(51, 153, 255));
        jLabel9.setText("Destination");
        getContentPane().add(jLabel9);
        jLabel9.setBounds(0, 590, 98, 33);

        amount.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        amount.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                amountActionPerformed(evt);
            }
        });
        amount.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                amountKeyPressed(evt);
            }
        });
        getContentPane().add(amount);
        amount.setBounds(110, 510, 210, 39);

        genders.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        genders.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gendersActionPerformed(evt);
            }
        });
        genders.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                gendersKeyPressed(evt);
            }
        });
        getContentPane().add(genders);
        genders.setBounds(120, 430, 204, 39);

        jPanel1.setBackground(new java.awt.Color(204, 204, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.setForeground(new java.awt.Color(0, 153, 255));

        book.setBackground(new java.awt.Color(204, 204, 255));
        book.setFont(new java.awt.Font("Tahoma", 3, 16)); // NOI18N
        book.setForeground(new java.awt.Color(0, 51, 204));
        book.setText("Book");
        book.setActionCommand("");
        book.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bookMouseClicked(evt);
            }
        });
        book.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bookActionPerformed(evt);
            }
        });

        back.setBackground(new java.awt.Color(204, 204, 255));
        back.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        back.setForeground(new java.awt.Color(0, 102, 255));
        back.setIcon(new javax.swing.ImageIcon("C:\\Users\\This Pc\\Pictures\\Saved Pictures\\back.jpg")); // NOI18N
        back.setText("Back");
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });

        jButton3.setBackground(new java.awt.Color(204, 204, 255));
        jButton3.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jButton3.setForeground(new java.awt.Color(0, 0, 204));
        jButton3.setText("Print ticket");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(book, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 276, Short.MAX_VALUE)
                .addComponent(jButton3)
                .addGap(221, 221, 221)
                .addComponent(back, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(116, 116, 116))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(back, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(book, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        getContentPane().add(jPanel1);
        jPanel1.setBounds(20, 640, 1010, 64);

        passen.setBackground(new java.awt.Color(204, 204, 255));
        passen.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        passen.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        passen.setSelectionBackground(new java.awt.Color(204, 204, 255));
        passen.setSelectionForeground(new java.awt.Color(0, 51, 255));
        passen.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                passenMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(passen);

        getContentPane().add(jScrollPane2);
        jScrollPane2.setBounds(330, 220, 700, 410);

        fname.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        fname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fnameActionPerformed(evt);
            }
        });
        getContentPane().add(fname);
        fname.setBounds(120, 240, 204, 39);

        nation.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        nation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nationActionPerformed(evt);
            }
        });
        nation.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                nationKeyPressed(evt);
            }
        });
        getContentPane().add(nation);
        nation.setBounds(110, 590, 210, 39);

        code.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        code.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "select flightcode" }));
        getContentPane().add(code);
        code.setBounds(120, 330, 204, 39);

        jLabel11.setFont(new java.awt.Font("Perpetua Titling MT", 1, 40)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 204, 0));
        jLabel11.setText("Derrick airlines");
        getContentPane().add(jLabel11);
        jLabel11.setBounds(330, 10, 420, 50);

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton1.setForeground(new java.awt.Color(51, 102, 255));
        jButton1.setText("View Bookings");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(544, 137, 190, 48);

        jButton2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton2.setForeground(new java.awt.Color(0, 51, 255));
        jButton2.setIcon(new javax.swing.ImageIcon("C:\\Users\\This Pc\\Pictures\\Saved Pictures\\printers.PNG")); // NOI18N
        jButton2.setText("Print");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2);
        jButton2.setBounds(777, 137, 126, 48);

        passportNo.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        passportNo.setForeground(new java.awt.Color(255, 0, 0));
        passportNo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                passportNoMouseReleased(evt);
            }
        });
        passportNo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passportNoActionPerformed(evt);
            }
        });
        getContentPane().add(passportNo);
        passportNo.setBounds(115, 145, 204, 39);

        search.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        search.setForeground(new java.awt.Color(51, 102, 255));
        search.setText("search");
        search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchActionPerformed(evt);
            }
        });
        getContentPane().add(search);
        search.setBounds(390, 140, 110, 48);

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\This Pc\\Pictures\\Saved Pictures\\aero.jpg")); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(0, 10, 1040, 740);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void amountActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_amountActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_amountActionPerformed

    private void gendersActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gendersActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_gendersActionPerformed

    private void bookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bookActionPerformed
    
            
    }//GEN-LAST:event_bookActionPerformed
int key=0;
    private void passenMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_passenMouseClicked
   DefaultTableModel model=(DefaultTableModel)passen.getModel();
        int mytable=passen.getSelectedRow();
        key=Integer.valueOf(model.getValueAt(mytable, 0).toString());
        fname.setText(model.getValueAt(mytable, 1).toString());
        code.setSelectedItem(model.getValueAt(mytable, 2).toString());
        genders.setText(model.getValueAt(mytable, 3).toString());
        passportNo.setText(model.getValueAt(mytable, 4).toString());
        amount.setText(model.getValueAt(mytable, 5).toString());
        nation.setText(model.getValueAt(mytable, 6).toString());
           
    }//GEN-LAST:event_passenMouseClicked

    private void bookMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bookMouseClicked
        // TODO add your handling code here:
        if(passportNo.getText().trim().isEmpty()){
        JOptionPane.showMessageDialog(null, "Please select an ID", "Error message", JOptionPane.ERROR_MESSAGE);
        passportNo.requestFocus();
        }
        else if(passportNo.getText().trim().isEmpty()){
        JOptionPane.showMessageDialog(null, "first name cannot be empty", "Error message", JOptionPane.ERROR_MESSAGE);
        passportNo.requestFocus();
        }
        else if(passportNo.getText().trim().length()<3){
        JOptionPane.showMessageDialog(null, "first name cannot be less than three characters", "Error message", JOptionPane.ERROR_MESSAGE);
        passportNo.requestFocus();
        }
        else if(code.getSelectedItem().toString()=="select flightcode"){
        JOptionPane.showMessageDialog(null, "Please select the flight code corresponding to the is", "Error message", JOptionPane.ERROR_MESSAGE);
        code.requestFocus();
         }
        
        else if(genders.getText().trim().isEmpty()){
        JOptionPane.showMessageDialog(null, "gender field cannot be empty", "Error message", JOptionPane.ERROR_MESSAGE);
        genders.requestFocus();
        }
        else if(fname.getText().trim().isEmpty()){
        JOptionPane.showMessageDialog(null, "Tell talex airlines your address", "Error message", JOptionPane.ERROR_MESSAGE);
        fname.requestFocus();
        }
        else if(amount.getText().trim().isEmpty()){
        JOptionPane.showMessageDialog(null, "Please provide your phone number", "Error message", JOptionPane.ERROR_MESSAGE);
        }
        else if(nation.getText().trim().isEmpty()){
        JOptionPane.showMessageDialog(null, "Please provide your phone number", "Error message", JOptionPane.ERROR_MESSAGE);
        }else{
         try{
             con=null;
        smt=null;
        result=null;
        st=null;
        user="root";
        path="jdbc:mysql://localhost:3306/airlines";
        password="";
            Class.forName("com.mysql.jdbc.Driver");
             con = DriverManager.getConnection(path, user, password);
            String insert_query="INSERT INTO bookings( name,code,gender,passportNo,amount,destination) VALUES (?,?,?,?,?,?)";
            smt=con.prepareStatement(insert_query);
//            int a=Integer.parseInt(pasId.getText());
//            smt.setInt(1, a);
           // smt.setInt(7, key);
            smt.setString(1, fname.getText());
            smt.setString(2, code.getSelectedItem().toString());
            smt.setString(3, genders.getText());
            smt.setString(4, passportNo.getText());
            smt.setString(5, amount.getText());
            smt.setString(6, nation.getText());
            smt.executeUpdate();
            JOptionPane.showMessageDialog(null, "You have successfully booked with us","Success message",JOptionPane.INFORMATION_MESSAGE);
            
            }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, ex.getMessage());
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Passengers.class.getName()).log(Level.SEVERE, null, ex);
            }
         Clear();
        
        }
    }//GEN-LAST:event_bookMouseClicked

    private void fnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fnameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fnameActionPerformed

    private void nationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nationActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nationActionPerformed
/**
 * <h2>This method clears the form</h2>
 * @param args takes on the arguments of the method
 */
    private void Clear(){
        passportNo.setText("");
        code.setSelectedIndex(0);
        nation.setText("");
        fname.setText("");
        genders.setText("");
        passportNo.setText("");
        amount.setText("");
        passportNo.requestFocus();

}
    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
        // TODO add your handling code here:
        new Flight().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_backActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        returnBookings();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        try{
        passen.print(JTable.PrintMode.NORMAL);
        }catch(Exception e){}
    }//GEN-LAST:event_jButton2ActionPerformed

    private void passportNoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passportNoActionPerformed
        // TODO add your handling code here:
        getPassengerData();
    }//GEN-LAST:event_passportNoActionPerformed

    private void passportNoMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_passportNoMouseReleased
        // TODO add your handling code here:
        getPassengerData();
    }//GEN-LAST:event_passportNoMouseReleased

    private void searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchActionPerformed
//checkExisting();        // TODO add your handling code here:
        getPassengerData();
    }//GEN-LAST:event_searchActionPerformed

    private void gendersKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_gendersKeyPressed
char c=evt.getKeyChar();
  if(Character.isLetter(c)||Character.isWhitespace(c)||Character.isISOControl(c)){
  genders.setEditable(true);
  } else{genders.setEditable(false);}       // TODO add your handling code here:
            // TODO add your handling code here:
    }//GEN-LAST:event_gendersKeyPressed

    private void amountKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_amountKeyPressed
char c=evt.getKeyChar();
  if(Character.isLetter(c)||Character.isWhitespace(c)||Character.isISOControl(c)){
  amount.setEditable(false);
  } else{amount.setEditable(true);}       // TODO add your handling code here:
            // TODO add your handling code here:
    }//GEN-LAST:event_amountKeyPressed

    private void nationKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nationKeyPressed
char c=evt.getKeyChar();
  if(Character.isLetter(c)||Character.isWhitespace(c)||Character.isISOControl(c)){
  nation.setEditable(true);
  } else{nation.setEditable(false);}       // TODO add your handling code here:
            // TODO add your handling code here:
    }//GEN-LAST:event_nationKeyPressed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        ticketprint print =new ticketprint();
        print.setTitle("CLIENTS TICKET");
        print.setLayout(null);
        print.setLocationRelativeTo(null);
        print.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton3ActionPerformed

    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Ticketbooking().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField amount;
    private javax.swing.JButton back;
    private javax.swing.JButton book;
    private javax.swing.JComboBox<String> code;
    private javax.swing.JTextField fname;
    private javax.swing.JTextField genders;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField nation;
    private javax.swing.JTable passen;
    private javax.swing.JTextField passportNo;
    private javax.swing.JButton search;
    private org.jdatepicker.impl.UtilCalendarModel utilCalendarModel1;
    // End of variables declaration//GEN-END:variables

}
