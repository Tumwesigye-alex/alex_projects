 <footer>
            <p>&copy All reserved to  Tumwesigye Alex <br> <marquee>DIRECTOR TALEX</marquee></p>
        </footer>