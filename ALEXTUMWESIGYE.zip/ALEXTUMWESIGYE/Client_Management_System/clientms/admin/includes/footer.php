 <footer>
            <p>&copy All rights reserved to TUMWESIGYE ALEX<br><marquee>DIRECTOR TALEX</marquee></p>
        </footer>