// SIDEBAR TOGGLE
var sidebarOpen = false;
var sidebar = document.getElementById("sidebar");

function openSidebar() {
  if(!sidebarOpen) {
    sidebar.classList.add("sidebar-responsive");
    sidebarOpen = true;
  }
}

function closeSidebar() {
  if(sidebarOpen) {
    sidebar.classList.remove("sidebar-responsive");
    sidebarOpen = false;
  }
}



// DISABLE BROWSER BUTTONS
function disableBrowserNavigation(){
  history.pushState(null, null, location.href);
  window.addEventListener('popstate', function(){
      history.pushState(null, null, location.href);
  });
}

// MODAL
var modal = document.getElementById('inventory');
// When the user clicks anywhere outside of the modal, close the modal
window.onclick = function(event) {
  if(event.target == modal){
    modal.style.display = "none";
  }
}
// FADE MODAL ON CLICK CLOSE
// let modalfade = document.getElementById('close');
// window.onclick = function(e){
//   if(e.target == modalfade){
//     classList.querySelector('.fade-modal')
//   }
// }