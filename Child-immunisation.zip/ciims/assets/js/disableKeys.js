// @Author: Mutatiina Brutas
// @copyright 2023
// @Version V1.01
// ---------------------------------------

document.onkeydown =((e)=>{
    if(e.ctrlKey && e.which==83){
        e.preventDefault()
        // alert('Ctrl + S was pressed')
    }else{
        if (e.ctrlKey && e.which==80) {
            e.preventDefault()
            // alert('Ctrl + P was pressed')
        }
    }
})