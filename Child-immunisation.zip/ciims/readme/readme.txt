Admin
edit profile
update photo
reset password
reset user password
deactivate user status
generate reports
export user list as excel
export user list as pdf
export userlogs as excel
export uerlogs as pdf
export vaccines as pdf
export vaccines as excel
export child register as excel
export child register as pdf
export immunisation register as excel
export immunisation register as pdf
search child details on child register
search child details on immunisation register
disable childs status
dashboard upcoming visits
view childs certificate of birth
download childs certificate of birth as pdf
view childs certificate of immunisation
download childs certificate of immunisation as pdf
add health complication upon registering a child
add support ticket upon registering a child
generate NIN upon registering a child
add mothers nin upon registering a child
add fathers nin upon registering a child
customise color from the UI
customise fonts from the UI
track continent and others on login
validate register vaccine
restructure sysinfo page
restructure my account page

Nurse
edit profile
update photo
update contact info
search child details
generate immunisation reports
print child ref cheat
download child register as excel
export child register as pdf
dashboard upcoming visits
export immunisation register as excel
export immunisation register as pdf
nurse to view all children of one mother at one time
view childs certificate of birth
download childs certificate of birth as pdf
view childs certificate of immunisation
download childs certificate of immunisation as pdf
add health complication upon registering a child
generate NIN upon registering a child
add mothers nin upon registering a child
add fathers nin upon registering a child
add other vaccine upon immunisation
add short notes upon immunisation
customise color from the UI
customise fonts from the UI
track continent and others on login
validate register vaccine
validate empty field onclick button on generate immunisation report
validate empty field onclick button on generate reference cheat
restructure sysinfo page

Parent
dashboard upcoming visits
edit profile
update contact info
search child details
track parents login device details
view childs certificate of birth
download childs certificate of birth as pdf
view childs certificate of immunisation
download childs certificate of immunisation as pdf
view all child details if a mother has more than one child
update userlogs table on logout
create website

retrieve child's health, any other vaccine

Note
test all system components
remove page extensions
hide id from url
restructure sysinfo page
add dismisable alerts
add badges to feedback
add push notifications
add children born today, yesterday, this week, last week, this month, this year, and last year
validate generated support ticket
send birthday sms
check user registered date type
add locations
generate qr code
create a system log file
add OTP verification on signup
create a system log file
add 2FA on successful login
add login time counter on failed logins
create triggers
disable use of vpn
404 redirect
505 redirect
403 redirect
replace all code with prepared statements
auto logout user after some time of system inactivity
get MAC address on login
add send manual sms campaigns to nurse panel
add dropdowns to the sidebar