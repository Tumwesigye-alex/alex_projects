<?php
// Start Session
session_start();
error_reporting(0);
// Include Database Connection
require_once '../includes/config/database.php';
// Check if session is set to true
if(strlen($_SESSION['login'])==0){
	header("Location: ../index.php");
	exit();
}else{
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    $sql=mysqli_query($con, "SELECT * FROM sysinfo");
    while($row=mysqli_fetch_assoc($sql)){?>
    <title><?php echo $row['fullname']." | ".$row['shortname'];;?></title>
    <?php } ?>
    <!-- Bootstrap -->
    <link rel="stylesheet" href="../assets/css/bootstrap.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- Material Icons -->
    <link rel="stylesheet" href="../assets/icons/material-icons.woff2">
    <!-- Current Time JS -->
    <script type="text/javascript" src="../assets/js/dateTime.js"></script>
    <!-- Favicon -->
    <link rel="shortcut icon" href="../components/favicon/favicon.png" type="image/x-icon">
</head>
<body>
    <!-- Wrapper -->
    <div class="wrapper">
        <!-- Header Section -->
        <?php if($_SESSION['login']!=""){ require_once 'includes/navbar/navbar.php';}?>
        <!-- Sidebar -->
        <?php if($_SESSION['login']!=""){ require_once 'includes/sidebar/sidebar.php';}?>
        <!-- Right Section -->
        <div class="main-wrapper">
            <div class="container">
                <div class="row pt-2">
                    <div class="col">
                        <p class="bold blue">System Information</p>
                        <?php
                        $sql=mysqli_query($con, "SELECT * FROM sysinfo ORDER BY sysid DESC LIMIT 1");
                        while($row=mysqli_fetch_assoc($sql)){?>
                        <div class="row">
                            <div class="col">
                                <p>System Name: <?php echo $row['fullname'];?></p>
                                <p>System Short Name: <?php echo $row['shortname'];?></p>
                                <p>Email: <?php echo $row['email'];?></p>
                                <p>Phone Number: <?php $ctrycode='+256'; $space=' '; $result=$row['contact']; $trimmed=substr($result,1); echo $ctrycode.$space.$trimmed;?></p>
                            </div>
                        </div>
                        <?php } ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <p>Build Year: 2023</p>
                        <p>Version: PHP V1.0</p>
                        <hr>
                        <p>Copyright &copy 2023. All rights reserved</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
<script src="../assets/js/main.js"></script>
<script src="../assets/js/disableKeys.js"></script>
</body>
</html>
<?php } ?>