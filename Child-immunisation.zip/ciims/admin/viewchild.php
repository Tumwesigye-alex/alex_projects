<?php
// Start Session
session_start();
error_reporting(0);
// Include Database Connection
require_once '../includes/config/database.php';
// Check if session is set to true
if(strlen($_SESSION['login'])==0){
	header("Location: ../index.php");
	exit();
}else{
        $childsnames=$_POST['childsnames'];
        $gender=$_POST['gender'];
        $childsdob=$_POST['childsdob'];
        $weight_at_birth=$_POST['weight_at_birth'];
        $birth_order=$_POST['birth_order'];
        $place_of_birth=$_POST['place_of_birth'];
        $mothers_names=$_POST['mothers_names'];
        $mothers_contact=$_POST['mothers_contact'];
        $mothers_occupation=$_POST['mothers_occupation'];
        $fathers_names=$_POST['fathers_names'];
        $fathers_contact=$_POST['fathers_contact'];
        $fathers_occupation=$_POST['fathers_occupation'];
        $district=$_POST['district'];
        $subcounty=$_POST['subcounty'];
        $parish=$_POST['parish'];
        $village=$_POST['village'];
    // }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    $sql=mysqli_query($con, "SELECT * FROM sysinfo");
    while($row=mysqli_fetch_assoc($sql)){?>
    <title><?php echo $row['fullname']." | ".$row['shortname'];;?></title>
    <?php } ?>
    <!-- Bootstrap -->
    <link rel="stylesheet" href="../assets/css/bootstrap.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- Material Icons -->
    <link rel="stylesheet" href="../assets/icons/material-icons.woff2">
    <!-- Current Time JS -->
    <script type="text/javascript" src="../assets/js/dateTime.js"></script>
    <!-- Favicon -->
    <link rel="shortcut icon" href="../components/favicon/favicon.png" type="image/x-icon">
</head>
<body>
    <!-- Wrapper -->
    <div class="wrapper">
        <!-- Header Section -->
        <?php if($_SESSION['login']!=""){ require_once 'includes/navbar/navbar.php';}?>
        <!-- Sidebar -->
        <?php if($_SESSION['login']!=""){ require_once 'includes/sidebar/sidebar.php';}?>
        <!-- Right Section -->
        <div class="main-wrapper">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <p class="bold blue">Child Details</p>
                        <hr>
                            <?php
                            $childsid=$_GET['regid'];
                            $sql=mysqli_query($con, "SELECT * FROM child_register WHERE regid='$childsid'");
                            while($row=mysqli_fetch_assoc($sql)){?>
                            <div class="row">
                                <div class="col-lg-4">
                                    <p><b>RegNo:</b> <?php echo $row['regno'];?></p>
                                </div>
                                <div class="col-lg-4">
                                    <p><b>Names:</b> <?php echo $row['childsnames'];?></p>
                                </div>
                                <div class="col-lg-4">
                                    <p><b>Gender:</b> <?php echo $row['gender'];?></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-4">
                                    <p><b>Date of Birth:</b> <?php echo date('D d M Y',strtotime($row['childsdob']));?></p>
                                </div>
                                <div class="col-lg-4">
                                    <p><b>Weight at Birth:</b> <?php echo $row['weight_at_birth'];?></p>
                                </div>
                                <div class="col-lg-4">
                                    <p><b>Birth Order:</b> <?php echo $row['birth_order'];?></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-4">
                                    <p><b>Place of Birth:</b> <?php echo $row['place_of_birth'];?></p>
                                </div>
                                <div class="col-lg-4">
                                    <p><b>Mother:</b> <?php echo $row['mothers_names'];?></p>
                                </div>
                                <div class="col-lg-4">
                                    <p><b>Contact:</b> <?php echo $row['mothers_contact'];?></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-4">
                                    <p><b>Occupation:</b> <?php echo $row['mothers_occupation'];?></p>
                                </div>
                                <div class="col-lg-4">
                                    <p><b>Father:</b> <?php echo $row['fathers_names'];?></p>
                                </div>
                                <div class="col-lg-4">
                                    <p><b>Contact:</b> <?php echo $row['fathers_contact'];?></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-4">
                                    <p><b>Occupation:</b> <?php echo $row['fathers_occupation'];?></p>
                                </div>
                                <div class="col-lg-4">
                                    <p><b>District:</b> <?php echo $row['district'];?></p>
                                </div>
                                <div class="col-lg-4">
                                    <p><b>Subcounty:</b> <?php echo $row['subcounty'];?></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-4">
                                    <p><b>Parish:</b> <?php echo $row['parish'];?></p>
                                </div>
                                <div class="col-lg-4">
                                    <p><b>Village:</b> <?php echo $row['village'];?></p>
                                </div>
                            </div>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<script src="../assets/js/main.js"></script>
<script src="../assets/js/disableKeys.js"></script>
</body>
</html>
<?php } ?>