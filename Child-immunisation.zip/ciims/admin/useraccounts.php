<?php
// Start Session
session_start();
error_reporting(0);
// Include Database Connection
require_once '../includes/config/database.php';
// Check if session is set to true
if(strlen($_SESSION['login'])==0){
	header("Location: ../index.php");
	exit();
}else{
    // Delete User
	if(isset($_GET['del'])){
		mysqli_query($con, "DELETE FROM users WHERE userid='".$_GET['userid']."'"); 
		$_SESSION['delmsg']="User deleted successfully";
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    $sql=mysqli_query($con, "SELECT * FROM sysinfo");
    while($row=mysqli_fetch_assoc($sql)){?>
    <title><?php echo $row['fullname']." | ".$row['shortname'];;?></title>
    <?php } ?>
    <!-- Bootstrap -->
    <link rel="stylesheet" href="../assets/css/bootstrap.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- Material Icons -->
    <link rel="stylesheet" href="../assets/icons/material-icons.woff2">
    <!-- Current Time JS -->
    <script type="text/javascript" src="../assets/js/dateTime.js"></script>
    <!-- Favicon -->
    <link rel="shortcut icon" href="../components/favicon/favicon.png" type="image/x-icon">
</head>
<body>
    <!-- Wrapper -->
    <div class="wrapper">
        <!-- Header Section -->
        <?php if($_SESSION['login']!=""){ require_once 'includes/navbar/navbar.php';}?>
        <!-- Sidebar -->
        <?php if($_SESSION['login']!=""){ require_once 'includes/sidebar/sidebar.php';}?>
        <!-- Right Section -->
        <div class="main-wrapper">
            <div class="container">
                <div class="row pt-2">
                    <div class="col">
                        <p class="blue">List of User Accounts</p>
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover" id="userlogs">
                                <thead>
                                    <tr>
                                        <th>Photo</th>
                                        <th>Surname</th>
                                        <th>Other</th>
                                        <th>Contact</th>
                                        <th>Email</th>
                                        <th>Username</th>
                                        <th>Role</th>
                                        <th>Registered</th>
                                        <th>Updated</th>
                                        <th>Status</th>
                                        <th colspan="2">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $sql=mysqli_query($con, "SELECT * FROM users");
                                    while($row=mysqli_fetch_assoc($sql)){?>
                                    <tr>
                                        <td><?php if($row['photo']==""){?><img src="../media/profile/avatar.png" alt="Profile" width="30px" height="30px"><?php }else{?><img src="../media/profile/<?php $row['photo'];?>" alt="Profile" width="30px" height="30px"><?php };?></td>
                                        <td><?php echo $row['surname'];?></td>
                                        <td><?php echo $row['lastname'];?></td>
                                        <td><?php echo $row['contact'];?></td>
                                        <td><?php echo $row['email'];?></td>
                                        <td><?php echo $row['username'];?></td>
                                        <td><?php echo $row['userrole'];?></td>
                                        <td><?php echo date('D d-M-Y H:i:s',strtotime($row['date_registered']));?></td>
                                        <td><?php echo $row['updated'];?></td>
                                        <td><?php if($row['status']==1){ echo 'Active';}else{ echo 'Inactive';};?></td>
                                        <td><a href="edituser.php?userid=<?php echo $row['userid'];?>" target="_blank"><i class="material-icons-outlined">edit</i></a></td>
                                        <td><a href="useraccounts.php?userid=<?php echo $row['userid']?>&del=DELETE" onClick="return confirm('Are you sure you want to delete this user')"><i class="material-icons-outlined">delete</i></a></td>
                                    </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="row pt-2">
                    <div class="col red">
                        <?php echo $_SESSION['delmsg'];?>
                        <?php echo $_SESSION['delmsg']="";?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<script src="../assets/js/main.js"></script>
<script src="../assets/js/disableKeys.js"></script>
</body>
</html>
<?php } ?>