<?php
// Start Session
session_start();
error_reporting(0);
// Include Database Connection
require_once '../includes/config/database.php';
// Check if session is set to true
if(strlen($_SESSION['login'])==0){
	header("Location: ../index.php");
	exit();
}else{
    // Delete vaccine
	if(isset($_GET['del'])){
		mysqli_query($con, "DELETE FROM vaccines WHERE vaccineid='".$_GET['vaccineid']."'"); 
		$_SESSION['delmsg']="Vaccine deleted successfully";
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    $sql=mysqli_query($con, "SELECT * FROM sysinfo");
    while($row=mysqli_fetch_assoc($sql)){?>
    <title><?php echo $row['fullname']." | ".$row['shortname'];;?></title>
    <?php } ?>
    <!-- Bootstrap -->
    <link rel="stylesheet" href="../assets/css/bootstrap.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- Material Icons -->
    <link rel="stylesheet" href="../assets/icons/material-icons.woff2">
    <!-- Current Time JS -->
    <script type="text/javascript" src="../assets/js/dateTime.js"></script>
    <!-- Favicon -->
    <link rel="shortcut icon" href="../components/favicon/favicon.png" type="image/x-icon">
</head>
<body>
    <!-- Wrapper -->
    <div class="wrapper">
        <!-- Header Section -->
        <?php if($_SESSION['login']!=""){ require_once 'includes/navbar/navbar.php';}?>
        <!-- Sidebar -->
        <?php if($_SESSION['login']!=""){ require_once 'includes/sidebar/sidebar.php';}?>
        <!-- Right Section -->
        <div class="main-wrapper">
            <div class="container">
                <div class="row pt-2">
                    <div class="col">
                        <p class="blue">List of Available Vaccines</p>
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover" id="vaccines">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Package</th>
                                        <th>Vaccine</th>
                                        <th>Vaccine Protects</th>
                                        <th>Administration Mode</th>
                                        <th colspan="2">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $sql=mysqli_query($con, "SELECT * FROM vaccines");
                                    $count=0;
                                    while($row=mysqli_fetch_assoc($sql)){$count++;?>
                                    <tr>
                                        <td><?php echo $count;?></td>
                                        <td><?php echo $row['vaccine_package'];?></td>
                                        <td><?php echo $row['vaccine_name'];?></td>
                                        <td><?php echo $row['vaccine_protects'];?></td>
                                        <td><?php echo $row['vaccine_admin_mode'];?></td>
                                        <td><a href="editvaccine.php?vaccineid=<?php echo $row['vaccineid'];?>" target="_blank"><i class="material-icons-outlined">edit</i></a></td>
                                        <td><a href="vaccines.php?vaccineid=<?php echo $row['vaccineid'];?>&del=DELETE" onclick="return confirm('Are you sure you want to delete this vaccine')"><i class="material-icons-outlined">delete</i></a></td>
                                    </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="row pt-4">
                    <div class="col red">
                        <?php echo $_SESSION['delmsg'];?>
                        <?php echo $_SESSION['delmsg']='';?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<script src="../assets/js/main.js"></script>
<script src="../assets/js/disableKeys.js"></script>
</body>
</html>
<?php } ?>