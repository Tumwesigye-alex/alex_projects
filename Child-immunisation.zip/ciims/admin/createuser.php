<?php
// Start Session
session_start();
error_reporting(0);
// Include Database Connection
require_once '../includes/config/database.php';
// Check if session is set to true
if(strlen($_SESSION['login'])==0){
	header("Location: ../index.php");
	exit();
}else{
    if(isset($_POST['submit'])){
        $surname=$_POST['surname'];
        $lastname=$_POST['lastname'];
        $contact=$_POST['contact'];
        $username=$_POST['username'];
        $userrole=$_POST['userrole'];
        $email=$_POST['email'];
        // Auto Generate Password
        $characters='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()-_';
        $password_length=8;
        $genpassword='';
        $charLength=strlen($characters)-1;
        for($i = 0; $i < $password_length; $i++){
            $genpassword .= $characters[rand(0, $charLength)];
            $hashedpassword=MD5($genpassword);
        }

        $sql=mysqli_query($con, "SELECT * FROM users WHERE username='$username'");
        if(mysqli_num_rows($sql)>0){
            $_SESSION['msg']='User with this username '.$username.' already exists. Please choose another username';
        }else{
            if(empty($_POST['surname'])){
                $_SESSION['msg']='Please fill all fields !!';
            }
            elseif(isset($_POST['surname'])){
                $surname=filter_var($_POST['surname'], FILTER_SANITIZE_STRING);
                if(isset($_POST['lastname'])){
                    $lastname=filter_var($_POST['lastname'], FILTER_SANITIZE_STRING);
                }
                if(isset($_POST['contact'])){
                    $contact=filter_var($_POST['contact'], FILTER_SANITIZE_STRING);
                }
                if(isset($_POST['username'])){
                    $username=filter_var($_POST['username'], FILTER_SANITIZE_STRING);
                }
                if(isset($_POST['userrole'])){
                    $userrole=filter_var($_POST['userrole'], FILTER_SANITIZE_STRING);
                }
                if(isset($_POST['email'])){
                    $email=filter_var(strtolower($_POST['email']), FILTER_VALIDATE_EMAIL);
                }
                if(isset($_POST['password'])){
                    $password=filter_var($_POST['password'], FILTER_SANITIZE_STRING);
                }
            }
            $query=mysqli_query($con, "INSERT INTO users(surname, lastname, contact, username, userrole, email, password) VALUES('$surname', '$lastname', '$contact', '$username', '$userrole', '$email', '$hashedpassword')");
            if($query){
                $_SESSION['msg']='New user account created successfully and login details sent via SMS';
                // Send Login details via SMS to the provided phone number
                function SendSMS($message_type,$message_category,$number,$message){ 
                    $username='0780697787';
                    $password='0780697787bM';
                    $sender='CIIMS';
                    $url="sms.thepandoranetworks.com/API/send_sms/?";
                    $parameters="number=[number]&message=[message]&username=[username]&password=[password]&sender=[sender]&message_type=[message_type]&message_category=[message_category]";
                    $parameters=str_replace("[message]", urlencode($message), $parameters);
                    $parameters=str_replace("[sender]", urlencode($sender),$parameters);
                    $parameters=str_replace("[number]", urlencode($number),$parameters);
                    $parameters=str_replace("[username]", urlencode($username),$parameters);
                    $parameters=str_replace("[password]", urlencode($password),$parameters);
                    $parameters=str_replace("[message_type]", urlencode($message_type),$parameters);
                    $parameters=str_replace("[message_category]", urlencode($message_category),$parameters);
                    $live_url="https://".$url.$parameters;
                    $parse_url=file($live_url);
                    $response=$parse_url[0];
                    return json_decode($response, true);
                    }
                    $receiver=$contact;
                    $msg='Thank you '.$surname.' '.$lastname.' for creating an account on CIIMS. Your username is '.$username.' userrole is '.$userrole.' and your password is '.$genpassword;
                    // function calling
                    SendSMS('non_customised','bulk', $receiver, $msg);
            }else{
                $_SESSION['msg']='Something went wrong';
            }
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    $sql=mysqli_query($con, "SELECT * FROM sysinfo");
    while($row=mysqli_fetch_assoc($sql)){?>
    <title><?php echo $row['fullname']." | ".$row['shortname'];;?></title>
    <?php } ?>
    <!-- Bootstrap -->
    <link rel="stylesheet" href="../assets/css/bootstrap.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- Material Icons -->
    <link rel="stylesheet" href="../assets/icons/material-icons.woff2">
    <!-- Current Time JS -->
    <script type="text/javascript" src="../assets/js/dateTime.js"></script>
    <!-- Favicon -->
    <link rel="shortcut icon" href="../components/favicon/favicon.png" type="image/x-icon">
</head>
<body>
    <!-- Wrapper -->
    <div class="wrapper">
        <!-- Header Section -->
        <?php if($_SESSION['login']!=""){ require_once 'includes/navbar/navbar.php';}?>
        <!-- Sidebar -->
        <?php if($_SESSION['login']!=""){ require_once 'includes/sidebar/sidebar.php';}?>
        <!-- Right Section -->
        <div class="main-wrapper">
            <div class="container">
                <div class="row pt-2">
                    <div class="col">
                        <p class="bold blue">Create User Account</p>
                        <form method="POST" autocomplete="off">
                            <div class="row">
                                <div class="col-lg-6 col-md-6">
                                    <label for="surname">Susrname</label>
                                    <input type="text" name="surname" class="input-field" placeholder="Surname">
                                </div>
                                <div class="col-lg-6 col-md-6">
                                    <label for="lastname">Last Name</label>
                                    <input type="text" name="lastname" class="input-field" placeholder="Last name">
                                </div>
                            </div>
                            <div class="row pt-4">
                                <div class="col-lg-6 col-md-6">
                                    <label for="username">Username</label>
                                    <input type="text" name="username" class="input-field" placeholder="Username">
                                </div>
                                <div class="col-lg-6 col-md-6">
                                    <label for="role">Role</label>
                                    <select name="userrole" class="input-field" id="mySelect">
                                        <option>Role</option>
                                        <?php
                                        $sql=mysqli_query($con, "SELECT * FROM userroles");
                                        while($row=mysqli_fetch_assoc($sql)){?>
                                        <option value="<?php echo $row['userrole'];?>"><?php echo $row['userrole'];?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>
                            <div class="row pt-4">
                                <div class="col-lg-6 col-md-6">
                                    <label for="contact">Phone Number</label>
                                    <input type="tel" name="contact" pattern="[0-9]{10,10}" minlength="10" maxlength="10" class="input-field" placeholder="Phone number">
                                </div>
                                <div class="col-lg-6 col-md-6">
                                    <label for="role">Email</label>
                                    <input type="email" name="email" class="input-field" placeholder="Email">
                                </div>
                            </div>
                            <div class="row pt-4">
                                <div class="col">
                                    <button type="submit" name="submit" class="button button-main">Create Account</button>
                                </div>
                            </div>
                        </form>
                        <div class="row pt-2">
                            <div class="col">
                                <?php echo $_SESSION['msg'];?>
                                <?php echo $_SESSION['msg']='';?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<script src="../assets/js/main.js"></script>
<script src="../assets/js/disableKeys.js"></script>
<script>
    document.addEventListener("DOMContentLoaded", function(){
        // Get the select element
        const selectElement = document.getElementById('mySelect');
        // Add click event listener to the select element
        selectElement.addEventListener("click", function(){
            // Hide the first option when the user clicks on the form
            selectElement.options[0].style.display = "none";
        });
    });
</script>
</body>
</html>
<?php } ?>