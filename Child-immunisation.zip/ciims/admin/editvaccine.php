<?php
// Start Session
session_start();
error_reporting(0);
// Include Database Connection
require_once '../includes/config/database.php';
// Check if session is set to true
if(strlen($_SESSION['login'])==0){
	header("Location: ../index.php");
	exit();
}else{
    $vaccineid=intval($_GET['vaccineid']);
    if(isset($_POST['update'])){
        $vaccine_package=$_POST['vaccine_package'];
        $vaccine_name=$_POST['vaccine_name'];
        $vaccine_protects=$_POST['vaccine_protects'];
        $vaccine_admin_mode=$_POST['vaccine_admin_mode'];

        if(empty($_POST['vaccine_package'])){
            $_SESSION['msg']='Please fill all fields';
        }else{
            $query=mysqli_query($con, "UPDATE vaccines SET vaccine_package='$vaccine_package', vaccine_name='$vaccine_name', vaccine_protects='$vaccine_protects', vaccine_admin_mode='$vaccine_admin_mode', date_updated=NOW() WHERE vaccineid='$vaccineid'");
            if($query){
                $_SESSION['msg']='Vaccine details updated successfully';
            }else{
                $_SESSION['msg']='Something went wrong';
            }
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    $sql=mysqli_query($con, "SELECT * FROM sysinfo");
    while($row=mysqli_fetch_assoc($sql)){?>
    <title><?php echo $row['fullname']." | ".$row['shortname'];;?></title>
    <?php } ?>
    <!-- Bootstrap -->
    <link rel="stylesheet" href="../assets/css/bootstrap.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- Material Icons -->
    <link rel="stylesheet" href="../assets/icons/material-icons.woff2">
    <!-- Current Time JS -->
    <script type="text/javascript" src="../assets/js/dateTime.js"></script>
    <!-- Favicon -->
    <link rel="shortcut icon" href="../components/favicon/favicon.png" type="image/x-icon">
</head>
<body>
    <!-- Wrapper -->
    <div class="wrapper">
        <!-- Header Section -->
        <?php if($_SESSION['login']!=""){ require_once 'includes/navbar/navbar.php';}?>
        <!-- Sidebar -->
        <?php if($_SESSION['login']!=""){ require_once 'includes/sidebar/sidebar.php';}?>
        <!-- Right Section -->
        <div class="main-wrapper">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <p class="bold blue">Edit Vaccine Records</p>
                        <form method="POST" autocomplete="off">
                            <?php
                            $vaccineid=$_GET['vaccineid'];
                            $sql=mysqli_query($con, "SELECT * FROM vaccines WHERE vaccineid='$vaccineid'");
                            while($row=mysqli_fetch_assoc($sql)){?>
                            <div class="row">
                                <div class="col-lg-6 col-md-6">
                                    <label for="">Package</label>
                                    <input type="text" name="vaccine_package" class="input-field" value="<?php echo $row['vaccine_package'];?>" placeholder="Package">
                                </div>
                                <div class="col-lg-6 col-md-6">
                                    <label for="">Vaccine</label>
                                    <input type="text" name="vaccine_name" class="input-field" value="<?php echo $row['vaccine_name'];?>" placeholder="Vaccine">
                                </div>
                            </div>
                            <div class="row pt-4">
                                <div class="col-lg-6 col-md-6">
                                    <label for="">What Vaccine Protects</label>
                                    <input type="text" name="vaccine_protects" class="input-field" value="<?php echo $row['vaccine_protects'];?>" placeholder="Vaccine">
                                </div>
                                <div class="col-lg-6 col-md-6">
                                    <label for="">Vaccine Admin Mode</label>
                                    <input type="text" name="vaccine_admin_mode" class="input-field" value="<?php echo $row['vaccine_admin_mode'];?>" placeholder="Vaccine">
                                </div>
                            </div>
                            <div class="row pt-4">
                                <div class="col">
                                    <button type="submit" name="update" class="button button-main">Update</button>
                                </div>
                            </div>
                            <?php } ?>
                        </form>
                    </div>
                </div>
                <div class="row pt-2">
                    <div class="col">
                        <?php echo $_SESSION['msg'];?>
                        <?php echo $_SESSION['msg']='';?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<script src="../assets/js/main.js"></script>
<script src="../assets/js/disableKeys.js"></script>
</body>
</html>
<?php } ?>