<?php
// Start Session
session_start();
error_reporting(0);
// Include Database Connection
require_once '../includes/config/database.php';
require_once '../plugins/userinfo.php';
// Check if session is set to true
if(strlen($_SESSION['login'])==0){
	header("Location: ../index.php");
	exit();
}else{
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    $sql=mysqli_query($con, "SELECT * FROM sysinfo");
    while($row=mysqli_fetch_assoc($sql)){?>
    <title><?php echo $row['fullname']." | ".$row['shortname'];;?></title>
    <?php } ?>
    <!-- Bootstrap -->
    <link rel="stylesheet" href="../assets/css/bootstrap.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- Material Icons -->
    <link rel="stylesheet" href="../assets/icons/material-icons.woff2">
    <!-- Current Time JS -->
    <script type="text/javascript" src="../assets/js/dateTime.js"></script>
    <!-- Favicon -->
    <link rel="shortcut icon" href="../components/favicon/favicon.png" type="image/x-icon">
</head>
<body>
    <!-- Wrapper -->
    <div class="wrapper">
        <!-- Header Section -->
        <?php if($_SESSION['login']!=""){ require_once 'includes/navbar/navbar.php';}?>
        <!-- Sidebar -->
        <?php if($_SESSION['login']!=""){ require_once 'includes/sidebar/sidebar.php';}?>
        <!-- Right Section -->
        <div class="main-wrapper">
            <div class="container">
                <div class="row pt-2">
                    <div class="col">
                        <p class="bold blue">My Account</p>
                        <?php
                        $sql=mysqli_query($con, "SELECT * FROM users WHERE username='".$_SESSION['login']."'");
                        while($row=mysqli_fetch_assoc($sql)){?>
                        <div class="row">
                            <div class="col-lg-10 col-md-10">
                                <p><i class="material-icons-outlined">person</i> Names: <?php echo $row[surname]." ".$row[lastname];?></p>
                                <p><i class="material-icons-outlined">email</i> Email: <?php echo $row[email];?></p>
                                <p><i class="material-icons-outlined">phone</i> Phone: <?php echo $row[contact];?></p>
                                <p><i class="material-icons-outlined">person</i> Role: <?php echo $row[userrole];?></p>
                                <p><i class="material-icons-outlined">calendar_month</i> Joined: <?php echo date('d M Y H:i:s A',strtotime($row[registered]));?></p>
                                <p><i class="material-icons-outlined">calendar_month</i> Last updated: <?php $row[updated];?></p>
                                <p><i class="material-icons-outlined">cloud</i> IP Address <?php echo UserInfo::get_ip();?></p>
                            </div>
                            <div class="col-lg-2 col-md-2">
                                <?php
                                if($row['photo']==""){?>
                                    <img src="../media/profile/avatar.png" alt="Profile" width="100px" height="100px">
                                <?php }else{ ?>
                                    <img class="img-circle" src="../media/profile/<?php echo $row['photo'];?>" alt="Profile" width="100px" height="100px">
                                <?php } ?>
                                <p class="pt-4"><a href="#">Edit Profile</a></p>
                            </div>
                        </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<script src="../assets/js/main.js"></script>
<script src="../assets/js/disableKeys.js"></script>
</body>
</html>
<?php } ?>