<?php
// Start Session
session_start();
error_reporting(0);
// Include Database Connection
require_once '../includes/config/database.php';
// Check if session is set to true
if(strlen($_SESSION['login'])==0){
	header("Location: ../index.php");
	exit();
}else{
    if(isset($_POST['submit'])){
        $fullname=$_POST['fullname'];
        $shortname=$_POST['shortname'];
        $slogan=$_POST['slogan'];
        $email=$_POST['email'];
        $contact=$_POST['contact'];

        if(empty($_POST['fullname']) || empty($_POST['shortname']) || empty($_POST['email']) || empty($_POST['contact'])){
            $_SESSION['msg']='Please fill all fields !!';
        }else{
            $query=mysqli_query($con, "INSERT INTO sysinfo(fullname, shortname, slogan, email, contact) VALUES('$fullname', '$shortname', '$slogan', '$email', '$contact')");
            if($query){
                $_SESSION['msg']='Settings updated';
            }else{
                $_SESSION['msg']='Something went wrong';
            }
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    $sql=mysqli_query($con, "SELECT * FROM sysinfo");
    while($row=mysqli_fetch_assoc($sql)){?>
    <title><?php echo $row['fullname']." | ".$row['shortname'];;?></title>
    <?php } ?>
    <!-- Bootstrap -->
    <link rel="stylesheet" href="../assets/css/bootstrap.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- Material Icons -->
    <link rel="stylesheet" href="../assets/icons/material-icons.woff2">
    <!-- Current Time JS -->
    <script type="text/javascript" src="../assets/js/dateTime.js"></script>
    <!-- Favicon -->
    <link rel="shortcut icon" href="../components/favicon/favicon.png" type="image/x-icon">
</head>
<body>
    <!-- Wrapper -->
    <div class="wrapper">
        <!-- Header Section -->
        <?php if($_SESSION['login']!=""){ require_once 'includes/navbar/navbar.php';}?>
        <!-- Sidebar -->
        <?php if($_SESSION['login']!=""){ require_once 'includes/sidebar/sidebar.php';}?>
        <!-- Right Section -->
        <div class="main-wrapper">
            <div class="container">
                <div class="row pt-2">
                    <div class="col">
                        <p class="bold blue">System Settings</p>
                        <form method="POST" autocomplete="off" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-lg-6 col-md-6">
                                    <label for="systemname">System Name</label>
                                    <input type="text" name="fullname" class="input-field" placeholder="System name">
                                </div>
                                <div class="col-lg-2 col-md-2">
                                    <label for="shortname">Short Form</label>
                                    <input type="text" name="shortname" class="input-field" placeholder="Short name">
                                </div>
                                <div class="col-lg-4 col-md-4">
                                    <label for="slogan">Slogan</label>
                                    <input type="text" name="slogan" class="input-field" placeholder="System slogan">
                                </div>
                            </div>
                            <div class="row pt-4">
                                <div class="col-lg-6 col-md-6">
                                    <label for="email">Email</label>
                                    <input type="email" name="email" class="input-field" placeholder="Email">
                                </div>
                                <div class="col-lg-6 col-md-6">
                                    <label for="contact">Contact</label>
                                    <input type="tel" name="contact" id="contact" class="input-field" pattern=[0-9]{10,10} minlength="10" maxlength="10" placeholder="Phone number">
                                </div>
                            </div>
                            <div class="row pt-4">
                                <div class="col">
                                    <button type="submit" name="submit" class="button button-main">Submit</button>
                                </div>
                            </div>
                        </form>
                        <div class="row pt-2">
                            <div class="col">
                                <?php echo $_SESSION['msg'];?>
                                <?php echo $_SESSION['msg']="";?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<script src="../assets/js/main.js"></script>
<script src="../assets/js/disableKeys.js"></script>
</body>
</html>
<?php } ?>