<?php
// Start Session
session_start();
// Include Database Connection
require_once '../includes/config/database.php';
$_SESSION['login']="";
date_default_timezone_set('Africa/Kampala');
$userlogid=$_GET['userlogid'];
mysqli_query($con, "UPDATE userlogs SET logouttime=NOW() WHERE tracker=".$_SESSION['tracker']);
session_unset();
$_SESSION['errormsg']="You are logged out";
    header("Location: ../index.php");
    exit();