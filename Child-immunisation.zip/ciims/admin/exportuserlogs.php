<?php
require_once '../includes/config/database.php';
date_default_timezone_set('Africa/Kampala');
if(isset($_POST['export'])){
	header('Content-Type: text/csv; charset=utf-8');
	$docname="User Logs History";
	$dash="-";
	$curdate=date("d-m-Y H:i:s");
	$filename=$docname.$dash.$curdate;
	header("Content-Disposition: attachment; filename=$filename.csv");
	$output=fopen("php://output", 'w');
	fputcsv($output, array('Username', 'Tracker', 'Operating System', 'Device', 'Browser', 'IP Address', 'Login Time', 'Logout Time', 'Login Status'));
	$query=mysqli_query($con, "SELECT username, tracker, os, device, browser, userip, logintime, logouttime, status FROM userlogs");
	while($row=mysqli_fetch_assoc($query)){
		fputcsv($output, $row);
	}
	fclose($output);
}