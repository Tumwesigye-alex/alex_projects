<?php
// Start Session
session_start();
error_reporting(0);
// Include Database Connection
require_once '../includes/config/database.php';
// Check if session is set to true
if(strlen($_SESSION['login'])==0){
	header("Location: ../index.php");
	exit();
}else{
    $regid=intval($_GET['regid']);
    if(isset($_POST['update'])){
        $childsnames=$_POST['childsnames'];
        $gender=$_POST['gender'];
        $childsdob=$_POST['childsdob'];
        $weight_at_birth=$_POST['weight_at_birth'];
        $birth_order=$_POST['birth_order'];
        $place_of_birth=$_POST['place_of_birth'];
        $mothers_names=$_POST['mothers_names'];
        $mothers_contact=$_POST['mothers_contact'];
        $mothers_occupation=$_POST['mothers_occupation'];
        $fathers_names=$_POST['fathers_names'];
        $fathers_contact=$_POST['fathers_contact'];
        $fathers_occupation=$_POST['fathers_occupation'];
        $district=$_POST['district'];
        $subcounty=$_POST['subcounty'];
        $parish=$_POST['parish'];
        $village=$_POST['village'];

        if(empty($_POST['childsnames'])){
            $_SESSION['msg']='Please fill all fields';
        }else{
            $query=mysqli_query($con, "UPDATE child_register SET childsnames='$childsnames', gender='$gender', childsdob='$childsdob', weight_at_birth='$weight_at_birth', birth_order='$birth_order', place_of_birth='$place_of_birth', mothers_names='$mothers_names', mothers_contact='$mothers_contact', mothers_occupation='$mothers_occupation', fathers_names='$fathers_names', fathers_contact='$fathers_contact', fathers_occupation='$fathers_occupation', district='$district', subcounty='$subcounty', parish='$parish', village='$village',  date_updated=NOW() WHERE regid='$regid'");
            if($query){
                $_SESSION['msg']='Child details updated successfully';
            }else{
                $_SESSION['msg']='Something went wrong';
            }
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    $sql=mysqli_query($con, "SELECT * FROM sysinfo");
    while($row=mysqli_fetch_assoc($sql)){?>
    <title><?php echo $row['fullname']." | ".$row['shortname'];;?></title>
    <?php } ?>
    <!-- Bootstrap -->
    <link rel="stylesheet" href="../assets/css/bootstrap.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- Material Icons -->
    <link rel="stylesheet" href="../assets/icons/material-icons.woff2">
    <!-- Current Time JS -->
    <script type="text/javascript" src="../assets/js/dateTime.js"></script>
    <!-- Favicon -->
    <link rel="shortcut icon" href="../components/favicon/favicon.png" type="image/x-icon">
</head>
<body>
    <!-- Wrapper -->
    <div class="wrapper">
        <!-- Header Section -->
        <?php if($_SESSION['login']!=""){ require_once 'includes/navbar/navbar.php';}?>
        <!-- Sidebar -->
        <?php if($_SESSION['login']!=""){ require_once 'includes/sidebar/sidebar.php';}?>
        <!-- Right Section -->
        <div class="main-wrapper">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <p class="bold blue">Edit Child Records</p>
                        <form method="POST" autocomplete="off">
                            <?php
                            $regid=$_GET['regid'];
                            $sql=mysqli_query($con, "SELECT * FROM child_register WHERE regid='$regid'");
                            while($row=mysqli_fetch_assoc($sql)){?>
                            <div class="row">
                                <div class="col-lg-4 col-md-4">
                                    <label for="">Child's RegNo</label>
                                    <input type="text" class="input-field" value="<?php echo $row['regno'];?>" readonly>
                                </div>
                                <div class="col-lg-4 col-md-4">
                                    <label for="">Child's Names</label>
                                    <input type="text" name="childsnames" class="input-field" value="<?php echo $row['childsnames'];?>" placeholder="Names">
                                </div>
                                <div class="col-lg-4 col-md-4">
                                    <label for="">Child's Gender</label>
                                    <input type="text" name="gender" class="input-field" value="<?php echo $row['gender'];?>" placeholder="Gender">
                                </div>
                            </div>
                            <div class="row pt-4">
                                <div class="col-lg-3 col-md-3">
                                    <label for="">Date of Birth</label>
                                    <input type="date" name="childsdob" class="input-field" value="<?php echo $row['childsdob'];?>">
                                </div>
                                <div class="col-lg-3 col-md-3">
                                    <label for="">Weight at Birth (Kgs)</label>
                                    <input type="number" name="weight_at_birth" min="1" class="input-field" value="<?php echo $row['weight_at_birth'];?>" placeholder="Weight">
                                </div>
                                <div class="col-lg-3 col-md-3">
                                    <label for="">Birth Order</label>
                                    <input type="number" name="birth_order" min="1" class="input-field" value="<?php echo $row['birth_order'];?>" placeholder="Birth order">
                                </div>
                                <div class="col-lg-3 col-md-3">
                                    <label for="">Place of Birth</label>
                                    <input type="text" name="place_of_birth" class="input-field" value="<?php echo $row['place_of_birth'];?>" placeholder="Place of Birth">
                                </div>
                            </div>
                            <div class="row pt-4">
                                <div class="col-lg-4 col-md-4">
                                    <label for="">Mother's Names</label>
                                    <input type="text" name="mothers_names" class="input-field" value="<?php echo $row['mothers_names'];?>" placeholder="Mother">
                                </div>
                                <div class="col-lg-4 col-md-4">
                                    <label for="">Mother's Contact</label>
                                    <input type="tel" name="mothers_contact" class="input-field" pattern=[0-9]{10,10} minlength="10" maxlength="10" value="<?php echo $row['mothers_contact'];?>" placeholder="Contact">
                                </div>
                                <div class="col-lg-4 col-md-4">
                                    <label for="">Mother's Occupation</label>
                                    <input type="text" name="mothers_occupation" class="input-field" value="<?php echo $row['mothers_occupation'];?>" placeholder="Occupation">
                                </div>
                            </div>
                            <div class="row pt-4">
                                <div class="col-lg-4 col-md-4">
                                    <label for="">Fathers's Names</label>
                                    <input type="text" name="fathers_names" class="input-field" value="<?php echo $row['fathers_names'];?>" placeholder="Father">
                                </div>
                                <div class="col-lg-4 col-md-4">
                                    <label for="">Fathers's Contact</label>
                                    <input type="tel" name="fathers_contact" class="input-field" pattern=[0-9]{10,10} minlength="10" maxlength="10" value="<?php echo $row['fathers_contact'];?>" placeholder="Contact">
                                </div>
                                <div class="col-lg-4 col-md-4">
                                    <label for="">Fathers's Occupation</label>
                                    <input type="text" name="fathers_occupation" class="input-field" value="<?php echo $row['fathers_occupation'];?>" placeholder="Occupation">
                                </div>
                            </div>
                            <div class="row pt-4">
                                <div class="col-lg-3 col-md-3">
                                    <label for="">District</label>
                                    <input type="text" name="district" class="input-field" value="<?php echo $row['district'];?>" placeholder="District">
                                </div>
                                <div class="col-lg-3 col-md-3">
                                    <label for="">Subcounty</label>
                                    <input type="text" name="subcounty" class="input-field" value="<?php echo $row['subcounty'];?>" placeholder="Subcounty">
                                </div>
                                <div class="col-lg-3 col-md-3">
                                    <label for="">Parish</label>
                                    <input type="text" name="parish" class="input-field" value="<?php echo $row['parish'];?>" placeholder="Parish">
                                </div>
                                <div class="col-lg-3 col-md-3">
                                    <label for="">Village</label>
                                    <input type="text" name="village" class="input-field" value="<?php echo $row['village'];?>" placeholder="Village">
                                </div>
                            </div>
                            <div class="row pt-4">
                                <div class="col">
                                    <button type="submit" name="update" class="button button-main">Update Child Details</button>
                                </div>
                            </div>
                            <?php } ?>
                        </form>
                    </div>
                </div>
                <div class="row pt-2">
                    <div class="col">
                        <?php echo $_SESSION['msg'];?>
                        <?php echo $_SESSION['msg']='';?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<script src="../assets/js/main.js"></script>
<script src="../assets/js/disableKeys.js"></script>
</body>
</html>
<?php } ?>