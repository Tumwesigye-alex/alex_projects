<?php
// Start Session
session_start();
error_reporting(0);
// Include Database Connection
require_once '../includes/config/database.php';
// Check if session is set to true
if(strlen($_SESSION['login'])==0){
	header("Location: ../index.php");
	exit();
}else{
    if(isset($_POST['submit'])){
        $regno=$_POST['regno'];
        $childsnames=$_POST['childsnames'];
        $gender=$_POST['gender'];
        $childsdob=$_POST['childsdob'];
        $weight_at_birth=$_POST['weight_at_birth'];
        $birth_order=$_POST['birth_order'];
        $place_of_birth=$_POST['place_of_birth'];
        $mothers_names=$_POST['mothers_names'];
        $mothers_contact=$_POST['mothers_contact'];
        $mothers_occupation=$_POST['mothers_occupation'];
        $fathers_names=$_POST['fathers_names'];
        $fathers_contact=$_POST['fathers_contact'];
        $district=$_POST['district'];
        $subcounty=$_POST['subcounty'];
        $parish=$_POST['parish'];
        $village=$_POST['village'];
        // Auto generate child's NIN
        $initial='C'; //Constant
        $gender=$_POST['gender']; // Get submitted child's gender
        $dob=$_POST['childsdob']; // Get submitted child's date of birth
        $extracted=substr($dob, 0, 4); // Extract the year of birth from the submitted child's date of birth
        // Generate Random characters
        $characters='ABCDEFGHIJKLMN01234OPQRSTUVWXYZ56789'; // Create a character string
        $characterLength=10; // Specify the character length to be generated
        $chars=''; // Initialise the characters to none
        $charLength=strlen($characters)-1; // Validate the character length
        for($i = 0; $i < $characterLength; $i++){ // The for loop to keep checking the generated character length
            $chars .= $characters[rand(0, $charLength)]; // Generate random characters
        }
        $childs_nin=$initial.substr($gender, 0, 1).substr($extracted, -2).$chars; // Generated child's NIN
        // Auto generate support ticket
        $support_ticket='M-'.rand(100000,999999);
        // Return child's gender to use while sending a congratulatory SMS to the mother
        if($gender=='Male'){
            $childs_gender='boy';
        }else{
            $childs_gender='girl';
        }
        // Check if the submitted form is empty
        if(empty($_POST['weight_at_birth']) || empty($_POST['birth_order']) || empty($_POST['place_of_birth']) || empty($_POST['mothers_names']) || empty($_POST['mothers_contact']) || empty($_POST['fathers_names']) || empty($_POST['fathers_contact'])){
            $_SESSION['msg']='Please fill all fields to proceed!!';
        }else{
            // Insert the submitted form data to the child register table
            $query=mysqli_query($con, "INSERT INTO child_register(regno, childsnames, gender, childsdob, weight_at_birth, birth_order, place_of_birth, mothers_names, mothers_contact, mothers_occupation, fathers_names, fathers_contact, childs_nin, support_ticket, district, subcounty, parish, village) VALUES('$regno', '$childsnames', '$gender', '$childsdob', '$weight_at_birth', '$birth_order', '$place_of_birth', '$mothers_names', '$mothers_contact', '$mothers_occupation', '$fathers_names', '$fathers_contact', '$childs_nin', '$support_ticket', '$district', '$subcounty', '$parish', '$village')");
            if($query){
                $_SESSION['msg']='Child\'s details captured successfully';
                // Send child details via SMS to the provided phone number
                function SendSMS($message_type,$message_category,$number,$message){ 
                $username='0778147485';
                $password='mackol44';
                $sender='CIIMS';
                $url="sms.thepandoranetworks.com/API/send_sms/?";
                $parameters="number=[number]&message=[message]&username=[username]&password=[password]&sender=[sender]&message_type=[message_type]&message_category=[message_category]";
                $parameters=str_replace("[message]", urlencode($message), $parameters);
                $parameters=str_replace("[sender]", urlencode($sender),$parameters);
                $parameters=str_replace("[number]", urlencode($number),$parameters);
                $parameters=str_replace("[username]", urlencode($username),$parameters);
                $parameters=str_replace("[password]", urlencode($password),$parameters);
                $parameters=str_replace("[message_type]", urlencode($message_type),$parameters);
                $parameters=str_replace("[message_category]", urlencode($message_category),$parameters);
                $live_url="https://".$url.$parameters;
                $parse_url=file($live_url);
                $response=$parse_url[0];
                return json_decode($response, true);
                }
                $siteurl='https://ciims.com/parent';
                $mothers_contact=$mothers_contact;
                $fathers_contact=$fathers_contact;
                $login_guide_sms='Hello '.$mothers_names.', to login to your CIIMS portal, visit '.$siteurl.'. Use your child\'s registration number as username and your contact as password. Thank you.';
                $mothers_sms='Congratulations '.$mothers_names.', upon giving birth to a bouncing baby '.$childs_gender. '. Your child has been registered for immunisation. Your childs registration number is '.$regno.' and childs NIN is '.$childs_nin;
                $fathers_sms='Congratulations '.$fathers_names.', upon receiving a bouncing baby '.$childs_gender. '. Your child has been registered for immunisation. Your childs registration number is '.$regno.' and childs NIN is '.$childs_nin;
                // function calling
                SendSMS('non_customised','bulk', $mothers_contact, $mothers_sms);
                SendSMS('non_customised','bulk', $mothers_contact, $login_guide_sms);
                SendSMS('non_customised','bulk', $fathers_contact, $fathers_sms);
            }else{
                $_SESSION['msg']='Something went wrong';
            }
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    $sql=mysqli_query($con, "SELECT * FROM sysinfo");
    while($row=mysqli_fetch_assoc($sql)){?>
    <title><?php echo $row['fullname']." | ".$row['shortname'];;?></title>
    <?php } ?>
    <!-- Bootstrap -->
    <link rel="stylesheet" href="../assets/css/bootstrap.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- Material Icons -->
    <link rel="stylesheet" href="../assets/icons/material-icons.woff2">
    <!-- Current Time JS -->
    <script type="text/javascript" src="../assets/js/dateTime.js"></script>
    <!-- Favicon -->
    <link rel="shortcut icon" href="../components/favicon/favicon.png" type="image/x-icon">
</head>
<body>
    <!-- Wrapper -->
    <div class="wrapper">
        <!-- Header Section -->
        <?php if($_SESSION['login']!=""){ require_once 'includes/navbar/navbar.php';}?>
        <!-- Sidebar -->
        <?php if($_SESSION['login']!=""){ require_once 'includes/sidebar/sidebar.php';}?>
        <!-- Right Section -->
        <div class="main-wrapper">
            <div class="container">
                <div class="row pt-2">
                    <div class="col">
                        <p class="blue">Upon giving birth, Fill this form to register a new child for subsquent child immunisation follow up and immunisation management</p>
                        <form method="POST" autocomplete="off">
                            <div class="row">
                                <div class="col-lg-4 col-md-4">
                                    <label for="regno">Child's Registration Number</label>
                                    <?php
                                        $sql=mysqli_query($con, "SELECT COUNT(*) AS childcount FROM child_register");
                                        while($row=mysqli_fetch_assoc($sql)){
                                        $count=1;
                                        $initial='MRRH';
                                        $dash='-';
                                        $curdate=date('d');
                                        $curmonth=date('m');
                                        $curyear=date('y');
                                        $seal='CIIMS';
                                        $regid=intval($row['childcount'])+$count;
                                        $regno=$initial.$dash.$curdate.$curmonth.$curyear.$dash.$seal.sprintf('%03d', $regid);?>
                                        <input type="text" name="regno" value="<?php echo $regno;?>" class="input-field" readonly>
                                    <?php } ?>
                                </div>
                                <div class="col-lg-4 col-md-4">
                                    <label for="name">Child's Names</label>
                                    <input type="text" name="childsnames" class="input-field" placeholder="Names">
                                </div>
                                <div class="col-lg-4 col-md-4">
                                    <label for="gender">Child's Gender</label>
                                    <select name="gender" class="input-field">
                                        <option value="None">Gender</option>
                                        <option value="Male">Male</option>
                                        <option value="Female">Female</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row pt-4">
                                <div class="col-lg-4 col-md-4">
                                    <label for="dob">Child's Date of Birth</label>
                                    <input type="date" name="childsdob" class="input-field">
                                </div>
                                <div class="col-lg-4 col-md-4">
                                    <label for="weight">Child's Weight at Birth(Kgs)</label>
                                    <input type="number" name="weight_at_birth" min="1" class="input-field" placeholder="Weight">
                                </div>
                                <div class="col-lg-4 col-md-4">
                                    <label for="birthorder">Child's Birth Order</label>
                                    <input type="number" name="birth_order" min="1" class="input-field" placeholder="Birth order">
                                </div>
                            </div>
                            <div class="row pt-4">
                                <div class="col-lg-4 col-md-4">
                                    <label for="birth">Child's Place of Birth</label>
                                    <input type="text" name="place_of_birth" class="input-field" placeholder="Place of birth">
                                </div>
                                <div class="col-lg-4 col-md-4">
                                    <label for="mother">Child's Mother's Names</label>
                                    <input type="text" name="mothers_names" class="input-field" placeholder="Mother">
                                </div>
                                <div class="col-lg-4 col-md-4">
                                    <label for="contact">Child's Mother's Contact</label>
                                    <input type="tel" name="mothers_contact" class="input-field" placeholder="Phone number" pattern=[0-9]{10,10} minlength="10" maxlength="10">
                                </div>
                            </div>
                            <div class="row pt-4">
                                <div class="col-lg-4">
                                    <label for="moccupation">Child's Mother's Occupation</label>
                                    <input type="text" name="mothers_occupation" class="input-field" placeholder="Occupation">
                                </div>
                                <div class="col-lg-4 col-md-4">
                                    <label for="father">Child's Father's Names</label>
                                    <input type="text" name="fathers_names" class="input-field" placeholder="Father">
                                </div>
                                <div class="col-lg-4 col-md-4">
                                    <label for="fcontact">Child's Father's Contact</label>
                                    <input type="tel" name="fathers_contact" class="input-field" placeholder="Phone number" pattern=[0-9]{10,10} minlength="10" maxlength="10">
                                </div>
                            </div>
                            <div class="row pt-4">
                                <div class="col-lg-3 col-md-3">
                                    <label for="">District</label>
                                    <input type="text" name="district" class="input-field" placeholder="District">
                                </div>
                                <div class="col-lg-3 col-md-3">
                                    <label for="">Subcounty</label>
                                    <input type="text" name="subcounty" class="input-field" placeholder="Subcounty">
                                </div>
                                <div class="col-lg-3 col-md-3">
                                    <label for="">Parish</label>
                                    <input type="text" name="parish" class="input-field" placeholder="Parish">
                                </div>
                                <div class="col-lg-3 col-md-3">
                                    <label for="">Village</label>
                                    <input type="text" name="village" class="input-field" placeholder="Village">
                                </div>
                            </div>
                            <div class="row pt-4">
                                <div class="col">
                                    <button type="submit" name="submit" class="button button-main">Register Child</button>
                                </div>
                                <div class="col">
                                    <!-- <button type="reset" class="button button-main">Clear Form Data</button> -->
                                </div>
                            </div>
                        </form>
                        <div class="row pt-4">
                            <div class="col">
                                <?php echo $_SESSION['msg'];?>
                                <?php echo $_SESSION['msg']="";?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<script src="../assets/js/main.js"></script>
<script src="../assets/js/disableKeys.js"></script>
</body>
</html>
<?php } ?>