<?php
// Start Session
session_start();
error_reporting(0);
// Include Database Connection
require_once '../includes/config/database.php';
// Check if session is set to true
if(strlen($_SESSION['login'])==0){
	header("Location: ../index.php");
	exit();
}else{
    if(isset($_POST['submit'])){
        $userrole=$_POST['userrole'];

        $sql=mysqli_query($con, "SELECT * FROM userroles WHERE userrole='$userrole'");
        if(mysqli_num_rows($sql)>0){
            $_SESSION['msg']='<font color="red">Oops, this user role <strong>'.$userrole.'</strong> is already taken. Please choose another</font>';
        }else{
            if(empty($_POST['userrole'])){
                $_SESSION['msg']='<font color="red">Please enter user role to proceed !!</font>';
            }else{
                $query=mysqli_query($con, "INSERT INTO userroles(userrole) VALUES('$userrole')");
                if($query){
                    $_SESSION['msg']='<font color="blue">User role '.$userrole.' registered successfully</font>';
                }else{
                    $_SESSION['msg']='<font color="red">Something went wrong</font>';
                }
            }
        }
    }
    // Delete user role
    if(isset($_GET['del'])){
		mysqli_query($con, "DELETE FROM userroles WHERE userroleid='".$_GET['userroleid']."'"); 
		$_SESSION['delmsg']='<font color="red">User role deleted successfully</font>';
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    $sql=mysqli_query($con, "SELECT * FROM sysinfo");
    while($row=mysqli_fetch_assoc($sql)){?>
    <title><?php echo $row['fullname']." | ".$row['shortname'];;?></title>
    <?php } ?>
    <!-- Bootstrap -->
    <link rel="stylesheet" href="../assets/css/bootstrap.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- Material Icons -->
    <link rel="stylesheet" href="../assets/icons/material-icons.woff2">
    <!-- Current Time JS -->
    <script type="text/javascript" src="../assets/js/dateTime.js"></script>
    <!-- Favicon -->
    <link rel="shortcut icon" href="../components/favicon/favicon.png" type="image/x-icon">
</head>
<body>
    <!-- Wrapper -->
    <div class="wrapper">
        <!-- Header Section -->
        <?php if($_SESSION['login']!=""){ require_once 'includes/navbar/navbar.php';}?>
        <!-- Sidebar -->
        <?php if($_SESSION['login']!=""){ require_once 'includes/sidebar/sidebar.php';}?>
        <!-- Right Section -->
        <div class="main-wrapper">
            <div class="container">
                <div class="row pt-2">
                    <!-- First column that holds the submission form -->
                    <div class="col-lg-4">
                        <p class="blue">Create User Role</p>
                        <form method="POST" autocomplete="off">
                            <div class="row">
                                <div class="col">
                                    <input type="text" name="userrole" class="input-field" placeholder="Enter user role">
                                </div>
                            </div>
                            <div class="row pt-4">
                                <div class="col">
                                    <button type="submit" name="submit" class="button button-main button-block">Register User Role</button>
                                </div>
                            </div>
                        </form>
                        <div class="row pt-4">
                            <div class="col">
                                <?php echo $_SESSION['msg'];?>
                                <?php echo $_SESSION['msg']="";?>
                            </div>
                        </div>
                    </div>
                    <!-- Seconc column that holds the output -->
                    <div class="col-lg-8 col-md-8">
                        <p class="blue">List of available user roles</p>
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Role</th>
                                        <th>Status</th>
                                        <th colspan="2">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $sql=mysqli_query($con, "SELECT * FROM userroles");
                                    $count=0;
                                    while($row=mysqli_fetch_assoc($sql)){$count++;?>
                                    <tr>
                                        <td><?php echo $count;?></td>
                                        <td><?php echo $row['userrole'];?></td>
                                        <td><?php if($row['status']==1){echo 'Active';}else{echo 'Inactive';}?></td>
                                        <td><a href="#" target="_blank"><span class="material-icons-outlined">edit</span></a></td>
                                        <td><a href="userroles.php?userroleid=<?php echo $row['userroleid']?>&del=DELETE" onclick="return confirm('Are you sure you want to delete this user role')"><i class="material-icons-outlined">delete</i></a></td>
                                    </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="row">
                            <div class="col">
                                <?php echo $_SESSION['delmsg'];?>
                                <?php echo $_SESSION['delmsg']='';?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<script src="../assets/js/main.js"></script>
<script src="../assets/js/disableKeys.js"></script>
</body>
</html>
<?php } ?>