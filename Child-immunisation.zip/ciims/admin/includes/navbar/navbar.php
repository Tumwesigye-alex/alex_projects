<header class="header">
  <div class="menu-icon" onclick="openSidebar()">
    <span class="material-icons-outlined">menu</span>
  </div>
  <div class="header-left">
  <span class="bold">Today is:</span> <span class="blue"><?php date_default_timezone_set('Africa/Kampala'); print(date('D d M Y'));?></span>
  &nbsp&nbsp&nbsp&nbsp<span class="bold">Time</span>
    <span id="dateTime" class="blue"></span>
    <?php print(date('A'));?>
    <script type="text/javascript">window.onload=dateTime('dateTime');</script>
  </div>
  <div class="header-right">
    <ul>
      <li>
        <a href="#"><span class="material-icons-outlined">account_circle</span></a>
        <div class="dropdown">
          <ul>
            <li>
              <a href="myaccount.php"><span class="material-icons-outlined">person</span> My Account</a>
              <a href="signout.php"><span class="material-icons-outlined">logout</span> Signout</a>
            </li>
          </ul>
        </div>
      </li>
    </ul>
  </div>
</header>