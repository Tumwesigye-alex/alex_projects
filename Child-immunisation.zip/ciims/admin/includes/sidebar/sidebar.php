<aside id="sidebar">
    <div class="sidebar-title">
        <div class="sidebar-brand">
            <span title="CIIMS">Child Immunisation</span>
        </div>
        <span class="material-icons-outlined" onclick="closeSidebar()">close</span>
    </div>
    <ul class="sidebar-list">
        <li class="sidebar-list-item">
            <a href="dashboard.php"><span class="material-icons-outlined">dashboard</span> Dashboard</a>
        </li>
        <li class="sidebar-list-item">
            <a href="registerchild.php"><span class="material-icons-outlined">local_library</span> Register Child</a>
        </li>
        <li class="sidebar-list-item">
            <a href="childregister.php"><span class="material-icons-outlined">local_library</span> Child Register</a>
        </li>
        <li class="sidebar-list-item">
            <a href="immunisedchildren.php"><span class="material-icons-outlined">groups</span> Immunised Children</a>
        </li>
        <li class="sidebar-list-item">
            <a href="registervaccine.php"><span class="material-icons-outlined">vaccines</span> Register Vaccine</a>
        </li>
        <li class="sidebar-list-item">
            <a href="vaccines.php"><span class="material-icons-outlined">vaccines</span> List of Vaccines</a>
        </li>
        <li class="sidebar-list-item">
            <a href="userroles.php"><span class="material-icons-outlined">person_add</span> User Roles</a>
        </li>
        <li class="sidebar-list-item">
            <a href="createuser.php"><span class="material-icons-outlined">group</span> Create Account</a>
        </li>
        <li class="sidebar-list-item">
            <a href="useraccounts.php"><span class="material-icons-outlined">group</span> User Accounts</a>
        </li>
        <li class="sidebar-list-item">
            <a href="userlogs.php"><span class="material-icons-outlined">history</span> User Logs</a>
        </li>
        <li class="sidebar-list-item">
            <a href="settings.php"><span class="material-icons-outlined">settings</span> Settings</a>
        </li>
        <li class="sidebar-list-item">
            <a href="sysinfo.php"><span class="material-icons-outlined">settings_applications</span> System Info</a>
        </li>
    </ul>
</aside>