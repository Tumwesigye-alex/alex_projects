<?php
// Start Session
session_start();
error_reporting(0);
$tracker=mt_rand(100000,999999);
// Include Database Connection
require_once 'includes/config/database.php';
// Include script to catch user login os, device, browser and IP address
require_once 'plugins/userinfo.php';
// Set your timezone
date_default_timezone_set('Africa/Kampala');
// Check if thelogin button listener is set
if(isset($_POST['login'])){
    $username=$_POST['username'];
    $upassword=$_POST['password'];
    $hashpass=MD5($upassword);
    $userrole=$_POST['userrole'];
    $_SESSION['tracker']=$tracker;

    if(empty($_POST['username']) || empty($_POST['password'])){
        $_SESSION['msg']='Username or password cannot be blank';
    }else{
        // Select user from the database
        $query=mysqli_query($con, "SELECT * FROM users WHERE username='$username' AND password='$hashpass' AND userrole='$userrole' AND status=1");
        $user=mysqli_fetch_array($query);
        if($user>0){
        // Create user login session ID
        $_SESSION['login']=$_POST['username'];
        $_SESSION['userid']=$user['userid'];
        $_SESSION['surname']=$user['surname'];
        $_SESSION['lastname']=$user['lastname'];
        $_SESSION['userrole']=$user['userrole'];
        // Redirect user login previledges
        if($userrole=='Admin'){
            echo "<script type='text/javascript'> document.location = 'admin/dashboard.php';</script>";
        }
        else if($userrole=='Nurse'){
            echo "<script type='text/javascript'> document.location = 'nurse/dashboard.php';</script>";
        }
        // Catch user login OS, Device, Browser, IP address
        $os=UserInfo::get_os();
        $device=UserInfo::get_device();
        $browser=UserInfo::get_browser();
        $userip=UserInfo::get_ip();
        // Insert user login OS, Device, Browser, IP address into the database
        $sql=mysqli_query($con, "INSERT INTO userlogs(username, tracker, os, device, browser, userip, logintime) VALUES('".$_SESSION['userrole']."', '$tracker', '$os', '$device', '$browser', '$userip', NOW())");
        }
        else{
            $_SESSION['msg']='Invalid Login Details. Check your Login details and try again!!';
            // Collect login OS, Device, Browser, IP address
            $os=UserInfo::get_os();
            $device=UserInfo::get_device();
            $browser=UserInfo::get_browser();
            $userip=UserInfo::get_ip();
            // Generate tracker ID
            $trackerid='M-'.rand(100000,999999);
            $log=mysqli_query($con, "INSERT INTO login_attempts(username, password, useros, device, browser, userip, trial_time, tracker) VALUES('$username', '$upassword', '$os', '$device', '$browser', '$userip', NOW(), '$trackerid')");
            // Send Login failed SMS to the developer's phone number
            function SendSMS($message_type,$message_category,$number,$message){ 
            $username='0778147485';
            $password='mackol44';
            $sender='CIIMS';
            $url="sms.thepandoranetworks.com/API/send_sms/?";
            $parameters="number=[number]&message=[message]&username=[username]&password=[password]&sender=[sender]&message_type=[message_type]&message_category=[message_category]";
            $parameters=str_replace("[message]", urlencode($message), $parameters);
            $parameters=str_replace("[sender]", urlencode($sender),$parameters);
            $parameters=str_replace("[number]", urlencode($number),$parameters);
            $parameters=str_replace("[username]", urlencode($username),$parameters);
            $parameters=str_replace("[password]", urlencode($password),$parameters);
            $parameters=str_replace("[message_type]", urlencode($message_type),$parameters);
            $parameters=str_replace("[message_category]", urlencode($message_category),$parameters);
            $live_url="https://".$url.$parameters;
            $parse_url=file($live_url);
            $response=$parse_url[0];
            return json_decode($response, true);
            }
            $developer='0780697787';
            $curtime=DATE('D d-M-Y H:i:s A');
            $sms='Hallo, someone disguising as username '.$username.', password '.$upassword.' is trying to login to CIIMS using a '.$device.', '.$browser.', on '.$os.' and IP address of '.$userip.' at '.$curtime.'. Trxn ID '.$trackerid;
            // function calling
            SendSMS('non_customised','bulk', $developer, $sms);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to CIIMS - Login</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <!-- Material Icons -->
    <link rel="stylesheet" href="assets/icons/material-icons.woff2">
    <!-- Favicon -->
    <link rel="shortcut icon" href="components/favicon/favicon.png" type="image/x-icon">
<style>
body {
  background-image: url('media/photos/bg.jpg');
  background-size: cover;
  background-repeat: no-repeat;
  backdrop-filter: contrast(1);
}
</style>

</head>
<body>
    <div class="main-wrapper">
        <div class="container">
            <div class="row pt-5">
                <div class="col-lg-8 col-md-8">
                    <center><img src="media/photos/logo.png" width="100px" alt="Logo"></center>
                    <h3><p class="center white">Welcome to</p></h3>
                    <?php
                    $sql=mysqli_query($con, "SELECT * FROM sysinfo ORDER BY sysid DESC LIMIT 1");
                    while($row=mysqli_fetch_assoc($sql)){?>
                    <h2 class="white bold center"><?php echo $row['fullname'].' - '.$row['shortname'];?></h2>
                    <p class="center white"><?php echo $row['slogan'];?></p>
                    <p class="white pt-4">For any assistance, contact the systems Admin</p>
                    <p class="white">Contact: <a href="tel:<?php echo $row['contact'];?>"><?php $ctrycode='+256'; $space=' '; $result=$row['contact']; $trimmed=substr($result,1); echo $ctrycode.$space.$trimmed;?></a></p>
                    <p class="white">Email: <a href="mailto:<?php echo $row['email'];?>"><?php echo $row['email'];?></a></p>
                    <?php } ?>
                </div>
                <div class="col-lg-4 col-md-4">
                    <p class="white center">Please sign in to continue</p>
                    <div class="row pt-2">
                        <div class="col red center">
                            <?php echo $_SESSION['errormsg'];?>
                            <?php echo $_SESSION['errormsg']="";?>
                        </div>
                    </div>
                    <form method="POST" autocomplete="off">
                        <div class="row">
                            <div class="col">
                                <input type="text" name="username" class="input-field" placeholder="Username">
                            </div>
                        </div>
                        <div class="row pt-4">
                            <div class="col" style="position:relative;display:flex;align-items:center">
                                <input type="password" name="password" id="password" class="input-field" placeholder="Password">
                                <i class="material-icons-outlined" style="position:absolute;right:30px;cursor:pointer" onclick="togglePassword()">visibility</i>
                            </div>
                        </div>
                        <div class="row pt-4">
                            <div class="col">
                                <select name="userrole" class="input-field" id="mySelect">
                                    <option value="None">Role</option>
                                    <option value="Admin">Admin</option>
                                    <option value="Nurse">Nurse</option>
                                </select>
                            </div>
                        </div>
                        <div class="row pt-4">
                            <div class="col">
                                <button type="submit" name="login" class="button button-main button-block">SIGN IN</button>
                            </div>
                        </div>
                    </form>
                    <div class="row pt-2">
                        <div class="col red center">
                            <?php echo $_SESSION['msg'];?>
                            <?php echo $_SESSION['msg']="";?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row pt-5">
                <hr>
                <div class="col-lg-9 col-md-9">
                    <p class="inactive hover">Copyright &copy <?php print(date('Y'));?>. All rights reserved by MRRH</p>
                </div>
                <div class="col-lg-3 col-md-3">
                    <p class="inactive hover">Powered by Tech Code Inc</p>
                </div>
            </div>
        </div> 
    </div>
<script src="assets/js/main.js"></script>
<script src="assets/js/disableKeys.js"></script>
<script>
    document.addEventListener("DOMContentLoaded", function(){
        // Get the select element
        const selectElement = document.getElementById('mySelect');
        // Add click event listener to the select element
        selectElement.addEventListener("click", function(){
            // Hide the first option when the user clicks on the form
            selectElement.options[0].style.display = "none";
        });
    });
</script>
<script>
function togglePassword(){
  var passwordField = document.getElementById("password");
  var icon = document.querySelector(".toggle-password");
  
  if(passwordField.type === "password"){
    passwordField.type = "text";
    icon.classList.remove();
    icon.classList.add();
  }else{
    passwordField.type = "password";
    icon.classList.remove();
    icon.classList.add();
  }
}
</script>
</body>
</html>