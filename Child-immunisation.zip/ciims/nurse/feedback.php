<?php
// Start Session
session_start();
error_reporting(0);
// Include Database Connection
require_once '../includes/config/database.php';
// Check if session is set to true
if(strlen($_SESSION['login'])==0){
	header("Location: ../index.php");
	exit();
}else{
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    $sql=mysqli_query($con, "SELECT * FROM sysinfo");
    while($row=mysqli_fetch_assoc($sql)){?>
    <title><?php echo $row['fullname']." | ".$row['shortname'];;?></title>
    <?php } ?>
    <!-- Bootstrap -->
    <link rel="stylesheet" href="../assets/css/bootstrap.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- Material Icons -->
    <link rel="stylesheet" href="../assets/icons/material-icons.woff2">
    <!-- Current Time JS -->
    <script type="text/javascript" src="../assets/js/dateTime.js"></script>
    <!-- Favicon -->
    <link rel="shortcut icon" href="../components/favicon/favicon.png" type="image/x-icon">
</head>
<body>
    <!-- Wrapper -->
    <div class="wrapper">
        <!-- Header Section -->
        <?php if($_SESSION['login']!=''){ require_once 'includes/navbar/navbar.php';}?>
        <!-- Sidebar -->
        <?php if($_SESSION['login']!=''){ require_once 'includes/sidebar/sidebar.php';}?>
        <!-- Right Section -->
        <div class="main-wrapper">
            <div class="container">
                <div class="row pt-2">
                    <div class="col">
                        <p class="blue">View all feedback and give reply individually</p>
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover" id="feedback">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Child's RegNo</th>
                                        <th>Vaccine Received</th>
                                        <th>Date</th>
                                        <th>Priority</th>
                                        <th>Description</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $sql=mysqli_query($con, "SELECT * FROM feedback INNER JOIN child_register ON feedback.feedback_id=child_register.regid INNER JOIN vaccines ON feedback.feedback_id=vaccines.vaccineid");
                                    $count=0;
                                    while($row=mysqli_fetch_assoc($sql)){$count++;?>
                                    <tr>
                                        <td><?php echo $count;?></td>
                                        <td><?php echo $row['regno'];?></td>
                                        <td><?php echo $row['vaccine_name'];?></td>
                                        <td><?php echo date('D d-M-Y',strtotime($row['date_received']));?></td>
                                        <td><?php echo $row['priority'];?></td>
                                        <td><?php echo $row['comment'];?></td>
                                        <td><?php if($row['feedback_status']==0){echo 'Replied';}else{echo 'Pending';}?></td>
                                        <td><a href="feedbackreply.php?feedback_id=<?php echo $row['feedback_id'];?>" target="_blank"><i class="material-icons-outlined">reply</i> Reply</a></td>
                                    </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<script src="../assets/js/main.js"></script>
<script src="../assets/js/disableKeys.js"></script>
<script>
    $(document).ready(function(){
        function load_unseen_notification(view = ''){
        $.ajax({
            url:"fetch.php",
            method:"POST",
            data:{view:view},
            dataType:"json",
            success:function(data){
                $('.dropdown-menu').html(data.notification);
                if(data.unseen_notofication > 0){
                    $('.count').html(data.unseen_notofication);
                }
            }
        });
    }
    load_unseen_notification();
    $('$feedback_form').on('submit', function(event){
        event.preventDefault();
        if($('$subject').val() != '' && $('#comment').val() != ''){
            var form_data = $(this).serialize();
            $.ajax({
                url:"insert.php",
                method:"POST",
                data:form_data,
                success:function(data){
                    $('feedback_form')[0].reset();
                    load_unseen_notification();
                }
            })
        }else{
            alert('Both fields are required');
        }
    });
});
</script>
</body>
</html>
<?php } ?>