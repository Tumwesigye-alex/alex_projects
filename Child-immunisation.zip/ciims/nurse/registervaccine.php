<?php
// Start Session
session_start();
error_reporting(0);
// Include Database Connection
require_once '../includes/config/database.php';
// Check if session is set to true
if(strlen($_SESSION['login'])==0){
	header("Location: ../index.php");
	exit();
}else{
    if(isset($_POST['submit'])){
        $vaccine_package=$_POST['vaccine_package'];
        $vaccine_name=$_POST['vaccine_name'];
        $vaccine_protects=$_POST['vaccine_protects'];
        $vaccine_admin_mode=$_POST['vaccine_admin_mode'];

        $sql=mysqli_query($con, "SELECT * FROM vaccines WHERE vaccine_package='$vaccine_package'");
        if(mysqli_num_rows($sql)>0){
            $_SESSION['msg']='Sorry, this package '.$vaccine_package.' is already registered!!';
        }else{
            if(empty($_POST['vaccine_name']) || empty($_POST['vaccine_admin_mode'])){
                $_SESSION['msg']='Please fill all fields to proceed !!';
            }else{
                $query=mysqli_query($con, "INSERT INTO vaccines(vaccine_package, vaccine_name, vaccine_protects, vaccine_admin_mode) VALUES('$vaccine_package', '$vaccine_name', '$vaccine_protects', '$vaccine_admin_mode')");
                if($query){
                    $_SESSION['msg']='Vaccine registered';
                }else{
                    $_SESSION['msg']='Something went wrong';
                }
            }
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    $sql=mysqli_query($con, "SELECT * FROM sysinfo");
    while($row=mysqli_fetch_assoc($sql)){?>
    <title><?php echo $row['fullname']." | ".$row['shortname'];;?></title>
    <?php } ?>
    <!-- Bootstrap -->
    <link rel="stylesheet" href="../assets/css/bootstrap.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- Material Icons -->
    <link rel="stylesheet" href="../assets/icons/material-icons.woff2">
    <!-- Current Time JS -->
    <script type="text/javascript" src="../assets/js/dateTime.js"></script>
    <!-- Favicon -->
    <link rel="shortcut icon" href="../components/favicon/favicon.png" type="image/x-icon">
</head>
<body>
    <!-- Wrapper -->
    <div class="wrapper">
        <!-- Header Section -->
        <?php if($_SESSION['login']!=""){ require_once 'includes/navbar/navbar.php';}?>
        <!-- Sidebar -->
        <?php if($_SESSION['login']!=""){ require_once 'includes/sidebar/sidebar.php';}?>
        <!-- Right Section -->
        <div class="main-wrapper">
            <div class="container">
                <div class="row pt-2">
                    <div class="col">
                        <p class="bold blue">Register Vaccines</p>
                        <form method="POST" autocomplete="off">
                            <div class="row">
                                <div class="col-lg-6 col-md-6">
                                    <label for="package">Vaccine Package</label>
                                    <select name="vaccine_package"  id="mySelect" class="input-field">
                                        <option value="None">Select</option>
                                        <option value="At Birth">At Birth</option>
                                        <option value="Six Weeks">Six Weeks</option>
                                        <option value="Ten Weeks">Ten Weeks</option>
                                        <option value="Fourteen Weeks">Fourteen Weeks</option>
                                        <option value="Nine Months">Nine Months</option>
                                    </select>
                                </div>
                                <div class="col-lg-6 col-md-6">
                                    <label for="vaccine">Vaccine Name</label>
                                    <select name="vaccine_name"  id="mySelect" class="input-field">
                                        <option value="None">Select</option>
                                        <option value="Polio 0, BCG">Polio 0, BCG</option>
                                        <option value="DPT-HebB+Hib1, Polio 2">DPT-HebB+Hib1, Polio 2</option>
                                        <option value="Polio 2, DPT-HebB+Hib 2">Polio 2, DPT-HebB+Hib 2</option>
                                        <option value="Polio 3, DPT-HebB+Hib 3">Polio 3, DPT-HebB+Hib 3</option>
                                        <option value="Measles">Measles</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row pt-4">
                                <div class="col-lg-6 col-md-6">
                                    <label for="protects">Vaccine Protects</label>
                                    <select name="vaccine_protects"  id="mySelect" class="input-field">
                                        <option value="None">Select</option>
                                        <option value="Polio, Tuberculosis">Polio, Tuberculosis</option>
                                        <option value="Diphtheria/Tetanus/Whooping Cough /Hepatitis B/Haemophilus Influenzae type B, Polio">Diphtheria/Tetanus/Whooping Cough /Hepatitis B/Haemophilus Influenzae type B, Polio</option>
                                        <option value="Polio, Diphtheria/Tetanus/Whooping Cough/ Hepatitis B/Haemophilus Influenzae type B">Polio, Diphtheria/Tetanus/Whooping Cough/ Hepatitis B/Haemophilus Influenzae type B</option>
                                        <option value="Polio, Diphtheria/Tetanus/Whooping Cough /Hepatitis B/Haemophilus Influenzae type B">Polio, Diphtheria/Tetanus/Whooping Cough /Hepatitis B/Haemophilus Influenzae type B</option>
                                        <option value="Measles">Measles</option>
                                    </select>
                                </div>
                                <div class="col-lg-6 col-md-6">
                                    <label for="adminmode">Vaccine Administration Mode</label>
                                    <select name="vaccine_admin_mode"  id="mySelect" class="input-field">
                                        <option value="None">Select</option>
                                        <option value="Mouth Drops, Left Upper Arm">Mouth Drops, Left Upper Arm</option>
                                        <option value="Left Upper Thigh, Mouth Drops">Left Upper Thigh, Mouth Drops</option>
                                        <option value="Mouth Drops, Left Upper Thigh">Mouth Drops, Left Upper Thigh</option>
                                        <option value="Fourteen Weeks">Mouth Drops, Left Upper Thigh</option>
                                        <option value="Left Upper Arm">Left Upper Arm</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row pt-4">
                                <div class="col">
                                    <button type="submit" name="submit" class="button button-main">Register Vaccine</button>
                                </div>
                            </div>
                        </form>
                        <div class="row pt-4">
                            <div class="col">
                                <?php echo $_SESSION['msg'];?>
                                <?php echo $_SESSION['msg']="";?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<script src="../assets/js/main.js"></script>
<script src="../assets/js/disableKeys.js"></script>
<script>
    document.addEventListener("DOMContentLoaded", function(){
        // Get the select element
        const selectElement = document.getElementById('mySelect');
        // Add click event listener to the select element
        selectElement.addEventListener("click", function(){
            // Hide the first option when the user clicks on the form
            selectElement.options[0].style.display = "none";
        });
    });
</script>
</body>
</html>
<?php } ?>