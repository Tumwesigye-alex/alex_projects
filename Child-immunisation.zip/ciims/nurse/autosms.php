<?php
// Include Database Connection
require_once '../includes/config/database.php';

// Immunisation packages duration in days
$sixweeks = 42;
$tenweeks = 70;
$fourteenweeks = 98;
$ninemonths = 270;

// Create variable to store current date
$current_date = DATE('Y-m-d');
echo $current_date;

// Convert next immunisation visit date and subtract 2 days from it by getting next visit date from the database
$query=mysqli_query($con, "SELECT next_visit_date FROM immunisation_register");
while($row=mysqli_fetch_assoc($query)){
    $visit_date = $row['next_visit_date'];
}
// Create a variable to store the extracted date
$two_days_to = DATE('Y-m-d',strtotime($visit_date)-2);
echo $two_days_to;

// Select the mother to send sms for the next immunisation visit date
$sql=mysqli_query($con, "SELECT * FROM immunisation_register INNER JOIN child_register ON immunisation_register.child_immunised=child_register.regid");
while($row=mysqli_fetch_assoc($sql)){
    $mothers_names = strtoupper($row['mothers_names']); //Fetch mother's names
    $recipient = $row['mothers_contact']; //Fetch mother's contact to send sms
    echo $mothers_names;
    echo $recipient;
    // Create a condition to send the sms
    if($current_date == $two_days_to){
        $sms = 'Hello, '.$mothers_names.', you are reminded to bring your child for immunisation at MRRH on '.$visit_date.' Thank you';
    }
}
?>