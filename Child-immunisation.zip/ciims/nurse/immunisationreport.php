<?php
// Start Session
session_start();
error_reporting(0);
// Include Database Connection
require_once '../includes/config/database.php';
// Check if session is set to true
if(strlen($_SESSION['login'])==0){
	header("Location: ../index.php");
	exit();
}else{
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    $sql=mysqli_query($con, "SELECT * FROM sysinfo");
    while($row=mysqli_fetch_assoc($sql)){?>
    <title><?php echo $row['fullname']." | ".$row['shortname'];;?></title>
    <?php } ?>
    <!-- Bootstrap -->
    <link rel="stylesheet" href="../assets/css/bootstrap.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- Material Icons -->
    <link rel="stylesheet" href="../assets/icons/material-icons.woff2">
    <!-- Current Time JS -->
    <script type="text/javascript" src="../assets/js/dateTime.js"></script>
    <!-- Favicon -->
    <link rel="shortcut icon" href="../components/favicon/favicon.png" type="image/x-icon">
</head>
<body>
    <!-- Wrapper -->
    <div class="wrapper">
        <!-- Header Section -->
        <?php if($_SESSION['login']!=""){ require_once 'includes/navbar/navbar.php';}?>
        <!-- Sidebar -->
        <?php if($_SESSION['login']!=""){ require_once 'includes/sidebar/sidebar.php';}?>
        <!-- Right Section -->
        <div class="main-wrapper">
            <div class="container">
                <div class="row pt-2">
                    <div class="col">
                        <p class="blue">Select the date range in the form below to generate a child immunisation report between the date range values you select</p>
                        <form action="childimmunisationreport.php" method="POST" autocomplete="off" target="_blank">
                            <div class="row">
                                <div class="col-lg-4 col-md-4">
                                    <label for="">Start Date</label>
                                    <input type="date" name="startdate" class="input-field">
                                </div>
                                <div class="col-lg-4 col-md-4">
                                    <label for="">End Date</label>
                                    <input type="date" name="enddate" class="input-field">
                                </div>
                                <div class="col-lg-4 col-md-4 pt-4">
                                    <button type="submit" name="generate" class="btn btn-lg btn-secondary">Generate Report</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<script src="../assets/js/main.js"></script>
<script src="../assets/js/disableKeys.js"></script>
</body>
</html>
<?php } ?>