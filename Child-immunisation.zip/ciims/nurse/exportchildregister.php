<?php
require_once '../includes/config/database.php';
date_default_timezone_set('Africa/Kampala');
if(isset($_POST['export'])){
	header('Content-Type: text/csv; charset=utf-8');
	$docname="Child Register";
	$dash="-";
	$curdate=date("d-m-Y H:i:s");
	$filename=$docname.$dash.$curdate;
	header("Content-Disposition: attachment; filename=$filename.csv");
	$output=fopen("php://output", 'w');
	fputcsv($output, array('RegNo', 'Names', 'Gender', 'DOB', 'Weight at Birth', 'Birth Order', 'Place of Birth', 'Mother', 'Contact', 'Occupation', 'Father', 'Contact', 'Occupation', 'District', 'Subcounty', 'Parish', 'Village'));
	$query=mysqli_query($con, "SELECT regno, childsnames, gender, childsdob, weight_at_birth, birth_order, place_of_birth, mothers_names, mothers_contact, mothers_occupation, fathers_names, fathers_contact, fathers_occupation, district, subcounty, parish, village FROM child_register WHERE childs_status=1");
	while($row=mysqli_fetch_assoc($query)){
		fputcsv($output, $row);
	}
	fclose($output);
}