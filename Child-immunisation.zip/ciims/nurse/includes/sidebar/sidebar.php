<aside id="sidebar">
    <div class="sidebar-title">
        <div class="sidebar-brand">
            <span title="CIIMS">Child Immunisation</span>
        </div>
        <span class="material-icons-outlined" onclick="closeSidebar()">close</span>
    </div>
    <ul class="sidebar-list">
        <li class="sidebar-list-item">
            <a href="dashboard.php"><span class="material-icons-outlined">dashboard</span> Dashboard</a>
        </li>
        <li class="sidebar-list-item">
            <a href="registerchild.php"><span class="material-icons-outlined">local_library</span> Register Child</a>
        </li>
        <li class="sidebar-list-item">
            <a href="childregister.php"><span class="material-icons-outlined">local_library</span> Child Register</a>
        </li>
        <li class="sidebar-list-item">
            <a href="immunisechild.php"><span class="material-icons-outlined">menu_book</span> Immunise Child</a>
        </li>
        <li class="sidebar-list-item">
            <a href="immunisedchildren.php"><span class="material-icons-outlined">groups</span> Immunised Children</a>
        </li>
        <li class="sidebar-list-item">
            <a href="registervaccine.php"><span class="material-icons-outlined">vaccines</span> Register Vaccine</a>
        </li>
        <li class="sidebar-list-item">
            <a href="vaccines.php"><span class="material-icons-outlined">vaccines</span> List of Vaccines</a>
        </li>
        <li class="sidebar-list-item">
            <a href="immunisationreport.php"><span class="material-icons-outlined">poll</span> Immunisation Report</a>
        </li>
        <li class="sidebar-list-item">
            <a href="referencecheat.php"><span class="material-icons-outlined">book</span> Reference Cheat</a>
        </li>
        <li class="sidebar-list-item">
            <a href="feedback.php"><span class="material-icons-outlined">message</span> Feedback Section</a>
        </li>
        <li class="sidebar-list-item">
            <a href="sysinfo.php"><span class="material-icons-outlined">settings_applications</span> System Information</a>
        </li>
        
        <li class="sidebar-list-item dropdown">
            <a href="feedback.php" class="dropdown-toggle" data-toggel="dropdown">
                <span class="material-icons-outlined">message</span> Feedback Section <span class="label label-pill label-danger count"></span>
                <ul class="dropdown-menu"></ul>
            </a>
        </li>
        
        <!-- <li class="sidebar-list-item">
            <a href="#"><span class="material-icons-outlined">message</span> Feedback Section
                <span class="badge text-bg-secondary">4</span>
            </a>
        </li> -->
    </ul>
</aside>