<?php
// Start Session
session_start();
error_reporting(0);
// Include Database Connection
require_once '../includes/config/database.php';
// Check if session is set to true
if(strlen($_SESSION['login'])==0){
	header("Location: ../index.php");
	exit();
}else{
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    $sql=mysqli_query($con, "SELECT * FROM sysinfo");
    while($row=mysqli_fetch_assoc($sql)){?>
    <title><?php echo $row['fullname']." | ".$row['shortname'];;?></title>
    <?php } ?>
    <!-- Bootstrap -->
    <link rel="stylesheet" href="../assets/css/bootstrap.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- Material Icons -->
    <link rel="stylesheet" href="../assets/icons/material-icons.woff2">
    <!-- Current Time JS -->
    <script type="text/javascript" src="../assets/js/dateTime.js"></script>
    <!-- Favicon -->
    <link rel="shortcut icon" href="../components/favicon/favicon.png" type="image/x-icon">
</head>
<body>
    <!-- Wrapper -->
    <div class="wrapper">
        <!-- Header Section -->
        <?php if($_SESSION['login']!=""){ require_once 'includes/navbar/navbar.php';}?>
        <!-- Sidebar -->
        <?php if($_SESSION['login']!=""){ require_once 'includes/sidebar/sidebar.php';}?>
        <!-- Right Section -->
        <div class="main-wrapper">
            <div class="container">
                <div class="row pt-2">
                    <div class="col">
                        <p class="blue">List of all immunised Children and their next immunisation visit dates</p>
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover" id="visits">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Child Names</th>
                                        <th>Package</th>
                                        <th>Vaccine</th>
                                        <th>Date</th>
                                        <th>Next Visit</th>
                                        <th>Remarks</th>
                                        <th>O/Vaccine</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $sql=mysqli_query($con, "SELECT * FROM immunisation_register INNER JOIN child_register ON immunisation_register.child_immunised=child_register.regid INNER JOIN vaccines ON immunisation_register.vaccine_administered=vaccines.vaccineid");
                                    $count=0;
                                    while($row=mysqli_fetch_assoc($sql)){$count++;?>
                                    <tr>
                                        <td><?php echo $count;?></td>
                                        <td><?php echo $row['childsnames'];?></td>
                                        <td><?php echo $row['vaccine_package'];?></td>
                                        <td><?php echo $row['vaccine_name'];?></td>
                                        <td><?php echo date('D d M Y',strtotime($row['date_immunised']));?></td>
                                        <td><?php if($row['next_visit_date']!=NULL){
                                            echo date('D d M Y',strtotime($row['next_visit_date']));
                                        }
                                        else{
                                            echo 'Complete';
                                        };?></td>
                                        <td><?php echo $row['health_remarks'];?></td>
                                        <td><?php echo $row['other_vaccine'];?></td>
                                    </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<script src="../assets/js/main.js"></script>
<script src="../assets/js/disableKeys.js"></script>
</body>
</html>
<?php } ?>