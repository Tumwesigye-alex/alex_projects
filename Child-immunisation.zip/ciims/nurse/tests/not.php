<!DOCTYPE html>
<html>
<head>
    <title>Unread Messages</title>
    <style>
        /* Basic styling for the notifications */
        .notifications {
            max-width: 400px;
            margin: 20px auto;
            padding: 10px;
            border: 1px solid #ccc;
            background-color: #f9f9f9;
            font-family: Arial, sans-serif;
        }

        .notification {
            position: relative;
            padding: 10px;
            border-bottom: 1px solid #ccc;
            cursor: pointer;
        }

        .notification:last-child {
            border-bottom: none;
        }

        .unread {
            font-weight: bold;
        }

        .unread-counter {
            position: absolute;
            top: 8px;
            left: -25px;
            padding: 4px 8px;
            border-radius: 50%;
            background-color: #ff4500;
            color: white;
            font-size: 12px;
        }

        .info-container {
            display: none;
            margin-top: 10px;
            padding: 10px;
            border: 1px solid #ccc;
            background-color: #fff;
        }
    </style>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const notifications = document.querySelectorAll('.notification');

            notifications.forEach(notification => {
                notification.addEventListener('click', function () {
                    const infoContainer = this.querySelector('.info-container');
                    infoContainer.style.display = (infoContainer.style.display === 'block') ? 'none' : 'block';
                });
            });
        });
    </script>
</head>
<body>
    <?php
    // ... Your PHP code to fetch unread messages ...
    ?>

    <div class="notifications">
        <?php if ($unreadCount > 0) : ?>
            <h2>Unread Messages (<?php echo $unreadCount; ?>)</h2>
        <?php else : ?>
            <h2>No unread messages.</h2>
        <?php endif; ?>
        <ul>
            <?php foreach ($unreadMessages as $message) : ?>
                <li class="notification">
                    <?php if ($message['is_read'] === '0') : ?>
                        <span class="unread-counter"><?php echo $message['id']; ?></span>
                    <?php endif; ?>
                    <strong>ID:</strong> <?php echo $message['id']; ?><br>
                    <?php echo nl2br($message['content']); ?><br>
                    <em>Received at <?php echo $message['created_at']; ?></em>
                    <div class="info-container">
                        <!-- Additional information can be displayed here -->
                        <!-- For example: <?php echo $message['additional_info']; ?> -->
                    </div>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
</body>
</html>