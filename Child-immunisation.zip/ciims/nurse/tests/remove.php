<?php
$filename = "remove.php";

// Use pathinfo() function to get the file information
$fileInfo = pathinfo($filename);

// Get the filename without the extension
$filenameWithoutExtension = $fileInfo['filename'];

echo "Original Filename: " . $filename . "<br>";
echo "Filename without Extension: " . $filenameWithoutExtension;
?>
