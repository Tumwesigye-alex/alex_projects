<!DOCTYPE html>
<html>
<head>
    <title>Unread Messages</title>
    <style>
        /* Basic styling for the notifications */
        .notifications {
            max-width: 400px;
            margin: 20px auto;
            padding: 10px;
            border: 1px solid #ccc;
            background-color: #f9f9f9;
            font-family: Arial, sans-serif;
        }

        .notification {
            position: relative;
            padding: 10px;
            border-bottom: 1px solid #ccc;
        }

        .notification:last-child {
            border-bottom: none;
        }

        .unread {
            font-weight: bold;
        }

        .unread-counter {
            position: absolute;
            top: 8px;
            left: -25px;
            padding: 4px 8px;
            border-radius: 50%;
            background-color: #ff4500;
            color: white;
            font-size: 12px;
        }
    </style>
</head>
<body>
    <?php
    // Replace these variables with your database credentials
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "ciims";

    // Create a database connection
    $conn = mysqli_connect($servername, $username, $password, $dbname);

    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Fetch unread messages from the database
    $query = "SELECT feedbackid, description, date_sent FROM feedback WHERE feedback_status = 0";
    $result = mysqli_query($conn, $query);

    // Count the number of unread messages
    $unreadCount = mysqli_num_rows($result);
    ?>

    <div class="notifications">
        <?php if ($unreadCount > 0) : ?>
            <h2>Unread Messages (<?php echo $unreadCount; ?>)</h2>
        <?php else : ?>
            <h2>No unread messages.</h2>
        <?php endif; ?>
        <ul>
            <?php while ($message = mysqli_fetch_assoc($result)) : ?>
                <li class="notification">
                    <?php if ($message['feedback_status'] === '0') : ?>
                        <span class="unread-counter"><?php echo $message['feedbackid']; ?></span>
                    <?php endif; ?>
                    <strong>ID:</strong> <?php echo $message['feedbackid']; ?><br>
                    <?php echo nl2br($message['content']); ?><br>
                    <em>Received at <?php echo $message['date_sent']; ?></em>
                </li>
            <?php endwhile; ?>
        </ul>
    </div>

    <?php
    // Close the database connection
    mysqli_close($conn);
    ?>
</body>
</html>