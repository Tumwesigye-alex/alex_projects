<?php
// Start Session
session_start();
error_reporting(0);
// Include Database Connection
require_once '../includes/config/database.php';
// Check if session is set to true
if(strlen($_SESSION['login'])==0){
	header("Location: ../index.php");
	exit();
}else{
    $feedback_id=intval($_GET['feedback_id']);
    if(isset($_POST['submit'])){
        $reply=$_POST['reply'];

        if(empty($_POST['reply'])){
            $_SESSION['msg']='<font color="red">Please, reply field can\'t be blank</font>';
        }else{
            $query=mysqli_query($con, "UPDATE feedback SET reply='$reply', date_replied=NOW(), replied_by='".$_SESSION['surname']."', reply_status='1', feedback_status='0' WHERE feedback_id='$feedback_id'");
            if($query){
                $_SESSION['msg']='<font color="blue">Feedback sent successfully</font>';
            }else{
                $_SESSION['msg']='<font color="red">Something went wrong</font>';
            }
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    $sql=mysqli_query($con, "SELECT * FROM sysinfo");
    while($row=mysqli_fetch_assoc($sql)){?>
    <title><?php echo $row['fullname']." | ".$row['shortname'];;?></title>
    <?php } ?>
    <!-- Bootstrap -->
    <link rel="stylesheet" href="../assets/css/bootstrap.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- Material Icons -->
    <link rel="stylesheet" href="../assets/icons/material-icons.woff2">
    <!-- Current Time JS -->
    <script type="text/javascript" src="../assets/js/dateTime.js"></script>
    <!-- Favicon -->
    <link rel="shortcut icon" href="../components/favicon/favicon.png" type="image/x-icon">
    <style>
        .feedback{
            line-height: 1rem;
        }
        .reply-section{
            background: #fafafa;
            width: 600px;
            height: 500px;
            position: fixed;
            padding: 15px;
            z-index: 10;
            border-radius: 5px;
            overflow-x: hidden;
            overflow-y: auto;
        }
    </style>
</head>
<body>
    <!-- Wrapper -->
    <div class="wrapper">
        <!-- Header Section -->
        <?php if($_SESSION['login']!=''){ require_once 'includes/navbar/navbar.php';}?>
        <!-- Sidebar -->
        <?php if($_SESSION['login']!=''){ require_once 'includes/sidebar/sidebar.php';}?>
        <!-- Right Section -->
        <div class="main-wrapper">
            <div class="container">
                <div class="row">
                    <!-- First Column -->
                    <div class="col-lg-5 col-md-5">
                        <p class="bold blue">Feedback Reply Section</p>
                        <form method="POST" id="feedback" autocomplete="off">
                            <?php
                            $feedback_id=$_GET['feedback_id'];
                            $sql=mysqli_query($con, "SELECT * FROM feedback INNER JOIN child_register ON feedback.childs_regno=child_register.regid INNER JOIN vaccines ON feedback.feedback_id=vaccines.vaccineid WHERE feedback_id='$feedback_id'");
                            while($row=mysqli_fetch_assoc($sql)){?>
                            <div class="row">
                                <div class="col">
                                    <label for="">Child's RegNo</label>
                                    <input type="text" class="input-field" value="<?php echo $row['regno'];?>" readonly>
                                </div>
                            </div>
                            <div class="row pt-2">
                                <div class="col">
                                    <label for="">Package received</label>
                                    <input type="text" class="input-field" value="<?php echo $row['vaccine_package'];?>" readonly>
                                </div>
                            </div>
                            <div class="row pt-2">
                                <div class="col">
                                    <label for="">Date of Vaccination</label>
                                    <input type="text" class="input-field" value="<?php echo $row['date_received'];?>" readonly>
                                </div>
                            </div>
                            <div class="row pt-2">
                                <div class="col">
                                    <label for="">Reply</label>
                                    <textarea name="reply" rows="4" class="input-field" placeholder="Provide ellaborative feedback..."></textarea>
                                </div>
                            </div>
                            <div class="row pt-2">
                                <div class="col">
                                    <button type="submit" name="submit" class="button button-main button-block"><i class="material-icons-outlined">reply</i> Reply</button>
                                </div>
                            </div>
                            <div class="row pt-2">
                                <div class="col">
                                    <?php echo $_SESSION['msg'];?>
                                    <?php echo $_SESSION['msg']='';?>
                                </div>
                            </div>
                            <?php } ?>
                        </form>
                    </div>
                    <!-- Second Column -->
                    <div class="col-lg-7 col-md-7">
                        <p class="bold blue">Chats Section with the Mother</p>
                        <div class="reply-section">
                        <?php
                        $query=mysqli_query($con, "SELECT * FROM feedback INNER JOIN child_register ON feedback.feedback_id=child_register.regid WHERE feedback_id='$feedback_id'");
                        while($row=mysqli_fetch_assoc($query)){?>
                        <!-- Mother's Feedback -->
                        <div class="row">
                            <div class="col">
                                <div class="feedback">
                                    <p><?php echo $row['comment'];?></p>
                                    <p class="small"><?php echo 'Time: '.date('D d-M-Y H:i:s A',strtotime($row['date_sent']));?></p>
                                    <p class="bold blue"><?php echo $row['mothers_names'];?></p>
                                </div>
                            </div>
                        </div>
                        <!-- Nurse's Feedback -->
                        <div class="row pt-4">
                            <div class="col">
                                <div class="feedback">
                                    <p><?php echo $row['reply'];?></p>
                                    <p class="small"><?php echo 'Time: '.date('D d-M-Y H:i:s A',strtotime($row['date_replied']));?></p>
                                    <p class="bold blue"><?php echo $row['replied_by'];?></p>
                                </div>
                            </div>
                        </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<script src="../assets/js/main.js"></script>
<script src="../assets/js/disableKeys.js"></script>
</body>
</html>
<?php } ?>