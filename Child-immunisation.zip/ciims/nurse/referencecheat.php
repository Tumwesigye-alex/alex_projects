<?php
// Start Session
session_start();
error_reporting(0);
// Include Database Connection
require_once '../includes/config/database.php';
// Check if session is set to true
if(strlen($_SESSION['login'])==0){
	header("Location: ../index.php");
	exit();
}else{
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    $sql=mysqli_query($con, "SELECT * FROM sysinfo");
    while($row=mysqli_fetch_assoc($sql)){?>
    <title><?php echo $row['fullname']." | ".$row['shortname'];;?></title>
    <?php } ?>
    <!-- Bootstrap -->
    <link rel="stylesheet" href="../assets/css/bootstrap.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- Material Icons -->
    <link rel="stylesheet" href="../assets/icons/material-icons.woff2">
    <!-- Current Time JS -->
    <script type="text/javascript" src="../assets/js/dateTime.js"></script>
    <!-- Favicon -->
    <link rel="shortcut icon" href="../components/favicon/favicon.png" type="image/x-icon">
</head>
<body>
    <!-- Wrapper -->
    <div class="wrapper">
        <!-- Header Section -->
        <?php if($_SESSION['login']!=""){ require_once 'includes/navbar/navbar.php';}?>
        <!-- Sidebar -->
        <?php if($_SESSION['login']!=""){ require_once 'includes/sidebar/sidebar.php';}?>
        <!-- Right Section -->
        <div class="main-wrapper">
            <div class="container">
                <div class="row pt-2">
                    <div class="col">
                        <p class="blue">Generate child reference cheat</p>
                        <form method="POST" autocomplete="off">
                            <div class="row">
                                <div class="col-lg-10 col-md-10">
                                    <input type="text" name="searched" class="input-field" placeholder="Search child" title="Search child details using child's registration number, child's names, mother's names or father's names">
                                </div>
                                <div class="col-lg-2 col-md-2">
                                    <button type="submit" name="search" class="btn btn-lg btn-secondary" title="Click to search child">Submit</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="row pt-4">
                    <div class="col">
                        <?php
                        if(isset($_POST['search'])){
                            $searched=$_POST['searched'];

                            $sql=mysqli_query($con, "SELECT * FROM child_register WHERE childsnames='$searched' || regno='$searched' || mothers_names='$searched' || fathers_names='$searched'");
                            while($row=mysqli_fetch_assoc($sql)){?>
                            <div class="table-responsive">
                                <table class="table table-bordered table-hover" id="children">
                                    <thead>
                                        <tr>
                                            <th>Names</th>
                                            <th>RegNo</th>
                                            <th>Gender</th>
                                            <th>DOB</th>
                                            <th>Mother</th>
                                            <th>Contact</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td><?php echo $row['childsnames'];?></td>
                                            <td><?php echo $row['regno'];?></td>
                                            <td><?php echo $row['gender'];?></td>
                                            <td><?php echo $row['childsdob'];?></td>
                                            <td><?php echo $row['mothers_names'];?></td>
                                            <td><?php echo $row['mothers_contact'];?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <button onclick="printPdf()" class="button button-main">Print</button>
                        <?php } } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<script src="../assets/js/main.js"></script>
<script src="../assets/js/disableKeys.js"></script>
<script async>
    function printPdf(){
        const newWindow = window.open();

        const html = document.createElement("html");

        const head = document.head.cloneNode(true);

        // creating a new body element for our newWindow
        const body = document.createElement("body");

        // grab the elements that you want to convert to PDF
        const section = document
            .getElementById("children")
            .cloneNode(true);

        // you can append as many children as you like
        // this is where we add our elements to the new window.
        body.appendChild(section);

        html.appendChild(head);
        html.appendChild(body);

        // write content to the new window's document.
        newWindow.document.write(html.innerHTML);

        // close document to stop writing
        // otherwise new window may hang
        newWindow.document.close();
        
        // print content in new window as PDF
        newWindow.print();

        // close the new window after printing
        newWindow.close();
    }
</script>
</body>
</html>
<?php } ?>