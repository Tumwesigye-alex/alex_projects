<?php
// Start Session
session_start();
error_reporting(0);
// Include Database Connection
require_once '../includes/config/database.php';
// Check if the user is logged in
if(strlen($_SESSION['login']) == 0){
    header("Location: ../index.php");
    exit();
}else{
    if(isset($_POST['submit'])){
        $child_immunised=$_POST['child_immunised'];
        $vaccine_administered=$_POST['vaccine_administered'];
        $health_remarks=$_POST['health_remarks'];
        $other_vaccine=$_POST['other_vaccine'];
        $date_immunised=$_POST['date_immunised'];

        // ----------------------------------------------------------------
        // Convert immunisation package duration into days
        $sixweeks = 42;
        $tenweeks = 70;
        $fourteenweeks = 98;
        $ninemonths = 270;

        // Select vaccine administered from the database
        $sql="SELECT vaccineid, vaccine_package FROM vaccines WHERE vaccineid='$vaccine_administered'";
        $results=mysqli_query($con,$sql);
        $result=mysqli_fetch_assoc($results);  

        // Perform the conditions to auto calculate next visit date
        if($result['vaccine_package'] == "At Birth"){
            $vaccineid=$result['vaccineid'];
            $next_visit_date=date('Y-m-d', strtotime($date_immunised . " + " . $sixweeks . " days"));
        }elseif ($result['vaccine_package'] == "Six Weeks"){
            $vaccineid=$result['vaccineid'];
            $next_visit_date=date('Y-m-d', strtotime($date_immunised . " + " . $tenweeks . " days"));
        }elseif ($result['vaccine_package'] == "Ten Weeks"){
            $vaccineid=$result['vaccineid'];
            $next_visit_date=date('Y-m-d', strtotime($date_immunised . " + " . $fourteenweeks . " days"));
        }elseif ($result['vaccine_package'] == "Fourteen Weeks"){
            $vaccineid=$result['vaccineid'];
            $next_visit_date=date('Y-m-d', strtotime($date_immunised . " + " . $ninemonths . " days"));
        }elseif ($result['vaccine_package'] == "Nine Months"){
            $vaccineid=$result['vaccineid'];
            $next_visit_date=NULL;
        }else{
            // Invalid vaccine package, handle the error or provide a default value
            $next_visit_date = 'Invalid Vaccine Package';
        }
        // ----------------------------------------------------------------
        // First, select the child's ID to immunize from the database
        $childimmunised="SELECT regid FROM child_register WHERE regno=?";
        $immunisechild=mysqli_prepare($con, $childimmunised);
        mysqli_stmt_bind_param($immunisechild, "s", $child_immunised);
        mysqli_stmt_execute($immunisechild);
        $row=mysqli_stmt_get_result($immunisechild);
        $childid=mysqli_fetch_assoc($row)['regid'];

        // Using prepared statements to avoid SQL injection select the vaccine package
        $query="SELECT * FROM immunisation_register INNER JOIN vaccines ON immunisation_register.vaccine_administered=vaccines.vaccineid WHERE child_immunised=? AND vaccine_administered=?";
        $stmt=mysqli_prepare($con, $query);
        mysqli_stmt_bind_param($stmt, "is", $childid, $vaccine_administered);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_store_result($stmt);
        if(mysqli_stmt_num_rows($stmt) > 0){
            $_SESSION['msg']='Sorry, this child has already been vaccinated for this package ';
        }else{
            if(empty($_POST['child_immunised'])){
                $_SESSION['msg']='Please enter the child\'s registration number to proceed';
            }else{
                // Insert the immunisation record into the database
                $insert_query="INSERT INTO immunisation_register(child_immunised, vaccine_administered, date_immunised, health_remarks, other_vaccine, location, next_visit_date) VALUES (?, ?, ?, ?, ?, ?, ?)";
                $insert_stmt=mysqli_prepare($con, $insert_query);
                mysqli_stmt_bind_param($insert_stmt, "issssss", $childid, $vaccineid, $date_immunised, $health_remarks, $other_vaccine, $location, $next_visit_date);
                // Debugging: Output the query parameters
                error_log('Child ID: ' . $childid);
                error_log('Vaccine Administered: ' . $vaccine_administered);
                error_log('Date Immunised: ' . $date_immunised);
                error_log('Remarks: ' . $health_rmarks);
                error_log('Any other: ' . $other_vaccine);
                error_log('Next Visit Date: ' . $next_visit_date);
                $query_result=mysqli_stmt_execute($insert_stmt);

                if($query_result){
                    $_SESSION['msg']='Child\'s immunisation records saved';
                // Send confirmation SMS to the parent of the child's package and vaccine received and the next scheduled visit date via SMS to the mother's phone number
                function SendSMS($message_type,$message_category,$number,$message){ 
                    $username='0778147485';
                    $password='mackol44';
                    $sender='CIIMS';
                    $url="sms.thepandoranetworks.com/API/send_sms/?";
                    $parameters="number=[number]&message=[message]&username=[username]&password=[password]&sender=[sender]&message_type=[message_type]&message_category=[message_category]";
                    $parameters=str_replace("[message]", urlencode($message), $parameters);
                    $parameters=str_replace("[sender]", urlencode($sender),$parameters);
                    $parameters=str_replace("[number]", urlencode($number),$parameters);
                    $parameters=str_replace("[username]", urlencode($username),$parameters);
                    $parameters=str_replace("[password]", urlencode($password),$parameters);
                    $parameters=str_replace("[message_type]", urlencode($message_type),$parameters);
                    $parameters=str_replace("[message_category]", urlencode($message_category),$parameters);
                    $live_url="https://".$url.$parameters;
                    $parse_url=file($live_url);
                    $response=$parse_url[0];
                    return json_decode($response, true);
                    }
                    // Select mother's name and phone number for the child vaccinated from the database using the child's vaccinated registration number
                    $sql=mysqli_query($con, "SELECT mothers_names, mothers_contact FROM immunisation_register INNER JOIN child_register ON immunisation_register.child_immunised=child_register.regid WHERE child_immunised='$childid'");
                    while($row=mysqli_fetch_assoc($sql)){
                        $mothers_names=$row['mothers_names'];
                        $mothers_contact=$row['mothers_contact'];
                        $fathers_names=$row['fathers_names'];
                        $fathers_contact=$row['fathers_contact'];
                    }
                    // Select vaccine administered to the child from the database
                    $sql="SELECT vaccine_name FROM vaccines WHERE vaccineid='$vaccine_administered'";
                    $results = mysqli_query($con,$sql);
                    $result = mysqli_fetch_assoc($results);
                    $package_received = $result['vaccine_name'];
                    // Validate last vaccine message upon completing vaccinaion
                    if($next_visit_date==NULL){
                        $nextdate='Vaccination Completed';
                    }
                    else{
                        $nextdate='Your next immunisation visit date is '.DATE('D d-M-Y',strtotime($next_visit_date));
                    }
                    // Compose message to send to the mother and father
                    $mothers_sms='Hello, '.$mothers_names.'. Thank you for immunising your child against '.$package_received.'. '.$nextdate.'. Thank you. A healthy child, a better living';
                    $fathers_sms='Hello, '.$fathers_names.'. Thank you for immunising your child against '.$package_received.'. '.$nextdate.'. Thank you. A healthy child, a better living';
                    // function calling
                    SendSMS('non_customised','bulk', $mothers_contact, $mothers_sms);
                    SendSMS('non_customised','bulk', $fathers_contact, $fathers_sms);
                }else{
                    // Debugging: Output the query error
                    error_log('Query Error: ' . mysqli_error($con));
                    $_SESSION['msg']='Oops, Child immunisation records not saved. If Child is already registered, try again. If the child is not yet registered, first register the child and use the child\'s valid registration number';
                }
            }
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    $sql=mysqli_query($con, "SELECT * FROM sysinfo");
    while($row=mysqli_fetch_assoc($sql)){?>
    <title><?php echo $row['fullname']." | ".$row['shortname'];;?></title>
    <?php } ?>
    <!-- Bootstrap -->
    <link rel="stylesheet" href="../assets/css/bootstrap.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- Material Icons -->
    <link rel="stylesheet" href="../assets/icons/material-icons.woff2">
    <!-- Current Time JS -->
    <script type="text/javascript" src="../assets/js/dateTime.js"></script>
    <!-- Favicon -->
    <link rel="shortcut icon" href="../components/favicon/favicon.png" type="image/x-icon">
</head>
<body>
    <!-- Wrapper -->
    <div class="wrapper">
        <!-- Header Section -->
        <?php if($_SESSION['login']!=""){ require_once 'includes/navbar/navbar.php';}?>
        <!-- Sidebar -->
        <?php if($_SESSION['login']!=""){ require_once 'includes/sidebar/sidebar.php';}?>
        <!-- Right Section -->
        <div class="main-wrapper">
            <div class="container">
                <div class="row pt-2">
                    <div class="col">
                        <p class="blue">Record Child Immunisation Records</p>
                        <form method="POST" autocomplete="off">
                            <div class="row">
                                <div class="col-lg-6 col-md-6">
                                    <label for="regno">Child Registration Number</label>
                                    <input type="text" name="child_immunised" class="input-field" placeholder="Enter RegNo">
                                </div>
                                <div class="col-lg-6 col-md-6">
                                    <label for="package">Package Administered</label>
                                    <select name="vaccine_administered" id="package" class="input-field">
                                        <option>Select</option>
                                        <?php
                                        $sql=mysqli_query($con, "SELECT * FROM vaccines");
                                        while($row=mysqli_fetch_assoc($sql)){?>
                                        <option value="<?php echo $row['vaccineid'];?>"><?php echo $row['vaccine_package'];?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>
                            <div class="row pt-4">
                                <div class="col-lg-6 col-md-6">
                                    <label for="date">Date Immunised</label>
                                    <input type="date" name="date_immunised" class="input-field">
                                </div>
                                <div class="col-lg-6 col-md-6">
                                    <label for="nextdate">Location</label>
                                    <input type="text" name="location" class="input-field" placeholder="Location">
                                </div>
                            </div>
                            <div class="row pt-4">
                                <div class="col-lg-6 col-md-6">
                                    <label for="date">Health Remarks</label>
                                    <input type="text" name="health_remarks" class="input-field" placeholder="Health remarks">
                                </div>
                                <div class="col-lg-6 col-md-6">
                                    <label for="nextdate">Any Other Vaccine Administered</label>
                                    <input type="text" name="other_vaccine" class="input-field" placeholder="Any other vaccine">
                                </div>
                            </div>
                            <div class="row pt-4">
                                <div class="col">
                                    <button type="submit" name="submit" class="button button-main">Immunise Child</button>
                                </div>
                            </div>
                        </form>
                        <div class="row pt-4">
                            <div class="col">
                                <?php echo $_SESSION['msg'];?>
                                <?php echo $_SESSION['msg']="";?>
                            </div>
                        </div>
                        <!-- <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<script src="../assets/js/main.js"></script>
<script src="../assets/js/dateTime.js"></script>
<script src="../assets/js/disableKeys.js"></script>
<script src="../assets/js/bootstrap.js"></script>
<!-- Fetch Next Visit Date -->
<script>
    function nextVisitDate(){

    }
</script>
</body>
</html>
<?php } ?>