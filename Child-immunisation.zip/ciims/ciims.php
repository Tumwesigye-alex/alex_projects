<?php
// Start Session
session_start();
error_reporting(0);
// Include Database Connection
require_once 'includes/config/database.php';
if(isset($_POST['signup'])){
  $surname=$_POST['surname'];
  $lastname=$_POST['lastname'];
  $contact=$_POST['contact'];
  $username=$_POST['username'];
  $userrole=$_POST['userrole'];
  $password=$_POST['password'];

  $query=mysqli_query($con, "SELECT * FROM users WHERE username='$username' OR contact='$contact'");
  if(mysqli_num_rows($query)>0){
    $_SESSION['msg']='User with this username <b><font color="blue">'.$username.'</font></b> or contact <b>'.$contact.'</b> already exists';
  }
  else{
    if(empty($_POST['surname']) AND empty($_POST['lastname']) AND empty($_POST['contact']) AND empty($_POST['username']) AND empty($_POST['password'])){
    $_SESSION['msg']='Please fill all Fields';
    }
    elseif(isset($_POST['surname'])){
      $surname=filter_var($_POST['surname'], FILTER_SANITIZE_STRING);

      if(isset($_POST['lastname'])){
        $lastname=filter_var($_POST['lastname'], FILTER_SANITIZE_STRING);
      }
      if(isset($_POST['contact'])){
        $contact=filter_var($_POST['contact'], FILTER_SANITIZE_STRING);
      }
      if(isset($_POST['username'])){
        $username=filter_var($_POST['username'], FILTER_SANITIZE_STRING);
      }
      if(isset($_POST['password'])){
        $hashedpassword=filter_var(MD5($_POST['password']), FILTER_SANITIZE_STRING);
      }
    }
    $query=mysqli_query($con, "INSERT INTO users(surname, lastname, contact, username, userrole, password) VALUES('$surname', '$lastname', '$contact', '$username', '$userrole', '$hashedpassword')");
    if($query) {
      $_SESSION['msg']='Dear, ' . $surname . " " . $lastname . '. Your account has been successfully created. ' . 'We have sent your login details to your phone number.';
      // Send Login details via SMS to the provided phone number
      function SendSMS($message_type,$message_category,$number,$message){ 
      $username='0778147485';
      $password='mackol44';
      $sender='CIIMS';
      $url="sms.thepandoranetworks.com/API/send_sms/?";
      $parameters="number=[number]&message=[message]&username=[username]&password=[password]&sender=[sender]&message_type=[message_type]&message_category=[message_category]";
      $parameters=str_replace("[message]", urlencode($message), $parameters);
      $parameters=str_replace("[sender]", urlencode($sender),$parameters);
      $parameters=str_replace("[number]", urlencode($number),$parameters);
      $parameters=str_replace("[username]", urlencode($username),$parameters);
      $parameters=str_replace("[password]", urlencode($password),$parameters);
      $parameters=str_replace("[message_type]", urlencode($message_type),$parameters);
      $parameters=str_replace("[message_category]", urlencode($message_category),$parameters);
      $live_url="https://".$url.$parameters;
      $parse_url=file($live_url);
      $response=$parse_url[0];
      return json_decode($response, true);
      }
      $recipient=$contact;
      $siteurl='https://ciims.com';
      $msg='Thank you '.$surname.' '.$lastname.' for creating an account on CIIMS. Visit '.$siteurl.' to login. Your username is '.$username.', user type is '.$userrole.' and password is '.$password;
      // function calling
      SendSMS('non_customised','bulk', $recipient, $msg);
    }
    else{
      $_SESSION['msg']='Something went wrong';
    }
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?php
  $sql=mysqli_query($con, "SELECT * FROM sysinfo");
  while($row=mysqli_fetch_assoc($sql)){?>
  <title><?php echo $row['fullname'];?></title>
  <?php } ?>
  <!-- Custom CSS -->
  <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="assets/css/style.css">
  <!-- Material Icons -->
  <link rel="stylesheet" type="text/css" href="assets/icons/material-icons.woff2.css">
  <!-- Favicon -->
  <link rel="shortcut icon" href="components/favicon/favicon.png" type="image/x-icon">
  <style type="text/css">
  /* The message box is shown when the user clicks on the password field */
  #message{
    display: none;
    background: #f1f1f1;
    color: #000000;
    position: relative;
    padding: 20px;
    margin-top: 10px;
  }
  #message p{
    padding: 10px 35px;
    font-size: 18px;
  }
  /* Add a green text color and a checkmark when the requirements are right */
  .valid{
    color: green;
  }
  .valid:before{
    position: relative;
    left: -35px;
  }
  /* Add a red text color and an "x" icon when the requirements are wrong */
  .invalid{
    color: red;
  }
  .invalid:before {
    position: relative;
    left: -35px;
  }
</style>
</head>
<body>
<div class="container">
    <div class="row pt-2">
        <div class="col center">
          <img src="media/photos/logo.png" alt="Logo" width="80px" height="80px">
          <p class="blue pt-2">Child Immunisation Information Management System - CIIMS</p>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-6 col-md-6 col-sm-12 offset-lg-3 offset-md-3 offset-sm-12">
        <p class="bold">Create your account here</p>
            <form method="POST" autocomplete="off">
                <div class="row">
                  <div class="col">
                    <input type="text" name="surname" class="form-control" placeholder="Surname...">
                  </div>
                </div>
                <div class="row pt-4">
                  <div class="col">
                    <input type="text" name="lastname" class="form-control" placeholder="Last name...">
                  </div>
                </div>
                <div class="row pt-4">
                  <div class="col">
                    <input type="tel" name="contact" pattern="[0-9]{10,10}" minlength="10" maxlength="10" class="form-control" placeholder="Contact...">
                  </div>
                </div>
                <div class="row pt-4">
                  <div class="col">
                    <input type="text" name="username" class="form-control" pattern="[A-Z\a-z]{3,10}" placeholder="Username...">
                  </div>
                </div>
                <div class="row pt-4">
                  <div class="col">
                    <input type="text" name="userrole" value="Admin" class="form-control" readonly>
                  </div>
                </div>
                <div class="row pt-4">
                  <div class="col" style="position:relative;display:flex;align-items:center">
                    <input type="password" name="password" id="password" class="form-control" placeholder="Password..." pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one uppercase and lowercase letter, and at least 8 or more characters">
                    <i class="material-icons-outlined" style="position:absolute;right:30px;cursor:pointer" onclick="togglePassword()">visibility</i>
                  </div>
                </div>
                <div class="row pt-4">
                  <div class="col-lg-4">
                    <button type="submit" name="signup" class="btn btn-block btn-primary">SIGNUP</button>
                  </div>
                  <div class="col-lg-8">
                  <p>Already have an account? <a href="index.php">Login Here</a></p>
                </div>
              </div>
            </form>
          <div class="row pt-3">
            <div class="col">
              <span style="color: var(--blue);">
              <?php echo $_SESSION['msg'];?>
              <?php echo $_SESSION['msg']="";?>
              </span>
            </div>
          </div>
        </div>
    </div>
    <div class="row pt-4">
        <div class="col">
            <div id="message">
                <p>Password must contain the following:</p>
                <p id="letter" class="invalid">A <b>lowercase</b> letter</p>
                <p id="capital" class="invalid">A <b>capital or uppercase</b> letter</p>
                <p id="number" class="invalid">A <b>number</b></p>
                <p id="length" class="invalid">A Minimum of <b>8 characters</b></p>
            </div>
        </div>
    </div>
</div>
<script src="../assets/js/bootstrap.js"></script>
<script src="../assets/js/jquery.js"></script>
<script src="../assets/js/disableKeys.js"></script>
<!-- Show/Hide Password -->
<script>
function togglePassword(){
  var passwordField = document.getElementById("password");
  var icon = document.querySelector(".toggle-password");
  
  if(passwordField.type === "password"){
    passwordField.type = "text";
    icon.classList.remove("fa-eye-slash");
    icon.classList.add("fa-eye");
  }else{
    passwordField.type = "password";
    icon.classList.remove("fa-eye");
    icon.classList.add("fa-eye-slash");
  }
}
</script>
<!-- Validate Password -->
<script>
var myInput = document.getElementById("password");
var letter = document.getElementById("letter");
var capital = document.getElementById("capital");
var number = document.getElementById("number");
var length = document.getElementById("length");

// When the user clicks on the password field, show the message box
myInput.onfocus = function(){
  document.getElementById("message").style.display = "block";
}

// When the user clicks outside of the password field, hide the message box
myInput.onblur = function(){
  document.getElementById("message").style.display = "none";
}
// When the user starts to type something inside the password field
myInput.onkeyup = function(){
  // Validate lowercase letters
  var lowerCaseLetters = /[a-z]/g;
  if(myInput.value.match(lowerCaseLetters)){
    letter.classList.remove("invalid");
    letter.classList.add("valid");
  }else{
    letter.classList.remove("valid");
    letter.classList.add("invalid");
}
  // Validate capital letters
  var upperCaseLetters = /[A-Z]/g;
  if(myInput.value.match(upperCaseLetters)){
    capital.classList.remove("invalid");
    capital.classList.add("valid");
  }else{
    capital.classList.remove("valid");
    capital.classList.add("invalid");
  }
  // Validate numbers
  var numbers = /[0-9]/g;
  if(myInput.value.match(numbers)){
    number.classList.remove("invalid");
    number.classList.add("valid");
  }else{
    number.classList.remove("valid");
    number.classList.add("invalid");
  }
  // Validate length
  if(myInput.value.length >= 8){
    length.classList.remove("invalid");
    length.classList.add("valid");
  }else{
    length.classList.remove("valid");
    length.classList.add("invalid");
  }
}
</script>
</body>
</html>