<?php
// Start session
session_start();
error_reporting(0);
// Include database connection
require_once '../includes/config/database.php';
// Check if session is set
if(strlen($_SESSION['parent'])==0){
	header("Location: index.php");
	exit();
}else{
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    $sql=mysqli_query($con, "SELECT * FROM sysinfo");
    while($row=mysqli_fetch_assoc($sql)){?>
    <title><?php echo $row['fullname']." | ".$row['shortname'];;?></title>
    <?php } ?>
    <!-- CSS -->
    <link rel="stylesheet" href="../assets/css/bootstrap.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- Material Icons -->
    <link rel="stylesheet" href="../assets/icons/material-icons.woff2">
    <!-- Favicon -->
    <link rel="shortcut icon" href="../components/favicon/favicon.png" type="image/x-icon">
    <!-- Current Time JS -->
    <script type="text/javascript" src="../assets/js/dateTime.js"></script>
    <style>
        .box-bg{
            background: #fff;
            border-radius: 5px;
            margin-top: 1rem;
            padding: 1rem;
        }
    </style>
</head>
<body>
<div class="wrapper">
    <!-- Header Section -->
    <?php if($_SESSION['parent']!=""){ require_once 'includes/navbar/navbar.php';}?>
    <!-- Sidebar -->
    <?php if($_SESSION['parent']!=""){ require_once 'includes/sidebar/sidebar.php';}?>
    <!-- Right Section -->
    <main class="main-wrapper">
        <div class="container">
            <div class="row pt-2">
                <div class="col">
                <p class="blue">A table showing all vaccines administered to a child and at what stage of child development, what the vaccine protects and as well as vaccine administration mode.</p>
                <p class="bold">Always remember to take your child for immunisation for a better health child</p>
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover" id="vaccines">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Package</th>
                                    <th>Vaccine</th>
                                    <th>Vaccine Protects</th>
                                    <th>Administration Mode</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $sql=mysqli_query($con, "SELECT * FROM vaccines");
                                $count=0;
                                while($row=mysqli_fetch_assoc($sql)){$count++;?>
                                <tr>
                                    <td><?php echo $count;?></td>
                                    <td><?php echo $row['vaccine_package'];?></td>
                                    <td><?php echo $row['vaccine_name'];?></td>
                                    <td><?php echo $row['vaccine_protects'];?></td>
                                    <td><?php echo $row['vaccine_admin_mode'];?></td>
                                </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </main>  
</div>
<!-- JS -->
<script src="../assets/js/main.js"></script>
<script src="../assets/js/dateTime.js"></script>
<script src="../assets/js/disableKeys.js"></script>
</body>
</html>
<?php } ?>