<?php
// Start session
session_start();
error_reporting(0);
// Include database connection
require_once '../includes/config/database.php';
if(isset($_POST['login'])){
  $regno=$_POST['regno'];
  $mothers_contact=$_POST['mothers_contact'];

  $query=mysqli_query($con, "SELECT * FROM child_register WHERE regno='$regno' AND mothers_contact='$mothers_contact' OR fathers_contact='$mothers_contact' AND childs_status=1");
  $user=mysqli_fetch_array($query);
  if($user){
    if(!empty($_POST['remember'])){
      setcookie("regno", $_POST['regno'], time()+ (10 * 365 * 24 * 60 * 60));
      setcookie("mothers_contact", $_POST['mothers_contact'], time()+ (10 * 365 * 24 * 60 * 60));
    }
    else{
      if(isset($_COOKIE['regno'])){
        setcookie("regno", "");
      }
      if(isset($_COOKIE['mothers_contact'])){
        setcookie("mothers_contact", "");
      }
    }
    header('Location: index.php');
  }
  if($user>0){
    $extra='dashboard.php';
    $_SESSION['parent']=$_POST['regno'];
    $_SESSION['regid']=$user['regid'];
    $_SESSION['fullnames']=$user['mothers_names'];
    $host=$_SERVER['HTTP_HOST'];
    $uri=rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
    header("Location: http://$host$uri/$extra");
    exit();
  }else{
    $_SESSION['msg']='Username and Password Do not Match';
    $extra='index.php';
    $host=$_SERVER['HTTP_HOST'];
    $uri=rtrim(dirname($_SERVER['PHP_SELF']),'/\\');
    header("Location: http://$host$uri/$extra");
    exit();
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to CIIMS</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" type="text/css" href="../assets/css/bootstrap.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" type="text/css" href="../assets/css/style.css">
    <!-- Material Icons -->
    <link rel="stylesheet" href="../assets/icons/material-icons.woff2">
    <!-- Favicon -->
    <link rel="shortcut icon" href="../components/favicon/favicon.png" type="image/x-icon">
    <style>
        body{
            background-color: #232E40;
        }
        .box-bg{
            background: #f3f3f3;
            border-radius: 5px;
            margin-top: 1rem;
        }
        .box-bg p{
            color: blue;
            padding: 1rem;
        }
        .input-field:focus{
            border-bottom: 1px solid blue;
            background: #fafafa;
        }
    </style>
  </head>
<body>
    <div class="main-wrapper">
        <div class="container">
            <div class="row pt-5 mt-5">
                <div class="col-lg-8 col-md-8">
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-lg-5 col-md-5">
                                    <h4 class="center uppercase bold blue">Login</h4>
                                    <form method="POST" autocomplete="off">
                                        <div class="row pt-4">
                                            <div class="col">
                                                <input type="text" name="regno" value="<?php if(isset($_COOKIE['regno'])){ echo $_COOKIE['regno']; } ?>" class="input-field" placeholder="Child registration number" title="This field is required">
                                            </div>
                                        </div>
                                        <div class="row pt-4">
                                            <div class="col">
                                                <input type="password" name="mothers_contact" maxlength="10" value="<?php if(isset($_COOKIE['mothers_contact'])){ echo $_COOKIE['mothers_contact']; } ?>" class="input-field" placeholder="Password" title="This field is required">
                                            </div>
                                        </div>
                                        <div class="row pt-4">
                                            <div class="col">
                                                <input type="checkbox" name="remember" <?php if(isset($_COOKIE['regno'])){ ?> checked <?php } ?>> Remember Me
                                            </div>
                                        </div>
                                        <div class="row pt-4">
                                            <div class="col">
                                                <button type="submit" name="login" class="button button-main button-block">Login</button>
                                            </div>
                                        </div>
                                    </form>
                                    <div class="row pt-4">
                                        <div class="col center red">
                                            <?php echo $_SESSION['msg'];?>
                                            <?php echo $_SESSION['msg']='';?>
                                        </div>
                                    </div>
                                    <div class="row pt-2">
                                        <div class="col">
                                            <a href="#" class="center">Forgot Password?</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-7 col-md-6 pt-7">
                                    <center><img src="../media/photos/logo.png" alt="Logo" width="100px"></center>
                                    <div class="box-bg">
                                        <p>Welcome to Child Immunisation Information Management System, your user name is your child's registration number and your password is your contact you used while registering your child's birth</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 pt-5 mt-5">
                    <p>For any assistance, you can download the user manual - PDF guide</p>
                    <a href="../readme/Child-Immunisation-Information-Management-System-User-Manual.pdf" target="_blank"><button class="button button-main button-block">Download User Manual</button></a>
                </div>
            </div>
        </div>
    </div>
<!-- JS -->
<script src="../assets/js/main.js"></script>
<script src="../assets/js/disableKeys.js"></script>
</body>
</html>