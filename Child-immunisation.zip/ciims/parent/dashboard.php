<?php
// Start session
session_start();
error_reporting(0);
// Include database connection
require_once '../includes/config/database.php';
// Check if session is set
if(strlen($_SESSION['parent'])==0){
	header("Location: index.php");
	exit();
}else{
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    $sql=mysqli_query($con, "SELECT * FROM sysinfo");
    while($row=mysqli_fetch_assoc($sql)){?>
    <title><?php echo $row['fullname']." | ".$row['shortname'];;?></title>
    <?php } ?>
    <!-- CSS -->
    <link rel="stylesheet" href="../assets/css/bootstrap.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- Material Icons -->
    <link rel="stylesheet" href="../assets/icons/material-icons.woff2">
    <!-- Favicon -->
    <link rel="shortcut icon" href="../components/favicon/favicon.png" type="image/x-icon">
    <!-- Current Time JS -->
    <script type="text/javascript" src="../assets/js/dateTime.js"></script>
</head>
<body>
<div class="wrapper">
    <!-- Header Section -->
    <?php if($_SESSION['parent']!=""){ require_once 'includes/navbar/navbar.php';}?>
    <!-- Sidebar -->
    <?php if($_SESSION['parent']!=""){ require_once 'includes/sidebar/sidebar.php';}?>
    <!-- Right Section -->
    <main class="main-wrapper">
        <div class="container">
            <div class="row">
                <div class="col">
                    <p class="blue"><span class="material-icons-outlined">person</span>Welcome <span class="bold"><?php echo $_SESSION['fullnames'];?></span></p>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <div class="main-card">
                        <div class="card">
                            <div class="card-body">
                                <p class="text-primary uppercase">Total Packages</p>
                                <span class="material-icons-outlined blue">vaccines</span>
                            </div>
                            <span class="text-primary bold">
                                <?php
                                $sql=mysqli_query($con, "SELECT * FROM vaccines");
                                $visitcount=0;
                                while($row=mysqli_fetch_array($sql)){
                                $visitcount++;
                                }
                                echo sprintf('%03d',$visitcount);
                                ?>
                            </span>
                        </div>
                        <div class="card">
                            <div class="card-body">
                                <p class="text-primary uppercase">Completed Packages</p>
                                <span class="material-icons-outlined orange">vaccines</span>
                            </div>
                            <span class="text-primary bold">
                                <?php
                                $sql=mysqli_query($con, "SELECT * FROM immunisation_register INNER JOIN child_register ON immunisation_register.child_immunised=child_register.regid INNER JOIN vaccines ON immunisation_register.vaccine_administered=vaccines.vaccineid WHERE regno='".$_SESSION['parent']."'");
                                $completed=0;
                                while($row=mysqli_fetch_array($sql)){
                                $completed++;
                                }
                                echo sprintf('%03d',$completed);
                                ?>
                            </span>
                        </div>
                        <div class="card">
                            <div class="card-body">
                                <p class="text-primary uppercase">Upcoming Visits</p>
                                <span class="material-icons-outlined green">calendar_month</span>
                            </div>
                            <span class="text-primary bold">
                                <?php
                                $sql=mysqli_query($con, "SELECT COUNT(*) AS upcoming FROM immunisation_register INNER JOIN child_register ON immunisation_register.child_immunised=child_register.regid INNER JOIN vaccines ON immunisation_register.vaccine_administered=vaccines.vaccineid WHERE date(next_visit_date) > CURDATE() AND regno='".$_SESSION['parent']."'");
                                while($row=mysqli_fetch_array($sql)){
                                $upcoming=$row['upcoming'];
                                $packages=5;
                                if($upcoming==$packages){
                                    echo 'Immunisation Complete';
                                }else{
                                    echo sprintf('%03d',$upcoming);
                                }}
                                ?>
                            </span>
                        </div>
                    </div>
                    <div class="main-card pt-4">
                        <div class="card">
                            <div class="card-body">
                                <p class="text-primary uppercase">Visits Today</p>
                                <span class="material-icons-outlined green">today</span>
                            </div>
                            <span class="text-primary bold">
                                <?php
                                $sql=mysqli_query($con, "SELECT * FROM immunisation_register WHERE DATE(next_visit_date)=CURDATE() AND regno='".$_SESSION['parent']."'");
                                $count=0;
                                while($row=mysqli_fetch_array($sql)){
                                $count++;
                                }
                                echo sprintf('%03d',$count);
                                ?>
                            </span>
                        </div>
                        <div class="card">
                            <div class="card-body">
                                <p class="text-primary uppercase">Visits this Week</p>
                                <span class="material-icons-outlined blue">event</span>
                            </div>
                            <span class="text-primary bold">
                                <?php
                                $current_week_start=date('Y-m-d',strtotime("monday this week"));
                                $current_week_end=date('Y-m-d',strtotime("sunday this week"));
                                $current_week_year=date('Y');
                                $sql=mysqli_query($con, "SELECT * FROM immunisation_register WHERE next_visit_date BETWEEN '$current_week_start' AND '$current_week_end' AND YEAR(next_visit_date)='$current_week_year' AND regno='".$_SESSION['parent']."'");
                                $count=0;
                                while($row=mysqli_fetch_array($sql)){
                                $count++;
                                }
                                echo sprintf('%03d',$count);
                                ?>
                            </span>
                        </div>
                        <div class="card">
                            <div class="card-body">
                                <p class="text-primary uppercase">Visits this Month</p>
                                <span class="material-icons-outlined orange">calendar_month</span>
                            </div>
                            <span class="text-primary bold">
                                <?php
                                $current_month=date('m');
                                $current_month_year=date('Y');
                                $sql=mysqli_query($con, "SELECT * FROM immunisation_register INNER JOIN child_register ON immunisation_register.child_immunised=child_register.regid WHERE MONTH(next_visit_date)='$current_month' AND YEAR(next_visit_date)='$current_month_year' AND regno='".$_SESSION['parent']."'");
                                $count=0;
                                while($row=mysqli_fetch_array($sql)){
                                $count++;
                                }
                                echo sprintf('%03d',$count);
                                ?>
                            </span>
                        </div>
                    </div>
                    <div class="main-card pt-4">
                        <div class="card">
                            <div class="card-body">
                                <p class="text-primary uppercase">Visits Yesterday</p>
                                <span class="material-icons-outlined blue">today</span>
                            </div>
                            <span class="text-primary bold">
                                <?php
                                $sql=mysqli_query($con, "SELECT * FROM immunisation_register WHERE DATE(next_visit_date)=CURDATE()-1 AND regno='".$_SESSION['parent']."'");
                                $count=0;
                                while($row=mysqli_fetch_array($sql)){
                                $count++;
                                }
                                echo sprintf('%03d',$count);
                                ?>
                            </span>
                        </div>
                        <div class="card">
                            <div class="card-body">
                                <p class="text-primary uppercase">Visits Last Week</p>
                                <span class="material-icons-outlined orange">event</span>
                            </div>
                            <span class="text-primary bold">
                                <?php
                                $sql=mysqli_query($con, "SELECT * FROM immunisation_register WHERE DATE(next_visit_date)=CURDATE()-7 AND regno='".$_SESSION['parent']."'");
                                $count=0;
                                while($row=mysqli_fetch_array($sql)){
                                $count ++;
                                }
                                echo sprintf('%03d',$count);
                                ?>
                            </span>
                        </div>
                        <div class="card">
                            <div class="card-body">
                                <p class="text-primary uppercase">Visits Last Month</p>
                                <span class="material-icons-outlined green">calendar_month</span>
                            </div>
                            <span class="text-primary bold">
                                <?php
                                $last_month=date('m', strtotime('-1 month'));
                                $last_month_year=date('Y', strtotime('-1 month'));
                                $sql=mysqli_query($con, "SELECT * FROM immunisation_register WHERE MONTH(next_visit_date)='$last_month' AND YEAR(next_visit_date)='$last_month_year' AND regno='".$_SESSION['parent']."'");
                                $count=0;
                                while($row=mysqli_fetch_array($sql)){
                                $count++;
                                }
                                echo sprintf('%03d',$count);
                                ?>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>  
</div>
<!-- JS -->
<script src="../assets/js/main.js"></script>
<script src="../assets/js/dateTime.js"></script>
<script src="../assets/js/disableKeys.js"></script>
</body>
</html>
<?php } ?>