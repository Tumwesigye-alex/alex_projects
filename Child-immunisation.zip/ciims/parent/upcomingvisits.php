<?php
// Start session
session_start();
error_reporting(0);
// Include database connection
require_once '../includes/config/database.php';
// Check if session is set
if(strlen($_SESSION['parent'])==0){
	header("Location: index.php");
	exit();
}else{
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    $sql=mysqli_query($con, "SELECT * FROM sysinfo");
    while($row=mysqli_fetch_assoc($sql)){?>
    <title><?php echo $row['fullname']." | ".$row['shortname'];;?></title>
    <?php } ?>
    <!-- CSS -->
    <link rel="stylesheet" href="../assets/css/bootstrap.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- Material Icons -->
    <link rel="stylesheet" href="../assets/icons/material-icons.woff2">
    <!-- Favicon -->
    <link rel="shortcut icon" href="../components/favicon/favicon.png" type="image/x-icon">
    <!-- Current Time JS -->
    <script type="text/javascript" src="../assets/js/dateTime.js"></script>
</head>
<body>
<div class="wrapper">
    <!-- Header Section -->
    <?php if($_SESSION['parent']!=""){ require_once 'includes/navbar/navbar.php';}?>
    <!-- Sidebar -->
    <?php if($_SESSION['parent']!=""){ require_once 'includes/sidebar/sidebar.php';}?>
    <!-- Right Section -->
    <main class="main-wrapper">
        <div class="container">
            <div class="row pt-5">
                <div class="col">
                    <?php
                    $sql=mysqli_query($con, "SELECT * FROM immunisation_register INNER JOIN child_register ON immunisation_register.child_immunised=child_register.regid INNER JOIN vaccines ON immunisation_register.vaccine_administered=vaccines.vaccineid WHERE regno='".$_SESSION['parent']."' ORDER BY childid DESC LIMIT 1");
                    while($row=mysqli_fetch_assoc($sql)){?>
                    <span class="blue">Your next immunisation visit date is </span>
                        <?php echo '<b>'.DATE('D d-M-Y',strtotime($row['next_visit_date'])).'</b>';?>
                    <?php } ?>
                </div>
            </div>
        </div>
    </main>  
</div>
<!-- JS -->
<script src="../assets/js/main.js"></script>
<script src="../assets/js/dateTime.js"></script>
<script src="../assets/js/disableKeys.js"></script>
</body>
</html>
<?php } ?>