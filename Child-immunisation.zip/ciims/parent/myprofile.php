<?php
// Start session
session_start();
error_reporting(0);
// Include database connection
require_once '../includes/config/database.php';
// Check if session is set
if(strlen($_SESSION['parent'])==0){
	header("Location: index.php");
	exit();
}else{
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    $sql=mysqli_query($con, "SELECT * FROM sysinfo");
    while($row=mysqli_fetch_assoc($sql)){?>
    <title><?php echo $row['fullname']." | ".$row['shortname'];;?></title>
    <?php } ?>
    <!-- CSS -->
    <link rel="stylesheet" href="../assets/css/bootstrap.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- Material Icons -->
    <link rel="stylesheet" href="../assets/icons/material-icons.woff2">
    <!-- Favicon -->
    <link rel="shortcut icon" href="../components/favicon/favicon.png" type="image/x-icon">
    <!-- Current Time JS -->
    <script type="text/javascript" src="../assets/js/dateTime.js"></script>
    <style>
        .box-bg{
            background: #fafafa;
            border-radius: 5px;
            margin-top: 1rem;
            padding: 1rem;
        }
    </style>
</head>
<body>
<div class="wrapper">
    <!-- Header Section -->
    <?php if($_SESSION['parent']!=""){ require_once 'includes/navbar/navbar.php';}?>
    <!-- Sidebar -->
    <?php if($_SESSION['parent']!=""){ require_once 'includes/sidebar/sidebar.php';}?>
    <!-- Right Section -->
    <main class="main-wrapper">
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="box-bg">
                        <p class="red">My Profile</p>
                        <?php
                        $sql=mysqli_query($con, "SELECT * FROM child_register WHERE regno='".$_SESSION['parent']."'");
                        while($row=mysqli_fetch_assoc($sql)){?>
                        <div class="row">
                            <div class="col-lg-1 col-lg-1">
                                <img src="../media/profile/avatar.png" alt="Profile" width="80px" height="80px">
                            </div>
                            <div class="col-lg-4 col-md-4">
                                <p class="uppercase blue bold"><?php echo $row['mothers_names'];?></p>
                                <?php $ctrycode='+256'; $space=' '; $result=$row['mothers_contact']; $trimmed=substr($result,1); echo $ctrycode.$space.$trimmed;?>
                            </div>
                            <div class="col-lg-4 col-md-4">
                                <p class="uppercase blue">Email ID<?php echo $row['mothers_email'];?></p>
                            </div>
                            <div class="col-lg-2 col-md-2">
                                <p class="uppercase blue">Occupation</p><?php echo $row['mothers_occupation'];?>
                            </div>
                            <div class="col-lg-1 col-md-1">
                                <a href="#"><span class="material-icons-outlined">edit</span></a>
                            </div>
                        </div>
                    </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </main>  
</div>
<!-- JS -->
<script src="../assets/js/main.js"></script>
<script src="../assets/js/dateTime.js"></script>
<script src="../assets/js/disableKeys.js"></script>
</body>
</html>
<?php } ?>