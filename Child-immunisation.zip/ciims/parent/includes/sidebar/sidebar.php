<aside id="sidebar">
    <div class="sidebar-title">
        <div class="sidebar-brand">
            <span title="CIIMS">Child Immunisation</span>
        </div>
        <span class="material-icons-outlined" onclick="closeSidebar()">close</span>
    </div>
    <ul class="sidebar-list">
        <li class="sidebar-list-item">
            <a href="dashboard.php"><span class="material-icons-outlined">dashboard</span> Dashboard</a>
        </li>
        <li class="sidebar-list-item">
            <a href="mychild.php"><span class="material-icons-outlined">family_restroom</span> My Child</a>
        </li>
        <li class="sidebar-list-item">
            <a href="myvisits.php"><span class="material-icons-outlined">calendar_month</span> My Visits</a>
        </li>
        <li class="sidebar-list-item">
            <a href="upcomingvisits.php"><span class="material-icons-outlined">calendar_month</span> Upcoming Visits</a>
        </li>
        <li class="sidebar-list-item">
            <a href="vaccines.php"><span class="material-icons-outlined">vaccines</span> Vaccines</a>
        </li>
        <li class="sidebar-list-item">
            <a href="feedback.php"><span class="material-icons-outlined">chat</span> Feedback</a>
        </li>
        <!-- <li class="sidebar-list-item">
            <a href="myprofile.php"><span class="material-icons-outlined">person</span> My Profile</a>
        </li> -->
        <li class="sidebar-list-item">
            <a href="signout.php"><span class="material-icons-outlined">logout</span> Signout</a>
        </li>
    </ul>
</aside>