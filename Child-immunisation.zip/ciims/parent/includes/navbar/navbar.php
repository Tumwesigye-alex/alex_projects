<header class="header">
  <div class="menu-icon" onclick="openSidebar()">
    <span class="material-icons-outlined">menu</span>
  </div>
  <div class="header-left">
  <span class="bold">Today is</span> <span class="blue"><?php date_default_timezone_set('Africa/Kampala'); print(date('D d M Y'));?></span>
  </div>
  <div class="header-right">
    <span class="bold">Time</span>
    <span id="dateTime" class="blue"></span>
    <?php print(date('A'));?>
    <script type="text/javascript">window.onload=dateTime('dateTime');</script>
  </div>
</header>