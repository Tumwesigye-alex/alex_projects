<?php
// Start session
session_start();
error_reporting(0);
// Include database connection
require_once '../includes/config/database.php';
// Check if session is set
if(strlen($_SESSION['parent'])==0){
	header("Location: index.php");
	exit();
}else{
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    $sql=mysqli_query($con, "SELECT * FROM sysinfo");
    while($row=mysqli_fetch_assoc($sql)){?>
    <title><?php echo $row['fullname']." | ".$row['shortname'];;?></title>
    <?php } ?>
    <!-- CSS -->
    <link rel="stylesheet" href="../assets/css/bootstrap.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- Material Icons -->
    <link rel="stylesheet" href="../assets/icons/material-icons.woff2">
    <!-- Favicon -->
    <link rel="shortcut icon" href="../components/favicon/favicon.png" type="image/x-icon">
    <!-- Current Time JS -->
    <script type="text/javascript" src="../assets/js/dateTime.js"></script>
</head>
<body>
<div class="wrapper">
    <!-- Header Section -->
    <?php if($_SESSION['parent']!=""){ require_once 'includes/navbar/navbar.php';}?>
    <!-- Sidebar -->
    <?php if($_SESSION['parent']!=""){ require_once 'includes/sidebar/sidebar.php';}?>
    <!-- Right Section -->
    <main class="main-wrapper">
        <div class="container">
            <div class="row pt-2">
                <div class="col">
                    <p class="blue">The table below shows a list of vaccines your child has completed and date the vaccine was administered</p>
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover" id="mychild">
                            <thead>
                                <tr>
                                    <th>Child's Names</th>
                                    <th>Registration Number</th>
                                    <th>Package</th>
                                    <th>Vaccine</th>
                                    <th>Date</th>
                                    <th>Remarks</th>
                                    <th>O/Vaccine</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $sql=mysqli_query($con, "SELECT * FROM immunisation_register INNER JOIN child_register ON immunisation_register.child_immunised=child_register.regid INNER JOIN vaccines ON immunisation_register.vaccine_administered=vaccines.vaccineid  WHERE regno='".$_SESSION['parent']."'");
                                while($row=mysqli_fetch_assoc($sql)){?>
                                <tr>
                                    <td><?php echo $row['childsnames'];?></td>
                                    <td><?php echo $row['regno'];?></td>
                                    <td><?php echo $row['vaccine_package'];?></td>
                                    <td><?php echo $row['vaccine_name'];?></td>
                                    <td><?php echo date('D-m-Y',strtotime($row['date_immunised']));?></td>
                                    <td><?php echo $row['health_remarks'];?></td>
                                    <td><?php echo $row['other_vaccine'];?></td>
                                </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </main>  
</div>
<!-- JS -->
<script src="../assets/js/main.js"></script>
<script src="../assets/js/dateTime.js"></script>
<script src="../assets/js/disableKeys.js"></script>
</body>
</html>
<?php } ?>