<?php
// Start session
session_start();
error_reporting(0);
// Include database connection
require_once '../includes/config/database.php';
// Check if session is set
if(strlen($_SESSION['parent'])==0){
	header("Location: index.php");
	exit();
}else{
    if(isset($_POST['submit'])){
        $childs_regno=$_POST['childs_regno'];
        $package_received=$_POST['package_received'];
        $date_received=$_POST['date_received'];
        $priority=$_POST['priority'];
        $comment=$_POST['comment'];

        if(empty($_POST['package_received']) || empty($_POST['date_received']) || empty($_POST['comment'])){
            $_SESSION['msg']='<font color="red">Please fill all fields</font>';
        }else{
            $query=mysqli_query($con, "INSERT INTO feedback(childs_regno, package_received, date_received, priority, comment) VALUES('$childs_regno', '$package_received', '$date_received', '$priority', '$comment')");
            if($query){
                $_SESSION['msg']='<font color="blue">Feedback sent successully. Your healthcare provider will get back to you soon</font>';
            }else{
                $_SESSION['msg']='<font color="red">Feedback not sent</font>';
            }
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    $sql=mysqli_query($con, "SELECT * FROM sysinfo");
    while($row=mysqli_fetch_assoc($sql)){?>
    <title><?php echo $row['fullname']." | ".$row['shortname'];;?></title>
    <?php } ?>
    <!-- CSS -->
    <link rel="stylesheet" href="../assets/css/bootstrap.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- Material Icons -->
    <link rel="stylesheet" href="../assets/icons/material-icons.woff2">
    <!-- Favicon -->
    <link rel="shortcut icon" href="../components/favicon/favicon.png" type="image/x-icon">
    <!-- Current Time JS -->
    <script type="text/javascript" src="../assets/js/dateTime.js"></script>
    <style>
        .feedback{
            line-height: 1rem;
        }
        .reply-section{
            background: #fafafa;
            width: 500px;
            height: 500px;
            position: fixed;
            padding: 15px;
            z-index: 10;
            border-radius: 5px;
            overflow-x: hidden;
            overflow-y: auto;
        }
    </style>
</head>
<body>
<div class="wrapper">
    <!-- Header Section -->
    <?php if($_SESSION['parent']!=""){ require_once 'includes/navbar/navbar.php';}?>
    <!-- Sidebar -->
    <?php if($_SESSION['parent']!=""){ require_once 'includes/sidebar/sidebar.php';}?>
    <!-- Right Section -->
    <main class="main-wrapper">
        <div class="container">
            <div class="row">
                <!-- First column -->
                <div class="col-lg-6 col-md-6">
                    <p class="blue">If your child develops complications or any suspicious condition after immunisation, always remember to inform your healthcare provider for better health monitoring by filling the form below</p>
                    <form method="POST" autocomplete="off">
                        <div class="row">
                            <div class="col">
                                <?php
                                    $sql=mysqli_query($con, "SELECT * FROM child_register WHERE regno='".$_SESSION['parent']."'");
                                    while($row=mysqli_fetch_assoc($sql)){?>
                                    <input type="text" name="childs_regno" value="<?php echo $row['regid'];?>" class="input-field" readonly hidden>
                                <?php } ?>
                            </div>
                        </div>
                        <div class="row pt-2">
                            <div class="col">
                                <select name="package_received" id="package" class="input-field">
                                <option>Select Vaccine Received</option>
                                <?php
                                $sql=mysqli_query($con, "SELECT * FROM vaccines");
                                while($row=mysqli_fetch_assoc($sql)){?>
                                <option value="<?php echo $row['vaccineid'];?>"><?php echo $row['vaccine_package'];?></option>
                                <?php } ?>
                                </select>
                            </div>
                        </div>
                        <div class="row pt-2">
                            <div class="col">
                                <label for="">When did this complication start</label>
                                <input type="date" name="date_received" class="input-field">
                            </div>
                        </div>
                        <div class="row pt-2">
                            <div class="col">
                                <select name="priority" class="input-field">
                                    <option>Select Priority</option>
                                    <option>Severe</option>
                                    <option>Moderate</option>
                                    <option>Undefined</option>
                                </select>
                            </div>
                        </div>
                        <div class="row pt-2">
                            <div class="col">
                                <textarea name="comment" rows="4" class="input-field" placeholder="Describe the current status of your child"></textarea>
                            </div>
                        </div>
                        <div class="row pt-2">
                            <div class="col">
                                <button type="submit" name="submit" class="button button-main button-block"><span class="material-icons-outlined">send</span> Send Feedback</button>
                            </div>
                        </div>
                        <div class="row pt-2">
                            <div class="col-lg-7">
                                <?php echo $_SESSION['msg'];?>
                                <?php echo $_SESSION['msg']='';?>
                            </div>
                        </div>
                    </form>
                </div>
                <!-- Second column -->
                <div class="col-lg-6 col-md-6">
                    <span class="blue bold">Chats Section with your healthcare provider</span>
                    <div class="reply-section">
                        <?php
                        $query=mysqli_query($con, "SELECT * FROM feedback INNER JOIN child_register ON feedback.feedback_id=child_register.regid WHERE regno='".$_SESSION['parent']."'");
                        while($row=mysqli_fetch_assoc($query)){?>
                        <!-- Nurse's reply -->
                        <div class="row pt-2">
                            <div class="col">
                                <div class="feedback">
                                <p><?php echo $row['reply'];?></p>
                                <p class="small"><?php echo 'Time: ' .date('D d-M-Y H:i:s A',strtotime($row['date_replied']));?></p>
                                <p class="bold blue"><?php echo $row['replied_by'];?></p>
                            </div>
                        </div>
                        <!-- Mother's reply -->
                        <div class="row pt-4">
                            <div class="col">
                                <div class="feedback">
                                <p><?php echo $row['comment'];?></p>
                                <p class="small"><?php echo 'Time: '. date('D d-M-Y H:i:s A',strtotime($row['date_sent']));?></p>
                                <p class="bold blue"><?php echo $row['mothers_names'];?></p>
                            </div>
                        </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </main>  
</div>
<!-- JS -->
<script src="../assets/js/main.js"></script>
<script src="../assets/js/dateTime.js"></script>
<script src="../assets/js/disableKeys.js"></script>
</body>
</html>
<?php } ?>