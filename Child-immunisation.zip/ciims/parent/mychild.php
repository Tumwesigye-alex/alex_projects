<?php
// Start session
session_start();
error_reporting(0);
// Include database connection
require_once '../includes/config/database.php';
// Check if session is set
if(strlen($_SESSION['parent'])==0){
	header("Location: index.php");
	exit();
}else{
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    $sql=mysqli_query($con, "SELECT * FROM sysinfo");
    while($row=mysqli_fetch_assoc($sql)){?>
    <title><?php echo $row['fullname']." | ".$row['shortname'];;?></title>
    <?php } ?>
    <!-- CSS -->
    <link rel="stylesheet" href="../assets/css/bootstrap.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- Material Icons -->
    <link rel="stylesheet" href="../assets/icons/material-icons.woff2">
    <!-- Favicon -->
    <link rel="shortcut icon" href="../components/favicon/favicon.png" type="image/x-icon">
    <!-- Current Time JS -->
    <script type="text/javascript" src="../assets/js/dateTime.js"></script>
    <style>
        .box-bg{
            background: #fafafa;
            border-radius: 5px;
            margin-top: 1rem;
            padding: 1rem;
        }
    </style>
</head>
<body>
<div class="wrapper">
    <!-- Header Section -->
    <?php if($_SESSION['parent']!=""){ require_once 'includes/navbar/navbar.php';}?>
    <!-- Sidebar -->
    <?php if($_SESSION['parent']!=""){ require_once 'includes/sidebar/sidebar.php';}?>
    <!-- Right Section -->
    <main class="main-wrapper">
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="box-bg">
                        <p class="red bold">My Account</p>
                        <?php
                        $sql=mysqli_query($con, "SELECT * FROM child_register WHERE regno='".$_SESSION['parent']."'");
                        while($row=mysqli_fetch_assoc($sql)){?>
                        <div class="row">
                            <div class="col-lg-1 col-lg-1">
                                <img src="../media/profile/avatar.png" alt="Profile" width="80px" height="80px">
                            </div>
                            <div class="col-lg-3 col-md-3">
                                <p class="uppercase blue bold"><?php echo $row['mothers_names'];?></p>
                                <?php $ctrycode='+256'; $space=' '; $result=$row['mothers_contact']; $trimmed=substr($result,1); echo $ctrycode.$space.$trimmed;?>
                            </div>
                            <div class="col-lg-2 col-md-2">
                                <p class="uppercase blue">Email ID<?php echo $row['mothers_email'];?></p>
                            </div>
                            <div class="col-lg-2 col-md-2">
                                <p class="uppercase blue">Occupation</p><?php echo $row['mothers_occupation'];?>
                            </div>
                            <div class="col-lg-4 col-md-4">
                                <p class="uppercase blue">Child's Registration Number</p><?php echo $row['regno'];?>
                            </div>
                        </div>
                    </div>
                    <div class="row pt-2">
                        <p class="uppercase red bold">My Child Details</p>
                        <div class="col-lg-3 col-md-3">
                            <p class="uppercase blue">Names</p><?php echo $row['childsnames'];?>
                        </div>
                        <div class="col-lg-1 col-md-1">
                            <p class="uppercase blue">Gender</p><?php echo $row['gender'];?>
                        </div>
                        <div class="col-lg-2 col-md-2">
                            <p class="uppercase blue">Date of Birth</p><?php echo date('D-m-Y',strtotime($row['childsdob']));?>
                        </div>
                        <div class="col-lg-2 col-md-2">
                            <p class="uppercase blue">Weight at Birth</p><?php echo $row['weight_at_birth'].' Kgs';?>
                        </div>
                        <div class="col-lg-1 col-md-1">
                            <p class="uppercase blue">Order</p><?php echo $row['birth_order'];?>
                        </div>
                        <div class="col-lg-3 col-md-3">
                            <p class="uppercase blue">Place of Birth</p><?php echo $row['place_of_birth'];?>
                        </div>
                    </div>
                    <div class="row pt-4">
                        <div class="col-lg-3 col-md-3">
                            <p class="uppercase blue">Husband</p><?php echo $row['fathers_names'];?> 
                        </div>
                        <div class="col-lg-3 col-md-3">
                            <p class="uppercase blue">Contact</p><?php echo $row['fathers_contact'];?> 
                        </div>
                        <div class="col-lg-3 col-md-3">
                            <p class="uppercase blue">Occupation</p><?php echo $row['fathers_occupation'];?> 
                        </div>
                        <div class="col-lg-3 col-md-3">
                            <p class="uppercase blue">NIN</p><?php echo $row['fathers_occupation'];?> 
                        </div>
                    </div>
                    <div class="row pt-4">
                        <div class="col-lg-3 col-md-3">
                            <p class="uppercase blue">District</p><?php echo $row['district'];?> 
                        </div>
                        <div class="col-lg-3 col-md-3">
                            <p class="uppercase blue">Sub county</p><?php echo $row['subcounty'];?> 
                        </div>
                        <div class="col-lg-3 col-md-3">
                            <p class="uppercase blue">Parish</p><?php echo $row['parish'];?> 
                        </div>
                        <div class="col-lg-3 col-md-3">
                            <p class="uppercase blue">Village</p><?php echo $row['village'];?> 
                        </div>
                    </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </main>  
</div>
<!-- JS -->
<script src="../assets/js/main.js"></script>
<script src="../assets/js/dateTime.js"></script>
<script src="../assets/js/disableKeys.js"></script>
</body>
</html>
<?php } ?>