-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 02, 2023 at 10:57 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ciims`
--

-- --------------------------------------------------------

--
-- Table structure for table `child_register`
--

CREATE TABLE `child_register` (
  `regid` int(11) NOT NULL,
  `regno` varchar(255) DEFAULT NULL,
  `childsnames` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `childsdob` date DEFAULT NULL,
  `weight_at_birth` varchar(255) DEFAULT NULL,
  `birth_order` varchar(255) DEFAULT NULL,
  `place_of_birth` varchar(255) DEFAULT NULL,
  `mothers_names` varchar(255) DEFAULT NULL,
  `mothers_nin` varchar(255) DEFAULT NULL,
  `mothers_contact` varchar(45) DEFAULT NULL,
  `mothers_occupation` varchar(255) DEFAULT NULL,
  `fathers_names` varchar(255) DEFAULT NULL,
  `fathers_nin` varchar(255) DEFAULT NULL,
  `fathers_contact` varchar(45) DEFAULT NULL,
  `fathers_occupation` varchar(255) DEFAULT NULL,
  `childs_photo` varchar(255) DEFAULT NULL,
  `childs_nin` varchar(255) DEFAULT NULL,
  `support_ticket` varchar(255) DEFAULT NULL,
  `mothers_photo` varchar(255) DEFAULT NULL,
  `fathers_photo` varchar(255) DEFAULT NULL,
  `childs_status` enum('1','0') NOT NULL DEFAULT '1',
  `date_registered` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_updated` datetime DEFAULT NULL,
  `district` varchar(255) DEFAULT NULL,
  `subcounty` varchar(255) DEFAULT NULL,
  `parish` varchar(255) DEFAULT NULL,
  `village` varchar(255) DEFAULT NULL,
  `health_complication` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `districts`
--

CREATE TABLE `districts` (
  `districtid` int(11) NOT NULL,
  `district` varchar(255) DEFAULT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `registered` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `feedbackid` int(11) NOT NULL,
  `childs_regno` varchar(255) DEFAULT NULL,
  `package_received` int(11) NOT NULL,
  `package_date_received` date DEFAULT NULL,
  `priority` varchar(45) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `support_ticket` varchar(45) DEFAULT NULL,
  `feedback_status` enum('1','0') NOT NULL DEFAULT '1',
  `date_sent` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `immunisation_register`
--

CREATE TABLE `immunisation_register` (
  `childid` int(11) NOT NULL,
  `child_immunised` int(11) NOT NULL,
  `vaccine_administered` int(11) NOT NULL,
  `date_immunised` date DEFAULT NULL,
  `health_remarks` varchar(255) DEFAULT NULL,
  `other_vaccine` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `next_visit_date` date DEFAULT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `date_registered` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `loginattempts`
--

CREATE TABLE `loginattempts` (
  `loginid` int(11) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `userip` varchar(255) DEFAULT NULL,
  `logintime` date DEFAULT NULL,
  `logincount` int(11) UNSIGNED ZEROFILL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `parishes`
--

CREATE TABLE `parishes` (
  `parishid` int(11) NOT NULL,
  `parish_district` int(11) NOT NULL,
  `parish_subcounty` int(11) NOT NULL,
  `parish` varchar(255) DEFAULT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `registered` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `subcounties`
--

CREATE TABLE `subcounties` (
  `subcountyid` int(11) NOT NULL,
  `subcounty_district` int(11) NOT NULL,
  `subcounty` varchar(255) DEFAULT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `registered` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `sysdev`
--

CREATE TABLE `sysdev` (
  `sysdevid` int(11) NOT NULL,
  `fullnames` varchar(255) DEFAULT NULL,
  `company` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `contact` varchar(255) DEFAULT NULL,
  `whatsapp` varchar(255) DEFAULT NULL,
  `twitter` varchar(255) DEFAULT NULL,
  `linkedin` varchar(255) DEFAULT NULL,
  `youtube` varchar(255) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `date_registered` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_updated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `sysinfo`
--

CREATE TABLE `sysinfo` (
  `sysid` int(11) NOT NULL,
  `fullname` varchar(255) DEFAULT NULL,
  `shortname` varchar(255) DEFAULT NULL,
  `slogan` varchar(255) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `contact` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `favicon` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `copyright` varchar(255) DEFAULT NULL,
  `buildyear` varchar(255) DEFAULT NULL,
  `coverphoto` varchar(255) DEFAULT NULL,
  `navbarcolor` varchar(255) DEFAULT NULL,
  `sidebarcolor` varchar(255) DEFAULT NULL,
  `maincolor` varchar(255) DEFAULT NULL,
  `footercolor` varchar(255) DEFAULT NULL,
  `headerfont` varchar(255) DEFAULT NULL,
  `bodyfont` varchar(255) DEFAULT NULL,
  `date_registered` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_updated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `userlogs`
--

CREATE TABLE `userlogs` (
  `userlogid` int(11) NOT NULL,
  `tracker` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `continent` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `countrycode` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `os` varchar(255) DEFAULT NULL,
  `device` varchar(255) DEFAULT NULL,
  `browser` varchar(255) DEFAULT NULL,
  `userip` varchar(255) DEFAULT NULL,
  `logintime` datetime DEFAULT NULL,
  `logouttime` datetime DEFAULT NULL,
  `status` enum('1','0') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `userlogs`
--

INSERT INTO `userlogs` (`userlogid`, `tracker`, `username`, `continent`, `country`, `countrycode`, `city`, `longitude`, `latitude`, `os`, `device`, `browser`, `userip`, `logintime`, `logouttime`, `status`) VALUES
(1, '334911', 'Admin', NULL, NULL, NULL, NULL, NULL, NULL, 'Windows 10', 'Computer', 'Chrome', '::1', '2023-08-02 23:56:37', NULL, '1');

-- --------------------------------------------------------

--
-- Table structure for table `userroles`
--

CREATE TABLE `userroles` (
  `userroleid` int(11) NOT NULL,
  `userrole` varchar(255) DEFAULT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `date_registered` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_updated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userid` int(11) NOT NULL,
  `surname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `contact` varchar(45) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `userrole` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `signature` varchar(255) DEFAULT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `date_registered` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_updated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userid`, `surname`, `lastname`, `contact`, `email`, `username`, `userrole`, `password`, `photo`, `signature`, `status`, `date_registered`, `date_updated`) VALUES
(1, 'Mutatiina', 'Brutas', '0780697787', NULL, 'Admin', 'Admin', '21232f297a57a5a743894a0e4a801fc3', NULL, NULL, '1', '2023-08-02 23:54:22', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `vaccines`
--

CREATE TABLE `vaccines` (
  `vaccineid` int(11) NOT NULL,
  `vaccine_package` varchar(255) DEFAULT NULL,
  `vaccine_name` varchar(255) DEFAULT NULL,
  `vaccine_protects` varchar(255) DEFAULT NULL,
  `vaccine_admin_mode` varchar(255) DEFAULT NULL,
  `vaccine_status` enum('1','0') NOT NULL DEFAULT '1',
  `registered` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_updated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `villages`
--

CREATE TABLE `villages` (
  `villageid` int(11) NOT NULL,
  `village_district` int(11) NOT NULL,
  `village_subcounty` int(11) NOT NULL,
  `village_parish` int(11) NOT NULL,
  `village` varchar(255) DEFAULT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `registered` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `child_register`
--
ALTER TABLE `child_register`
  ADD PRIMARY KEY (`regid`);

--
-- Indexes for table `districts`
--
ALTER TABLE `districts`
  ADD PRIMARY KEY (`districtid`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`feedbackid`);

--
-- Indexes for table `immunisation_register`
--
ALTER TABLE `immunisation_register`
  ADD PRIMARY KEY (`childid`),
  ADD KEY `child_immunised_idx` (`child_immunised`),
  ADD KEY `vaccine_administered_idx` (`vaccine_administered`);

--
-- Indexes for table `loginattempts`
--
ALTER TABLE `loginattempts`
  ADD PRIMARY KEY (`loginid`);

--
-- Indexes for table `parishes`
--
ALTER TABLE `parishes`
  ADD PRIMARY KEY (`parishid`),
  ADD KEY `parish_district_idx` (`parish_district`),
  ADD KEY `parish_subcounty_idx` (`parish_subcounty`);

--
-- Indexes for table `subcounties`
--
ALTER TABLE `subcounties`
  ADD PRIMARY KEY (`subcountyid`),
  ADD KEY `subcounty_district_idx` (`subcounty_district`);

--
-- Indexes for table `sysdev`
--
ALTER TABLE `sysdev`
  ADD PRIMARY KEY (`sysdevid`);

--
-- Indexes for table `sysinfo`
--
ALTER TABLE `sysinfo`
  ADD PRIMARY KEY (`sysid`);

--
-- Indexes for table `userlogs`
--
ALTER TABLE `userlogs`
  ADD PRIMARY KEY (`userlogid`);

--
-- Indexes for table `userroles`
--
ALTER TABLE `userroles`
  ADD PRIMARY KEY (`userroleid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `vaccines`
--
ALTER TABLE `vaccines`
  ADD PRIMARY KEY (`vaccineid`);

--
-- Indexes for table `villages`
--
ALTER TABLE `villages`
  ADD PRIMARY KEY (`villageid`),
  ADD KEY `village_district_idx` (`village_district`),
  ADD KEY `village_subcounty_idx` (`village_subcounty`),
  ADD KEY `village_parish_idx` (`village_parish`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `child_register`
--
ALTER TABLE `child_register`
  MODIFY `regid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `districts`
--
ALTER TABLE `districts`
  MODIFY `districtid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `feedbackid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `immunisation_register`
--
ALTER TABLE `immunisation_register`
  MODIFY `childid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `loginattempts`
--
ALTER TABLE `loginattempts`
  MODIFY `loginid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `parishes`
--
ALTER TABLE `parishes`
  MODIFY `parishid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subcounties`
--
ALTER TABLE `subcounties`
  MODIFY `subcountyid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sysdev`
--
ALTER TABLE `sysdev`
  MODIFY `sysdevid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sysinfo`
--
ALTER TABLE `sysinfo`
  MODIFY `sysid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `userlogs`
--
ALTER TABLE `userlogs`
  MODIFY `userlogid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `userroles`
--
ALTER TABLE `userroles`
  MODIFY `userroleid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `vaccines`
--
ALTER TABLE `vaccines`
  MODIFY `vaccineid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `villages`
--
ALTER TABLE `villages`
  MODIFY `villageid` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `immunisation_register`
--
ALTER TABLE `immunisation_register`
  ADD CONSTRAINT `child_immunised` FOREIGN KEY (`child_immunised`) REFERENCES `child_register` (`regid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `vaccine_administered` FOREIGN KEY (`vaccine_administered`) REFERENCES `vaccines` (`vaccineid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `parishes`
--
ALTER TABLE `parishes`
  ADD CONSTRAINT `parish_district` FOREIGN KEY (`parish_district`) REFERENCES `districts` (`districtid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `parish_subcounty` FOREIGN KEY (`parish_subcounty`) REFERENCES `subcounties` (`subcountyid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `subcounties`
--
ALTER TABLE `subcounties`
  ADD CONSTRAINT `subcounty_district` FOREIGN KEY (`subcounty_district`) REFERENCES `districts` (`districtid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `villages`
--
ALTER TABLE `villages`
  ADD CONSTRAINT `village_district` FOREIGN KEY (`village_district`) REFERENCES `districts` (`districtid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `village_parish` FOREIGN KEY (`village_parish`) REFERENCES `parishes` (`parishid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `village_subcounty` FOREIGN KEY (`village_subcounty`) REFERENCES `subcounties` (`subcountyid`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
